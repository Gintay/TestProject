#ifndef _TFSCLIENT_H__INCLUDED_
#define _TFSCLIENT_H__INCLUDED_

#ifndef USE_JNI_TFS_SDK

class CItemInfo
{
public:
	CItemInfo():
		m_nContentSize(0U),
		m_bIsDirectory(false)
		{}

	size_t GetContentSize() const				{ return m_nContentSize;	}
	void SetContentSize(const size_t cnSize)	{ m_nContentSize = cnSize;	}

	bool GetIsDirectory() const					{ return m_bIsDirectory;	}
	void SetIsDirectory(const bool cbValue)		{ m_bIsDirectory = cbValue;	}

	const string & GetPath() const				{ return m_sPath;			}
	void SetPath(const string & sPath)			{ m_sPath = sPath;			}

private:
	string		m_sPath;
	size_t		m_nContentSize;
	bool		m_bIsDirectory;
};

ref class CTfsClient
{
public:
	CTfsClient() {}

	bool Connect(const char * szcUrl, LibTfsClientResultCode & enRetCode, string & sError);
	bool Connect(const char * szcUrl, const char * szcDomain, const char * szcUser,
		const char * szcPwd, LibTfsClientResultCode & enRetCode, string & sError);
	bool DownloadItem(const char * szcPath, void * & pContent, size_t & nSize, 
		LibTfsClientResultCode & enRetCode, string & sError);
	bool UploadItemTempWorkspace(const char * szcServerPath, const char * szcLocalPath,
		const char * szcTargetToAdd, const char * szcComment, const bool cbRecursive,
		LibTfsClientResultCode & enRetv, string & sError);
	bool GetItemsByPath(const char * szcPath, const bool cbIsRecursive, vector<CItemInfo> & vInfos,
		LibTfsClientResultCode & enRetCode, string & sError);
	bool GetProjects(vector<string> & vsProjects, LibTfsClientResultCode & enRetCode,
		string & sError);
	string NormalizePathForTFS(const string & csPath);

private:
	static string GenerateTempWorkspaceName();

private:
	Microsoft::TeamFoundation::Client::TfsTeamProjectCollection ^	m_ProjectCollection;
};

#endif	//#ifndef USE_JNI_TFS_SDK
#endif // _TFSCLIENT_H__INCLUDED_
