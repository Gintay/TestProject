#include "StdAfx.h"

#include <string>
#include "libtfsclient.h"
#include "atomic_operations.h"

#ifdef USE_JNI_TFS_SDK
#include "common_constants.h"
#include "pathutils.h"
#include "tfsclient_jni.h"
#else	//#ifdef USE_JNI_TFS_SDK
#include "tfsclient.h"
#include "tfs_unresolved_assembly_handler.h"
#include <vcclr.h>
#endif	//#ifdef USE_JNI_TFS_SDK

////////////////////////////////////////////////////////////////////////////////////////////////////

const char g_szcFailedToCreateSession[]		= "Cannot create 'CLibTfsClientSession' object";
const char g_szcFailedToCreateClient[]		= "Cannot create 'CTfsJNIClient' object";
const char g_szcFailedToConnectToTFS[]		= "Cannot connect to TFS. Error: ";
const char g_szcMemoryAllocationError[]		= "Memory allocation error";
const char g_szcNullPointerParamPassed[]	= "NULL pointer parameter passed";
const char g_szcUnknownError[]				= "Unknown error";

int	g_iInitialized = 0;
////////////////////////////////////////////////////////////////////////////////////////////////////
// CLibTfsClientSession class

class CLibTfsClientSession
{
#ifdef USE_JNI_TFS_SDK

public:
	CLibTfsClientSession():
		m_pRootTfsClient(NULL)
		{}

	~CLibTfsClientSession()
		{ ReleaseRootTfsClient(); }

	CTfsJNIClient * GetTfsClient() const			{ return m_pRootTfsClient; }
	void SetTfsClient(CTfsJNIClient * pTfsClient)	{ m_pRootTfsClient = pTfsClient; }
	const string GetLastError() const				
	{ 
		return ((m_pRootTfsClient == NULL) ? string(szcEmptyString) :
			m_pRootTfsClient->GetLastError()); 
	}
	void ReleaseRootTfsClient()
	{
		if (m_pRootTfsClient != NULL) 
		{
			delete (CTfsJNIClient *)m_pRootTfsClient;
			m_pRootTfsClient = NULL; 
		}
	}

private:
	CTfsJNIClient * m_pRootTfsClient;

#else	//#ifdef USE_JNI_TFS_SDK

public:
	const string & GetLastError() const				{ return m_sLastError;	}
	void SetLastErrorByMoving(string & sLastError)	{ m_sLastError.swap(sLastError); }

	CTfsClient ^ GetTfsClient() const				{ return m_GcRootTfsClient; }
	void SetTfsClient(CTfsClient ^ tfsClient)		{ m_GcRootTfsClient = tfsClient; }

private:
	string					m_sLastError;
	gcroot<CTfsClient ^>	m_GcRootTfsClient;

#endif	//#ifdef USE_JNI_TFS_SDK
};

////////////////////////////////////////////////////////////////////////////////////////////////////
// CLibTfsClientItemsEnumeration class

class CLibTfsClientItemsEnumeration
{
public:
	void SetItemsInfoByMoving(vector<CItemInfo> & itemsInfo)
	{
		m_ItemsInfo.swap(itemsInfo);
		m_Iterator = m_ItemsInfo.begin();
	}

	const CItemInfo * GetCurrentItemInfo() const
	{
		const CItemInfo * cpItemInfo = NULL;

		if (m_Iterator != m_ItemsInfo.end())
		{
			cpItemInfo = &*m_Iterator;
		}

		return cpItemInfo;
	}

	bool MoveToNextItem()
	{
		bool bRes = false;

		do
		{
			if (m_Iterator == m_ItemsInfo.end())
			{
				break;
			}

			++m_Iterator;

			if (m_Iterator == m_ItemsInfo.end())
			{
				break;
			}

			bRes = true;
		}
		while (false);

		return bRes;
	}

	size_t	GetTfsClientItemsSize() const		{ return m_ItemsInfo.size(); }

private:
	vector<CItemInfo>					m_ItemsInfo;
	vector<CItemInfo>::const_iterator	m_Iterator;
};

////////////////////////////////////////////////////////////////////////////////////////////////////
// CLibTfsClientProjectsEnumeration class

class CLibTfsClientProjectsEnumeration
{
public:
	bool GetCurrentProject(const char * & szcName) const
	{
		bool bRes = false;

		if (m_Iterator != m_Projects.end())
		{
			szcName = m_Iterator->c_str();
			bRes = true;
		}

		return bRes;
	}

	bool MoveToNextProject()
	{
		bool bRes = false;

		do
		{
			if (m_Iterator == m_Projects.end())
			{
				break;
			}

			++m_Iterator;

			if (m_Iterator == m_Projects.end())
			{
				break;
			}

			bRes = true;
		}
		while (false);

		return bRes;
	}

	void SetProjectsByMoving(vector<string> & projects)
	{
		m_Projects.swap(projects);
		m_Iterator = m_Projects.begin();
	}

	size_t	GetTfsClientProjectsSize() const		{ return m_Projects.size(); }

private:
	vector<string>					m_Projects;
	vector<string>::const_iterator	m_Iterator;
};

////////////////////////////////////////////////////////////////////////////////////////////////////
// Common helper function

bool AllocateMessageToCaller(const string & csLocalMessage, char * & szMessage)
{
	bool bRetv = false;

	size_t nSize = csLocalMessage.size();
	void * pLocal = (nSize > 0) ? malloc(nSize + 1) : NULL;
	if (pLocal != NULL)
	{
		szMessage = static_cast<char *>(pLocal);
		memcpy(pLocal, (const void *)csLocalMessage.c_str(), nSize);
		szMessage[nSize] = '\0';
		bRetv = true;
	}

	return bRetv;
}

#ifdef USE_JNI_TFS_SDK

////////////////////////////////////////////////////////////////////////////////////////////////////
// Exported functions, JNI TFS SDK implementation
////////////////////////////////////////////////////////////////////////////////////////////////////

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_CreateSession(const char * szcUrl,
	CLibTfsClientSession * & pSession, char * & szError)
// User should not pass allocated memory here!
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	string sUrl, sDomain, sFullName, sPassword, sInput(SAFE_STRING(szcUrl));

	ParseUrlAndCredentialsString(sInput, sUrl, sFullName, sPassword);
	// Proceed with processing to evaluate parameters and produce an error if necessary 
	eRes = LibTfsClient_CreateAuthSession(sUrl.c_str(), sDomain.c_str(), sFullName.c_str(),
		sPassword.c_str(), pSession, szError);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_CreateAuthSession(const char * szcUrl,
	const char * szcDomainName, const char * szcUserName, const char * szcPassword,
	CLibTfsClientSession * & pSession, char * & szError)
// User should not pass valid allocated memory here!
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	string sLocalError;
	CTfsJNIClient * pTfsClient = NULL;
	do
	{
		if (szcUrl == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			sLocalError.assign(g_szcNullPointerParamPassed);
			break;
		}

		string	sUrl(szcUrl);
		if (sUrl.empty())
		{
			eRes = LibTfsClientResultCode_ErrorInvalidArgument;
			sLocalError.assign(g_szcEmptyInputError);
			break;
		}

		pTfsClient = NEW CTfsJNIClient();
		if (pTfsClient == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorMemoryAllocation;
			sLocalError.assign(g_szcFailedToCreateClient);
			break;
		}

		string	sFullName, sUserName(SAFE_STRING(szcUserName)), sPassword(SAFE_STRING(szcPassword)),
			sDomainName(SAFE_STRING(szcDomainName));
		// Check if passed 'sUserName' contains also domain name (exactly - look 4 backslash symbol)
		size_t nAtPos = sUserName.find(szcSymbolBackSlash);
		// JDK needs full name in the next format: "DomainName\\UserName"
		if (sDomainName.empty() || (nAtPos != string::npos))
		{
			sFullName.swap(sUserName);
		}
		else
		{
			sFullName.swap(sDomainName);
			sFullName.append(szcSymbolBackSlash);
			sFullName.append(sUserName);
		}

		if (!pTfsClient->Connect(sUrl, sFullName, sPassword))
		{
			eRes = LibTfsClientResultCode_ErrorConnectFailed;
			sLocalError = pTfsClient->GetLastError();
			break;
		}

		CLibTfsClientSession * pLibTfsClientSession = NEW CLibTfsClientSession;
		if (pLibTfsClientSession == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorMemoryAllocation2;
			sLocalError.assign(g_szcFailedToCreateSession);
			break;
		}

		pLibTfsClientSession->SetTfsClient(pTfsClient);
		pSession = pLibTfsClientSession;
		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	// Process error if any
	if (eRes != LibTfsClientResultCode_NoError)
	{
		AllocateMessageToCaller(sLocalError, szError);

		if (pTfsClient != NULL)
		{
			delete pTfsClient;
		}
	}

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_GetLastError(
	CLibTfsClientSession * pSession, char * & szError)
// User should not pass valid allocated memory here!
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		if (pSession == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		if (pSession->GetTfsClient() == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorInvalidArgument;
			break;
		}

		string	sError = pSession->GetLastError();
		if (sError.empty())
		{
			eRes = LibTfsClientResultCode_ErrorOperationFailed;
			break;
		}

		if (!AllocateMessageToCaller(sError, szError))
		{
			eRes = LibTfsClientResultCode_ErrorMemoryAllocation;
			break;
		}

		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_DownloadItem(
	CLibTfsClientSession * pSession, const char * szcPathToItem, void * & pContent,
	size_t & nContent)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		if ((pSession == NULL) || (szcPathToItem == NULL))
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		CTfsJNIClient * pTfsClient = pSession->GetTfsClient();
		if ((pTfsClient == NULL) || pTfsClient->IsProjectCollectionNULL())
		{
			eRes = LibTfsClientResultCode_ErrorInvalidArgument;
			break;
		}

		if (!pTfsClient->DownloadItem(szcPathToItem, pContent, nContent))
		{
			eRes = LibTfsClientResultCode_ErrorOperationFailed;
			break;
		}

		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_UploadItemUsingTempWorkspace(
	CLibTfsClientSession * pSession, const char * szcServerPath, const char * szcLocalPath,
	const char * szcTargetToAdd, const char * szcComment, const bool cbRecursive,
	const PendAddLockLevel ceLockLevel, const PendAddFileEncoding ceFileEncoding, 
	const PendAddGetOption ceGetOptions, const PendChangesOption cePendChangesOptions)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		if (pSession == NULL || szcServerPath == NULL || szcLocalPath == NULL ||
			szcComment == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		CTfsJNIClient * pTestTFS = pSession->GetTfsClient();
		if (pTestTFS == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		const string csNormalizedLocalPath = pTestTFS->NormalizePathForTFS(szcLocalPath);
		string sNormalizedTargetPath = pTestTFS->NormalizePathForTFS(szcTargetToAdd);

		if (sNormalizedTargetPath[0] == '\\')
		{
			sNormalizedTargetPath.erase(0, 1);
		}

		string sFullTargetPath(csNormalizedLocalPath);
		CPathUtils::AppendEndBackSlash(sFullTargetPath);
		sFullTargetPath.append(sNormalizedTargetPath);

		if (ceFileEncoding <= PendAddFileEncoding_Unknown ||
			ceFileEncoding >= PendAddFileEncodingsCount || 
			ceLockLevel <= PendAddLockLevel_Unknown || ceLockLevel >= PendAddLockLevelsCount ||
			ceGetOptions <= PendAddGetOption_Unknown || ceGetOptions >= PendAddGetOptionsCount ||
			cePendChangesOptions <= PendChangesOption_Unknown ||
			cePendChangesOptions >= PendChangesOptionsCount)
		{
			eRes = LibTfsClientResultCode_ErrorInvalidArgument;
			break;
		}

		CPendAdd PendAddOptions;
		PendAddOptions.sPaths.assign(sFullTargetPath);
		PendAddOptions.eFileEncoding = ceFileEncoding;
		PendAddOptions.eLockLevel = ceLockLevel;
		PendAddOptions.eGetOptions = ceGetOptions;
		PendAddOptions.ePendChangesOptions = cePendChangesOptions;
		PendAddOptions.bRecursive = true;

		if (!pTestTFS->UploadItemTempWorkspace(szcServerPath, csNormalizedLocalPath, szcComment,
			PendAddOptions))
		{
			eRes = LibTfsClientResultCode_ErrorOperationFailed;
			break;
		}

		eRes = LibTfsClientResultCode_NoError;
	} 
	while (false);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_UploadItemUsingExistingWorkspace(
	CLibTfsClientSession * pSession, const char * szcWorkspaceName, const char * szcWorkspaceOwner,
	const char * szcComment, const char * szcTargetFullPath, const bool cbRecursive,
	const PendAddLockLevel ceLockLevel, const PendAddFileEncoding ceFileEncoding, 
	const PendAddGetOption ceGetOptions, const PendChangesOption cePendChangesOptions)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		if (pSession == NULL || szcWorkspaceName == NULL || szcWorkspaceOwner == NULL 
			|| szcComment == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		if (ceFileEncoding <= PendAddFileEncoding_Unknown ||
			ceFileEncoding >= PendAddFileEncodingsCount || 
			ceLockLevel <= PendAddLockLevel_Unknown || ceLockLevel >= PendAddLockLevelsCount ||
			ceGetOptions <= PendAddGetOption_Unknown || ceGetOptions >= PendAddGetOptionsCount ||
			cePendChangesOptions <= PendChangesOption_Unknown ||
			cePendChangesOptions >= PendChangesOptionsCount)
		{
			eRes = LibTfsClientResultCode_ErrorInvalidArgument;
			break;
		}

		CTfsJNIClient * pTestTFS = pSession->GetTfsClient();
		if (pTestTFS == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		const string csNormalizedTargetPath = pTestTFS->NormalizePathForTFS(szcTargetFullPath);

		CPendAdd PendAddOptions;
		PendAddOptions.sPaths.assign(csNormalizedTargetPath);
		PendAddOptions.eFileEncoding = ceFileEncoding;
		PendAddOptions.eLockLevel = ceLockLevel;
		PendAddOptions.eGetOptions = ceGetOptions;
		PendAddOptions.ePendChangesOptions = cePendChangesOptions;
		PendAddOptions.bRecursive = true;

		if (!pTestTFS->UploadItemExistingWorkspace(szcWorkspaceName, szcWorkspaceOwner, szcComment,
			PendAddOptions))
		{
			eRes = LibTfsClientResultCode_ErrorOperationFailed;
			break;
		}

		eRes = LibTfsClientResultCode_NoError;

	} 
	while (false);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_BeginItemsEnumeration(
	CLibTfsClientSession * pSession, const char * szcPath, const bool cbRecursive,
	CLibTfsClientItemsEnumeration * & pEnumeration)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		if ((pSession == NULL) || (szcPath == NULL))
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		CTfsJNIClient * pTfsClient = pSession->GetTfsClient();
		if ((pTfsClient == NULL) || pTfsClient->IsProjectCollectionNULL())
		{
			eRes = LibTfsClientResultCode_ErrorInvalidArgument;
			break;
		}

		vector<CItemInfo> vItemsInfo;
		if (!pTfsClient->GetItemsByPath(szcPath, cbRecursive, vItemsInfo))
		{
			eRes = LibTfsClientResultCode_ErrorOperationFailed;
			break;
		}

		CLibTfsClientItemsEnumeration * pEnumInfo = NEW CLibTfsClientItemsEnumeration();
		if (pEnumInfo == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorMemoryAllocation;
			break;
		}

		pEnumInfo->SetItemsInfoByMoving(vItemsInfo);
		pEnumeration = pEnumInfo;
		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_BeginProjectsEnumeration(
	CLibTfsClientSession * pSession, CLibTfsClientProjectsEnumeration * & pEnumeration)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		if (pSession == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		CTfsJNIClient * pTfsClient = pSession->GetTfsClient();
		if ((pTfsClient == NULL) || pTfsClient->IsProjectCollectionNULL())
		{
			eRes = LibTfsClientResultCode_ErrorInvalidArgument;
			break;
		}

		vector<string> vsProjects;
		if (!pTfsClient->GetProjects(vsProjects))
		{
			eRes = LibTfsClientResultCode_ErrorOperationFailed;
			break;
		}

		CLibTfsClientProjectsEnumeration * pEnumInfo = NEW CLibTfsClientProjectsEnumeration;
		if (pEnumInfo == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorMemoryAllocation;
			break;
		}

		pEnumInfo->SetProjectsByMoving(vsProjects);
		pEnumeration = pEnumInfo;
		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_Initialize(const char * szcJvmLibRootPath,
	const char * szcTfsSdkRootPath, char * & szLogLibsLocationMsg, char * & szError)
// User should not pass valid allocated memory here!
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	string	sInitError;
	string	sJvmLibLocation(SAFE_STRING(szcJvmLibRootPath));
	string	sTfsSdkLocation(SAFE_STRING(szcTfsSdkRootPath));

	do
	{
		int iPrevValue = Atomic::Increment32((unsigned int *)&g_iInitialized);

		if (iPrevValue == 0)
		{
			bool	bExactLocation = !sJvmLibLocation.empty();
			if (bExactLocation)
			{
				// Ensure the path is slash-terminated
				CPathUtils::AppendEndSlash(sJvmLibLocation);
			}

			string	sError;
			if (!InitializeJVMLibrary(bExactLocation, sJvmLibLocation, sError))
			{
				sInitError.swap(sError);
				eRes = LibTfsClientResultCode_ErrorOperationFailed;
				break;
			}
				
			bExactLocation = !sTfsSdkLocation.empty();
			if (bExactLocation)
			{
				// Ensure the path is slash-terminated
				CPathUtils::AppendEndSlash(sTfsSdkLocation);
			}

			if (!InitializeJavaVirtualMachine(bExactLocation, sTfsSdkLocation, sError))
			{
				sInitError.swap(sError);
				FinalizeJVMLibrary();
				eRes = LibTfsClientResultCode_ErrorInternalJava;
				break;
			}

			eRes = LibTfsClientResultCode_NoError;
		}
		else if (iPrevValue > 0)
		{
			sInitError.assign("The process can only launch one JVM at a time; "
				"'LibTfsClient' library is initialized already");
			eRes = LibTfsClientResultCode_ErrorLibIsInitialized;
		}
		else // iPrevValue < 0	, too many finalizations
		{
			sInitError.assign(g_szcUnknownError);
			eRes = LibTfsClientResultCode_ErrorOutOfRange;
		}
	}
	while (false);

	string	sLibsLocation;
	if (eRes != LibTfsClientResultCode_NoError)
	{
		Atomic::Decrement32((unsigned int *)&g_iInitialized);
		AllocateMessageToCaller(sInitError, szError);
		FormatString(sLibsLocation, "Looking for Java Virtual Machine library in '%s' ; looking for"
			" TFS SDK tools in '%s' location", sJvmLibLocation.c_str(), sTfsSdkLocation.c_str());
	}
	else
	{
		FormatString(sLibsLocation, "Java Virtual Machine library successfully initialized in '%s';"
			" TFS SDK tools successfully initialized in '%s' location",
			sJvmLibLocation.c_str(), sTfsSdkLocation.c_str());
	}
	AllocateMessageToCaller(sLibsLocation, szLogLibsLocationMsg);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_Finalize()
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		int iPrevValue = Atomic::Decrement32((unsigned int *)&g_iInitialized);

		if (iPrevValue == 1)
		{
			bool bBreak = false;
			// Both Java Virtual Machine ...
			if (!FinalizeJavaVirtualMachine())
			{
				bBreak = true;
				eRes = LibTfsClientResultCode_ErrorInternalJava;
			}
			// ... and Java library release should be done anyway
			if (!FinalizeJVMLibrary())
			{
				bBreak = true;
				eRes = LibTfsClientResultCode_ErrorOperationFailed;
			}
			// Error occured
			if (bBreak)
			{
				break;
			}
		}
		else if (iPrevValue <= 0)	// finalized already
		{
			eRes = LibTfsClientResultCode_ErrorLibIsFinalized;
			break;
		}
		else // iPrevValue > 1, too many initializations
		{
			eRes = LibTfsClientResultCode_ErrorOutOfRange;
			break;
		}

		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	if (eRes != LibTfsClientResultCode_NoError)
	{
		Atomic::Increment32((unsigned int *)&g_iInitialized);
	}

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

#else	//#ifdef USE_JNI_TFS_SDK

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_BeginItemsEnumeration(
	CLibTfsClientSession * pSession, const char * szcPath, const bool cbRecurcive,
	CLibTfsClientItemsEnumeration * & pEnumeration)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		if (pSession == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		string sLastError;
		if (szcPath == NULL)
		{
			sLastError.assign("Invalid Path to destination items parameter passed");
			pSession->SetLastErrorByMoving(sLastError);
			eRes = LibTfsClientResultCode_ErrorInvalidArgument;
			break;
		}

		LibTfsClientResultCode eRetv = LibTfsClientResultCode_ErrorUnknown;
		vector<CItemInfo> itemsInfo;
		CTfsClient ^ tfsClient = pSession->GetTfsClient();
		if (!tfsClient->GetItemsByPath(szcPath, cbRecurcive, itemsInfo, eRetv, sLastError))
		{
			pSession->SetLastErrorByMoving(sLastError);
			eRes = (eRetv == LibTfsClientResultCode_ErrorUnknown) ?
				LibTfsClientResultCode_ErrorOperationFailed : eRetv;
			break;
		}

		CLibTfsClientItemsEnumeration * pEnumInfo = NEW CLibTfsClientItemsEnumeration();
		if (pEnumInfo == NULL)
		{
			sLastError.assign(g_szcMemoryAllocationError);
			pSession->SetLastErrorByMoving(sLastError);
			eRes = LibTfsClientResultCode_ErrorMemoryAllocation;
			break;
		}

		pEnumInfo->SetItemsInfoByMoving(itemsInfo);
		pEnumeration = pEnumInfo;
		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_BeginProjectsEnumeration(
	CLibTfsClientSession * pSession, CLibTfsClientProjectsEnumeration * & pEnumeration)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		if (pSession == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		string sLastError;
		vector<string> projects;
		LibTfsClientResultCode eRetv = LibTfsClientResultCode_ErrorUnknown;
		CTfsClient ^ tfsClient = pSession->GetTfsClient();
		if (!tfsClient->GetProjects(projects, eRetv, sLastError))
		{
			pSession->SetLastErrorByMoving(sLastError);
			eRes = (eRetv == LibTfsClientResultCode_ErrorUnknown) ?
				LibTfsClientResultCode_ErrorOperationFailed : eRetv;
			break;
		}

		CLibTfsClientProjectsEnumeration * pEnumInfo = NEW CLibTfsClientProjectsEnumeration;
		if (pEnumInfo == NULL)
		{
			sLastError.assign(g_szcMemoryAllocationError);
			pSession->SetLastErrorByMoving(sLastError);
			eRes = LibTfsClientResultCode_ErrorMemoryAllocation;
			break;
		}

		pEnumInfo->SetProjectsByMoving(projects);
		pEnumeration = pEnumInfo;
		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_CreateAuthSession(const char * szcUrl,
	const char * szcDomain, const char * szcUser, const char * szcPwd,
	CLibTfsClientSession * & pSession, char * & szError)
// User should not pass valid allocated memory here!
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	string	sConnectError;
	do
	{
		if (szcUrl == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			sConnectError.assign(g_szcNullPointerParamPassed);
			break;
		}

		string	sError;
		LibTfsClientResultCode eConnRetv = LibTfsClientResultCode_ErrorUnknown;
		CTfsClient ^ tfsClient = gcnew CTfsClient();
		// Try to connect with current user if credentials are not defined
		bool bConnected = false;
		if ((szcUser == NULL) && (szcPwd == NULL))
		{
			bConnected = tfsClient->Connect(szcUrl, eConnRetv, sError);
		}
		else
		{
			bConnected = tfsClient->Connect(szcUrl, szcDomain, szcUser, szcPwd, eConnRetv, sError);
		}
		if (!bConnected)
		{
			eRes = (eConnRetv == LibTfsClientResultCode_ErrorUnknown) ?
				LibTfsClientResultCode_ErrorConnectFailed : eConnRetv;
			sConnectError.assign(g_szcFailedToConnectToTFS);
			sConnectError.append(sError);
			break;
		}

		CLibTfsClientSession * pLibTfsClientSession = NEW CLibTfsClientSession;
		if (pLibTfsClientSession == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorMemoryAllocation;
			sConnectError.assign(g_szcFailedToCreateSession);
			break;
		}

		pLibTfsClientSession->SetTfsClient(tfsClient);
		pSession = pLibTfsClientSession;
		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	// Process error if any
	if (eRes != LibTfsClientResultCode_NoError)
	{
		AllocateMessageToCaller(sConnectError, szError);
	}

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_CreateSession(const char * szcUrl,
	CLibTfsClientSession * & pSession, char * & szError)
// User should not pass valid allocated memory here!
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	const char * szcDomain = NULL, szcUser = NULL, szcPwd = NULL;
	eRes = LibTfsClient_CreateAuthSession(szcUrl, szcDomain, szcUser, szcPwd, pSession, szError);
	
	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_DownloadItem(
	CLibTfsClientSession * pSession, const char * szcPathToItem, void * & pContent,
	size_t & nContent)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;

	do
	{
		if (pSession == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		string	sLastError;
		LibTfsClientResultCode eRetv = LibTfsClientResultCode_ErrorUnknown;
		CTfsClient ^ tfsClient = pSession->GetTfsClient();
		
		if (!tfsClient->DownloadItem(szcPathToItem, pContent, nContent, eRetv, sLastError))
		{
			pSession->SetLastErrorByMoving(sLastError);
			eRes = (eRetv == LibTfsClientResultCode_ErrorUnknown) ?
				LibTfsClientResultCode_ErrorOperationFailed : eRetv;
			break;
		}

		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_Finalize()
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		const int ciPrevValue =
			static_cast<int>(Atomic::Decrement32(reinterpret_cast<unsigned int *>(
			&g_iInitialized)));

		if (ciPrevValue == 1)
		{
			string sError;
			if (!CTfsUnresolvedAssemblyHandler::Stop(sError))
			{
				eRes = LibTfsClientResultCode_ErrorOperationFailed;
				break;
			}
		}
		else if (ciPrevValue <= 0)	// finalized already
		{
			eRes = LibTfsClientResultCode_ErrorLibIsFinalized;
			break;
		}
		else // > 1, too many initializations
		{
			eRes = LibTfsClientResultCode_ErrorOutOfRange;
			break;
		}

		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	if (eRes != LibTfsClientResultCode_NoError)
	{
		Atomic::Increment32((unsigned int *)&g_iInitialized);
	}

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_GetLastError(
	CLibTfsClientSession * pSession, char * & szError)
// User should not pass valid allocated memory here!
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		if (pSession == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		string	sError = pSession->GetLastError();
		if (sError.empty())
		{
			eRes = LibTfsClientResultCode_ErrorOperationFailed;
			break;
		}

		if (!AllocateMessageToCaller(sError, szError))
		{
			eRes = LibTfsClientResultCode_ErrorMemoryAllocation;
			break;
		}

		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_Initialize(const char * szcJvmLibRootPath,
	const char * szcTfsSdkRootPath, char * & szLogLibsLocationMsg, char * & szError)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();
	
	string sError;
	const string csTfsSdkRootPath = (szcTfsSdkRootPath == NULL) ? "" : szcTfsSdkRootPath;

	do
	{
		const int ciPrevValue =
			static_cast<int>(Atomic::Increment32(reinterpret_cast<unsigned int *>(
			&g_iInitialized)));

		if (ciPrevValue == 0)
		{
			if (!CTfsUnresolvedAssemblyHandler::Start(csTfsSdkRootPath, sError))
			{
				eRes = LibTfsClientResultCode_ErrorOperationFailed;
				break;
			}
			eRes = LibTfsClientResultCode_NoError;
		}
		else if (ciPrevValue > 0)
		{
			sError.assign("'LibTfsClient' library is initialized already");
			eRes = LibTfsClientResultCode_ErrorLibIsInitialized;
		}
		else // < 0, too many finalizations
		{
			sError.assign(g_szcUnknownError);
			eRes = LibTfsClientResultCode_ErrorOutOfRange;
		}
	}
	while (false);

	string sLibsLocation;
	if (eRes != LibTfsClientResultCode_NoError)
	{
		Atomic::Decrement32(reinterpret_cast<unsigned int *>(&g_iInitialized));
		AllocateMessageToCaller(sError, szError);
		sLibsLocation.assign("Looking for TFS SDK tools in location: ");
		sLibsLocation.append(csTfsSdkRootPath);
	}
	else
	{
		sLibsLocation.assign("TFS SDK tools successfully initialized in location: ");
		sLibsLocation.append(csTfsSdkRootPath);
	}
	AllocateMessageToCaller(sLibsLocation, szLogLibsLocationMsg);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_UploadItemUsingTempWorkspace(
	CLibTfsClientSession * pSession, const char * szcServerPath, const char * szcLocalPath,
	const char * szcTargetToAdd, const char * szcComment, const bool cbRecursive,
	const PendAddLockLevel ceLockLevel, const PendAddFileEncoding ceFileEncoding, 
	const PendAddGetOption ceGetOptions, const PendChangesOption cePendChangesOptions)
{
	LibTfsClientResultCode eRetv = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		if (pSession == NULL || szcServerPath == NULL || szcLocalPath == NULL ||
			szcTargetToAdd == NULL || szcComment == NULL)
		{
			eRetv = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		if (ceLockLevel <= PendAddLockLevel_Unknown || ceLockLevel >= PendAddLockLevelsCount)
		{
			eRetv = LibTfsClientResultCode_ErrorInvalidArgument;
			break;
		}
		
		string	sLastError;
		CTfsClient ^ tfsClient = pSession->GetTfsClient();

		if (!tfsClient->UploadItemTempWorkspace(szcServerPath, szcLocalPath, szcTargetToAdd,
			szcComment, cbRecursive, eRetv, sLastError))
		{
			pSession->SetLastErrorByMoving(sLastError);
			eRetv = (eRetv == LibTfsClientResultCode_ErrorUnknown) ?
				LibTfsClientResultCode_ErrorOperationFailed : eRetv;
			break;
		}
		
		eRetv = LibTfsClientResultCode_NoError;
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(eRetv = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRetv;
}

#endif	//#ifdef USE_JNI_TFS_SDK

////////////////////////////////////////////////////////////////////////////////////////////////////
// Exported functions common implementation

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_DestroySession(
	CLibTfsClientSession * & pSession)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		if (pSession == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		delete pSession;
		pSession = NULL;
		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_FreeMemory(void * & pMemory)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		if (pMemory == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		free(pMemory);
		pMemory = NULL;

		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(eRes = LibTfsClientResultCode_ErrorExceptionReceived);
	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_EndItemsEnumeration(
	CLibTfsClientItemsEnumeration * & pEnumeration)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;

	do
	{
		if (pEnumeration == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		delete pEnumeration;
		pEnumeration = NULL;

		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_EndProjectsEnumeration(
	CLibTfsClientProjectsEnumeration * & pEnumeration)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;

	do
	{
		if (pEnumeration == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		delete pEnumeration;
		pEnumeration = NULL;

		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_GetItemInfo(
	CLibTfsClientItemsEnumeration * pEnumeration, CLibTfsClientItemInfo & itemInfo)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;

	do
	{
		if (pEnumeration == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		const CItemInfo * cpItem = pEnumeration->GetCurrentItemInfo();
		if (cpItem == NULL)
		{
			eRes = LibTfsClientResultCode_EndReached;
			break;
		}

		itemInfo.m_bIsDirectory = cpItem->GetIsDirectory();
		itemInfo.m_nContentSize = cpItem->GetContentSize();
		itemInfo.m_szcPath = cpItem->GetPath().c_str();
		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_MoveToNextItem(
	CLibTfsClientItemsEnumeration * & pEnumeration)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;

	do
	{
		if (pEnumeration == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		if (!pEnumeration->MoveToNextItem())
		{
			eRes = LibTfsClientResultCode_EndReached;
			break;
		}

		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_GetProjectName(
	CLibTfsClientProjectsEnumeration * pEnumeration, const char * & szcProjectName)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;

	do
	{
		if (pEnumeration == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		if (!pEnumeration->GetCurrentProject(szcProjectName))
		{
			eRes = LibTfsClientResultCode_EndReached;
			break;
		}

		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	return eRes;
}

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_MoveToNextProject(
	CLibTfsClientProjectsEnumeration * pEnumeration)
{
	LibTfsClientResultCode eRes = LibTfsClientResultCode_ErrorUnknown;

	do
	{
		if (pEnumeration == NULL)
		{
			eRes = LibTfsClientResultCode_ErrorNullPtrParameter;
			break;
		}

		if (!pEnumeration->MoveToNextProject())
		{
			eRes = LibTfsClientResultCode_EndReached;
			break;
		}

		eRes = LibTfsClientResultCode_NoError;
	}
	while (false);

	return eRes;
}
