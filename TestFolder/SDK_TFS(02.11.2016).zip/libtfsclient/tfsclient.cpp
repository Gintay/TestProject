#include "StdAfx.h"

#include "libtfsclient/libtfsclientapi.h"

#ifndef USE_JNI_TFS_SDK

using namespace System;
using namespace Microsoft::TeamFoundation::Client;
using namespace Microsoft::TeamFoundation::VersionControl::Client;

#include "platformutils.h"
#include "atomic_operations.h"
#include "datetimeutils.h"
#include "managedutils.h"
#include "tfsclient.h"

////////////////////////////////////////////////////////////////////////////////////////////////////

const char g_szcManagedCodeException[]	= "Managed code exception received";
const char g_szcTempWorkspaceName[] = "TempJDKWorkspace";

////////////////////////////////////////////////////////////////////////////////////////////////////

bool CTfsClient::Connect(const char * szcUrl, LibTfsClientResultCode & enRetv, std::string & sError)
{
	bool bRes = false;
	sError.clear();

	try
	{
		String ^ sUrl = gcnew String(szcUrl);
		Uri ^ uri = gcnew Uri(sUrl);
		m_ProjectCollection = gcnew TfsTeamProjectCollection(uri);
		m_ProjectCollection->EnsureAuthenticated();

		enRetv = LibTfsClientResultCode_NoError;
		bRes = true;
	}
	catch (System::Exception ^ exception)
	{
		enRetv = LibTfsClientResultCode_ErrorExceptionReceived;
		ManagedUtils::ConvertSystemStringToStdString(exception->Message, sError);
		if (sError.empty())
		{
			sError.assign(g_szcManagedCodeException);
		}
	}

	return bRes;
}

bool CTfsClient::Connect(const char * szcUrl, const char * szcDomain, const char * szcUser,
	const char * szcPwd, LibTfsClientResultCode & enRetv, string & sError)
{
	bool bRes = false;
	sError.clear();

	try
	{
		String ^ sUrl = gcnew String(szcUrl);
		Uri ^ uri = gcnew Uri(sUrl);
		
		String ^ sDomain = gcnew String(szcDomain);
		String ^ sUser = gcnew String(szcUser);
		String ^ sPwd = gcnew String(szcPwd);
		System::Net::NetworkCredential ^ netCreds = 
			gcnew System::Net::NetworkCredential(sUser, sPwd, sDomain);
		
		m_ProjectCollection = gcnew TfsTeamProjectCollection(uri, netCreds);
		m_ProjectCollection->EnsureAuthenticated();

		enRetv = LibTfsClientResultCode_NoError;
		bRes = true;
	}
	catch (System::Exception ^ exception)
	{
		enRetv = LibTfsClientResultCode_ErrorExceptionReceived;
		ManagedUtils::ConvertSystemStringToStdString(exception->Message, sError);
		if (sError.empty())
		{
			sError.assign(g_szcManagedCodeException);
		}
	}

	return bRes;
}

bool CTfsClient::DownloadItem(const char * szcPath, void * & pContent, size_t & nSize, 
	LibTfsClientResultCode & enRetv, string & sError)
{
	bool bRes = false;
	sError.clear();
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		VersionControlServer ^ versionControl =
			m_ProjectCollection->GetService<VersionControlServer ^>();

		String ^ sPath = gcnew String(szcPath);

		if (!versionControl->ServerItemExists(sPath, ItemType::File))
		{
			sError.assign("Required item does not exist");
			enRetv = LibTfsClientResultCode_ErrorObjectNotExists;
			break;
		}

		Item ^ item = versionControl->GetItem(sPath);
		IO::Stream ^ stream = item->DownloadFile();
		IO::StreamReader ^ streamReader = gcnew IO::StreamReader(stream);

		String ^ sManagedContent = streamReader->ReadToEnd();

		nSize = static_cast<size_t>(sManagedContent->Length);
		pContent = malloc(nSize+1);
		if (pContent == NULL)
		{
			char szBuffer[100];

			sprintf(szBuffer, "Error allocating %llu bytes memory for file content",
				static_cast<unsigned long long>(nSize));
			sError.assign(szBuffer);
			enRetv = LibTfsClientResultCode_ErrorMemoryAllocation;
			nSize = 0U;
			break;
		}

		ManagedUtils::ConvertSystemStringToBytesArray(sManagedContent, pContent);
		char * szEnd = static_cast<char *>(pContent);
		*(szEnd + nSize) = '\0';
		bRes = true;
		enRetv = LibTfsClientResultCode_NoError;
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(bRes = false; 
		enRetv = LibTfsClientResultCode_ErrorExceptionReceived;
		sError.assign(g_szcManagedCodeException));
	return bRes;
}

bool CTfsClient::UploadItemTempWorkspace(const char * szcServerPath, const char * szcLocalPath,
	const char * szcTargetToAdd, const char * szcComment, const bool cbRecurcive,
	LibTfsClientResultCode & enRetv, string & sError)
{
	bool bRetVal = false;
	sError.clear();
	String ^ sExceptionError;
	Workspace ^ TempWorkspace;
	WorkingFolder ^ MappedFolders;

	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		try
		{
			if (szcServerPath == NULL || szcLocalPath == NULL || szcTargetToAdd == NULL ||
				szcComment == NULL)
			{
				sError.assign("Incorrect parameters was passed");
				enRetv = LibTfsClientResultCode_ErrorNullPtrParameter;
				break;
			}

			VersionControlServer ^ VersionControl = 
				m_ProjectCollection->GetService<VersionControlServer ^>();

			string sGeneratedWorkspaceName = GenerateTempWorkspaceName();

			String ^ sWorkspaceName	= gcnew String(sGeneratedWorkspaceName.c_str());
			String ^ sServerPath = gcnew String (szcServerPath);
			String ^ sLocalPath	= gcnew String (szcLocalPath); //TODO findout does target exist on disk
			String ^ sComment = gcnew String(szcComment);

			string sFullTargetPath(szcLocalPath);
			sFullTargetPath += "\\";
			sFullTargetPath += szcTargetToAdd;

			sFullTargetPath = NormalizePathForTFS(sFullTargetPath);

			if (!(CPlatformUtils::DirectoryExists(sFullTargetPath) ||
				CPlatformUtils::FileExists(sFullTargetPath)))
			{
				sError.assign("Target doesn't exits on local disk");
				enRetv = LibTfsClientResultCode_ErrorInvalidArgument;
				break;
			}

			String ^ sNormalizePathToTarget = gcnew String (sFullTargetPath.c_str());

			TempWorkspace = VersionControl->CreateWorkspace(sWorkspaceName,
				VersionControl->AuthenticatedUser);

			MappedFolders = gcnew WorkingFolder(sServerPath, sLocalPath);

			TempWorkspace->CreateMapping(MappedFolders);

			TempWorkspace->PendAdd(sNormalizePathToTarget, cbRecurcive);

			array<PendingChange ^> ^ Changes = TempWorkspace->GetPendingChanges();

			TempWorkspace->CheckIn(Changes, sComment);

			bRetVal = true;
		}
		catch (Exception ^ eError)
		{
			sExceptionError = eError->Message;
		}
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(bRetVal = false;
		enRetv = LibTfsClientResultCode_ErrorExceptionReceived;
		sError.assign(g_szcManagedCodeException));
	
	TempWorkspace->DeleteMapping(MappedFolders);
	TempWorkspace->Delete();

	return bRetVal;
}

bool CTfsClient::GetItemsByPath(const char * szcPath, const bool cbIsRecursive,
	vector<CItemInfo> & vInfos, LibTfsClientResultCode & enRetv, string & sError)
{
	bool bRes = false;
	sError.clear();
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		VersionControlServer ^ versionControl =
			m_ProjectCollection->GetService<VersionControlServer ^>();
	
		String ^ sPath = gcnew String(szcPath);
		ItemSet ^ itemSet = versionControl->GetItems(sPath,
			cbIsRecursive ? RecursionType::Full : RecursionType::OneLevel);

		array<Item ^> ^ items = itemSet->Items;
		const int ciLength = items->GetLength(0);

		if (ciLength <= 0)
		{
			sError.assign("Required items set is empty");
			enRetv = LibTfsClientResultCode_ErrorObjectNotExists;
			break;
		}

		vInfos.clear();
		vInfos.resize(static_cast<size_t>(ciLength));
		for (int iIndex = 0; iIndex != ciLength ; ++iIndex)
		{
			Item ^ item = items[iIndex];
			CItemInfo & info = vInfos[iIndex];

			// content size
			info.SetContentSize(static_cast<size_t>(item->ContentLength));

			// path
			string sPath;
			ManagedUtils::ConvertSystemStringToStdString(item->ServerItem, sPath);
			info.SetPath(sPath);

			// is directory
			info.SetIsDirectory(item->ItemType == ItemType::Folder);

			vInfos[iIndex] = info;
		}

		bRes = true;
		enRetv = LibTfsClientResultCode_NoError;
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(bRes = false;
		enRetv = LibTfsClientResultCode_ErrorExceptionReceived;
		sError.assign(g_szcManagedCodeException));
	return bRes;
}

bool CTfsClient::GetProjects(vector<string> & vsProjects, LibTfsClientResultCode & enRetv,
	string & sError)
{
	bool bRes = false;
	sError.clear();
	BEGIN_EXCEPTION_SAFE_BLOCK();

	do
	{
		VersionControlServer ^ versionControl =
			m_ProjectCollection->GetService<VersionControlServer ^>();

		array<TeamProject ^> ^ teamProjects = versionControl->GetAllTeamProjects(true);
		const int ciLength = teamProjects->GetLength(0);

		if (ciLength <= 0)
		{
			sError.assign("Required projects set is empty");
			enRetv = LibTfsClientResultCode_ErrorObjectNotExists;
			break;
		}

		vsProjects.clear();
		vsProjects.resize(static_cast<size_t>(ciLength));
		for (int iIndex = 0; iIndex != ciLength ; ++iIndex)
		{
			TeamProject ^ project = teamProjects[iIndex];
			ManagedUtils::ConvertSystemStringToStdString(project->Name, vsProjects[iIndex]);
		}

		bRes = true;
		enRetv = LibTfsClientResultCode_NoError;
	}
	while (false);

	END_EXCEPTION_SAFE_BLOCK(bRes = false;
		enRetv = LibTfsClientResultCode_ErrorExceptionReceived;
		sError.assign(g_szcManagedCodeException));
	return bRes;
}

// TFS incorrect works with slash('/') in local path (with server source control path
//		everything OK)
string CTfsClient::NormalizePathForTFS(const string & csPath)
{
	string sRetPath(csPath);
	string::size_type nPos = 0;

	while ((nPos = sRetPath.find('/', nPos)) != string::npos)
	{
		sRetPath[nPos] = '\\';
	}

	nPos = 1; 
	while((nPos = sRetPath.find("\\\\", nPos)) != string::npos)
	{
		sRetPath.erase(nPos + 1, 1);
	}

	return sRetPath;
}

/*static*/ string CTfsClient::GenerateTempWorkspaceName()
{
	static unsigned int iNameNumber = 0;
	string sTempWorkspaceName(g_szcTempWorkspaceName);
	CPDateTime dtCurrentDateTime = CPlatformUtils::NowLocal();
	sTempWorkspaceName.append(dtCurrentDateTime.Format("[%d%m%Y-%H%M%S(%L)]"));
	sTempWorkspaceName = sTempWorkspaceName + "-" + std::to_string(iNameNumber);
	Atomic::Increment32(&iNameNumber);
	return sTempWorkspaceName;
}

#endif	//#ifndef USE_JNI_TFS_SDK

