﻿#include "StdAfx.h"

#include "libtfsclient/libtfsclientapi.h"
#include "pathutils.h"
#include "platformutils.h"
#include "datetimeutils.h"
#include "atomic_operations.h"
#include "strutils.h"

#ifdef USE_JNI_TFS_SDK

#include "tfsclient_jni.h"

///////////////////////////////////////////////////////////////////////////////////////////////////

const char g_szcEmptyInputError[]	= "Empty input parameter";

const char g_szcServer[] = "SERVER";
const char g_szcLocal[] = "LOCAL";
const char g_szcTempWorkspaceName[] = "TempJDKWorkspace";
const char g_szcErrorMag[] = "Delete temporary Workspace failed";

const char * g_pszcWorkspaceOptionsList[WorkspaceOptionsCount] = 
	{NULL, "NONE", "SET_FILE_TO_CHECKIN"};

const char * g_pszcFileEncodingsList[PendAddFileEncodingsCount] = {NULL,
	"AUTO_DETECT_SPECIAL_VALUE", "AUTOMATICALLY_DETECT", "BINARY", "DEFAULT_TEXT",
	"TEXT_SPECIAL_VALUE", "UTF_16", "UTF_16BE", "UTF_32", "UTF_32BE", "UTF_8"};

const char * g_pszcLockLevelList[PendAddLockLevelsCount] = {NULL, "CHECKIN", "CHECKOUT", "NONE",
	"UNCHANGED"};

const char * g_pszcGetOptionList[PendAddGetOptionsCount] = {NULL, "GET_ALL", "NO_AUTO_RESOLVE",
	"NO_DISK_UPDATE", "NONE", "OVERWRITE", "PREVIEW", "REMAP"};

const char * g_pszcPendChangesOptionList[PendChangesOptionsCount] = {NULL,
	"APPLY_LOCAL_ITEM_EXCLUSIONS", "FORCE_CHECK_OUT_LOCAL_VERSION", "GET_LATEST_ON_CHECKOUT",
	"NONE", "SILENT", "SUPPRESS_ITEM_NOT_FOUND_FAILURES", "TREAT_MISSING_ITEMS_AS_FILES"};



///////////////////////////////////////////////////////////////////////////////////////////////////



bool CTfsJNIClient::Connect(const string & csUrl, const string & csFullName,
	const string & csPassword)
{
	bool bRes = false;

	do
	{
		const bool cbEmptyUrl = csUrl.empty();
		if (cbEmptyUrl || csFullName.empty() || csPassword.empty())
		{
			m_sError.assign(g_szcEmptyInputError);
			if (cbEmptyUrl)	// fatal error
			{
				break;
			}
		}

		if (!CreateTFSConnection(csUrl, csFullName, csPassword))
		{
			string	sError;
			sError.swap(m_sError);
			FormatString(m_sError, "Failed to connect to URI '%s' as '%s' user\nError: %s",
				csUrl.c_str(), csFullName.c_str(), sError.c_str());
			break;
		}

		bRes = true;
	}
	while (false);

	return bRes;
}

bool CTfsJNIClient::Close()
{
	const bool cbRes = (m_joProjectCollection == nullptr) ? false :
		CloseObject(m_joProjectCollection, g_szcProjectCollectionPath);
	m_joProjectCollection = nullptr;

	return cbRes;
}

bool CTfsJNIClient::DownloadItem(const char * szcPath, void * & pContent, size_t & nSize)
{
	bool bRes = false;
	ASSERT(szcPath != NULL);

	do
	{
		string	sItemPath(szcPath);
		nSize = 0;
		if (sItemPath.empty())
		{
			m_sError.assign(g_szcEmptyInputError);
			break;
		}

		if (!DownloadItemFromTFS(sItemPath, pContent, nSize))
		{
			// set error
			nSize = 0;
			break;
		}

		bRes = true;
	}
	while (false);

	return bRes;
}

bool CTfsJNIClient::UploadItemTempWorkspace(const string & csServerPath,
	const string & csLocalPath, const string & csComment, const CPendAdd & cPendAddOptions)
{
	bool bRetValue = false;

	CJNIObjectData jndVersionControlClient(g_szcVersionControlClPath);
	CJNIObjectData jndWorkspace(g_szcWorkspacePath);
	string sTempWorkspaceName;

	do
	{
		//Set VersionControlClient 
		CJNIObjectData	jndProjCollection(g_szcProjectCollectionPath, static_cast<jobject>
			(m_joProjectCollection));
		CJNIInstance<CJNIObjectData> jniVersionCC(g_szcGetVCCMethodName,
			g_szcProjectCollectionPath, &jndVersionControlClient);
		// Set function return type, number of parameters (0), and their types (if any)
		if (!jniVersionCC.SetFunctionSignature(JNIDataType_Object, 0))
		{
			m_sError = jniVersionCC.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIObjectData> jopVersionCC(&jniVersionCC, &jndProjCollection);
		// Find and run method with previously defined parameters
		if (!jopVersionCC.ExecuteMethod(0))
		{
			m_sError = jopVersionCC.GetLatestError();
			break;
		}

		//temp workspace name
		sTempWorkspaceName = GenerateTempWorkspaceName();

		//createWorkspace function
		if (!CreateWorkspace(csServerPath, csLocalPath, sTempWorkspaceName,
				csComment, WorkspaceOption_None, jndVersionControlClient, jndWorkspace))
		{
			string	sError;
			sError.swap(m_sError);
			FormatString(m_sError, "Failed to create temporary workspace.\nError: %s",
				sError.c_str());
			break;
		}

		if (!PendAdd(cPendAddOptions, jndWorkspace))
		{
			string	sError;
			sError.swap(m_sError);
			FormatString(m_sError, "Failed to add pending changes.\nError: %s",
				sError.c_str());
			break;
		}

		if (!CheckIn(csComment, jndWorkspace))
		{
			string	sError;
			sError.swap(m_sError);
			FormatString(m_sError, "Failed to check in changes.\nError: %s",
				sError.c_str());
			break;
		}

		bRetValue = true;
	} 
	while (false);
	
	if (!DeleteWorkspase(jndVersionControlClient, jndWorkspace))	
	{
		string	sError;
		sError.swap(m_sError);
		FormatString(m_sError, "Failed to delete temporary workspace - %s.\nError: %s",
			sTempWorkspaceName.c_str(), sError.c_str());

		bRetValue = false;
	}

	if (!jndVersionControlClient.IsObjectNull())
	{
		CloseObject(static_cast<void *>(jndVersionControlClient.GetJNIObjectData()),
			g_szcVersionControlClPath);

		jndVersionControlClient.SetJNIObjectData(nullptr);
	}

	return bRetValue;
}

bool CTfsJNIClient::UploadItemExistingWorkspace(const string & csWorkspaceName,
	const string & csWorkspaceOwner, const string & csComment, const CPendAdd & cPendAddOptions)
{
	bool bRetValue = false;

	CJNIObjectData	jndVersionControlClient(g_szcVersionControlClPath);

	do
	{
		//Set VersionControlClient 
		CJNIObjectData	jndProjCollection(g_szcProjectCollectionPath, static_cast<jobject>
			(m_joProjectCollection));
		CJNIInstance<CJNIObjectData> jniVersionCC(g_szcGetVCCMethodName,
			g_szcProjectCollectionPath, &jndVersionControlClient);
		// Set function return type, number of parameters (0), and their types (if any)
		if (!jniVersionCC.SetFunctionSignature(JNIDataType_Object, 0))
		{
			m_sError = jniVersionCC.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIObjectData> jopVersionCC(&jniVersionCC, &jndProjCollection);
		// Find and run method with previously defined parameters
		if (!jopVersionCC.ExecuteMethod(0))
		{
			m_sError = jopVersionCC.GetLatestError();
			break;
		}

		CJNIObjectData jndWorkspace(g_szcWorkspacePath);
		if (!GetWorkspace(csWorkspaceName, csWorkspaceOwner, jndVersionControlClient,
			jndWorkspace))
		{
			string	sError;
			sError.swap(m_sError);
			FormatString(m_sError, "Failed to get workspace.\nError: %s",
				sError.c_str());
			break;
		}

		if (!PendAdd(cPendAddOptions, jndWorkspace))
		{
			string	sError;
			sError.swap(m_sError);
			FormatString(m_sError, "Failed to add pending changes.\nError: %s",
				sError.c_str());
			break;
		}

		if (!CheckIn(csComment, jndWorkspace))
		{
			string	sError;
			sError.swap(m_sError);
			FormatString(m_sError, "Failed to check in changes.\nError: %s",
				sError.c_str());
			break;
		}

		bRetValue = true;
	} 
	while (false);

	if (!jndVersionControlClient.IsObjectNull())
	{
		CloseObject(static_cast<void *>(jndVersionControlClient.GetJNIObjectData()),
			g_szcVersionControlClPath);

		jndVersionControlClient.SetJNIObjectData(nullptr);
	}

	return bRetValue;
}

bool CTfsJNIClient::GetItemsByPath(const char * szcPath, const bool cbIsRecursive,
	vector<CItemInfo> & vInfos)
{
	bool bRes = false;
	ASSERT(szcPath != NULL);

	do
	{
		const string csItemPath(szcPath);
		if (csItemPath.empty())
		{
			m_sError.assign(g_szcEmptyInputError);
			break;
		}

		if (!GetItemsByPathFromTFS(csItemPath, cbIsRecursive, vInfos))
		{
			// set error
			break;
		}

		bRes = true;
	}
	while (false);

	return bRes;
}

bool CTfsJNIClient::GetProjects(vector<string> & vsProjects)
{
	bool bRes = false;
	BEGIN_EXCEPTION_SAFE_BLOCK();

	bRes = GetProjectsFromTFS(vsProjects);

	END_EXCEPTION_SAFE_BLOCK(bRes = false);

	return bRes;
}

///////////////////////////////////////////////////////////////////////////////////////////////////

bool CTfsJNIClient::CreateTFSConnection(const string & csUrl, const string & csFullName,
	const string & csPassword)
{
	bool bRetv = false;
//	ASSERT(!csUrl.empty());
//	ASSERT(!csFullName.empty());
//	ASSERT(!csPassword.empty());
	ASSERT(g_pJNIEnvironment != nullptr);

	if (m_joProjectCollection != nullptr)
	{
		CloseObject(m_joProjectCollection, g_szcProjectCollectionPath);
		m_joProjectCollection = nullptr;
	}

	do
	{
		// Constructs new URI object for input URL
		CJNIObjectData	jndObjUri(g_szcJavaURITypeName);
		CJNIInstance<CJNIObjectData> jniUri(g_szcClassConstructorName, g_szcJavaURITypeName,
			&jndObjUri);
				
		// Constructs new 'Credentials' object
		CJNIObjectData	jndObjCreds(g_szcCredentialsPath);
		CJNIInstance<CJNIObjectData> jniCreds(g_szcClassConstructorName, g_szcUPCredentialsPath,
			&jndObjCreds);

		// Constructs new 'TFSTeamProjectCollection' object
		CJNIObjectData	jndProjCollection(g_szcProjectCollectionPath);
		CJNIInstance<CJNIObjectData> jniProjCollection(g_szcClassConstructorName,
			g_szcProjectCollectionPath, &jndProjCollection);

		// Prepare java string actual parameter with necessary URL; 
		// Return values is unimportant since we only converts 'const char *' to 'jstring'
		string	sErr1, sErr2, sErr3;
		CJNIStringData	jniStringUrl(NULL, csUrl, sErr1), jniStringName(NULL, csFullName, sErr2),
			jniStringPwd(NULL, csPassword, sErr3);
		if (!sErr1.empty() || !sErr2.empty() || !sErr3.empty())
		{
			m_sError = sErr1 + sErr2 + sErr3;
			break;
		}

		// Set function (constructor) return type, number of parameters (1),
		// and their type: constructor needs single 'jstring' parameter
		jniUri.SetFunctionSignature(JNIDataType_Void, 1, &jniStringUrl);
		// Set function (constructor) return type, number of parameters (2),
		// and their type: constructor needs two 'jstring' parameters
		jniCreds.SetFunctionSignature(JNIDataType_Void, 2, &jniStringName, &jniStringPwd);

		// Declare data processor classes
		CJNIProcessor<CJNIObjectData> jopUri(&jniUri, NULL), jopCreds(&jniCreds, NULL);
		// Find and run constructors with previously defined parameters for 'Uri' ...
		if (!jopUri.CreateNewObject(1, jniStringUrl.GetJNIObjectData()))
		{
			m_sError = jopUri.GetLatestError();
			break;
		}
		// ... and 'Credentials' objects
		if (!jopCreds.CreateNewObject(2, jniStringName.GetJNIObjectData(),
			jniStringPwd.GetJNIObjectData()))
		{
			m_sError = jopCreds.GetLatestError();
			break;
		}

		// Set function (constructor) return type, number of parameters (2),
		// and their JNI types : (jobject, jobject)
		jniProjCollection.SetFunctionSignature(JNIDataType_Void, 2, &jndObjUri, &jndObjCreds);
		// Use created objects to construct TFSTeamProjectCollection object
		CJNIProcessor<CJNIObjectData> jopProjCollection(&jniProjCollection, NULL);
		// Find and run constructor with previously defined parameters
		if (!jopProjCollection.CreateNewObject(2, jndObjUri.GetJNIObjectData(),
			jndObjCreds.GetJNIObjectData()))
		{
			m_sError = jopProjCollection.GetLatestError();
			break;
		}
		m_joProjectCollection = jndProjCollection.GetJNIObjectData();

		// Look for authentification method address and run it
		CJNIVoidData jndDoAuth;
		CJNIInstance<CJNIVoidData> jniDoAuth(g_szcDoAuthedMethodName, g_szcProjectCollectionPath,
			&jndDoAuth);
		// Set function return type, number of parameters (0), and their type (no one)
		jniDoAuth.SetFunctionSignature(JNIDataType_Void, 0);
		CJNIProcessor<CJNIVoidData> jopDoAuth(&jniDoAuth, &jndProjCollection);
		// Find and run method with previously defined parameters
		if (!jopDoAuth.ExecuteMethod(0))
		{
			m_sError = jopDoAuth.GetLatestError();
			break;
		}

		// Check whether user is authentificated
		CJNIBooleanData jndIsAuth;
		CJNIInstance<CJNIBooleanData> jniIsAuth(g_szcIsAuthedMethodName, g_szcProjectCollectionPath,
			&jndIsAuth);
		// Set function return type, number of parameters (0), and their type (no one)
		jniIsAuth.SetFunctionSignature(JNIDataType_Boolean, 0);
		CJNIProcessor<CJNIBooleanData> jopIsAuth(&jniIsAuth, &jndProjCollection);
		// Find and run method with previously defined parameters
		if (!jopIsAuth.ExecuteMethod(0))
		{
			m_sError = jopIsAuth.GetLatestError();
			break;
		}

		bRetv = true;
	} 
	while (false);

	if (!bRetv && (m_joProjectCollection != nullptr))
	{
		CloseObject(m_joProjectCollection, g_szcProjectCollectionPath);
		m_joProjectCollection = nullptr;
	}

	return bRetv;
}

bool CTfsJNIClient::CloseObject(const void * pcTFSObject2Close, const char * szcObjectPath)
// TFSConnection : close()
// The Closable interface method must be called when this TFSConnection instance is no longer needed
{
	bool bRetv = false;
	ASSERT(szcObjectPath != NULL);

	do
	{
		if (pcTFSObject2Close == nullptr)
		{
			FormatString(m_sError, "Object with address '%s' is already destroyed", szcObjectPath);
		}

		// Set passed class as parent; hope it is of 'jobject' type
		CJNIObjectData	jndObj2Close(szcObjectPath, static_cast<jobject>(const_cast<void *>
			(pcTFSObject2Close)));
		// Create working objec t
		CJNIVoidData	jndClosing;
		CJNIInstance<CJNIVoidData> jniClosing(g_szcCloseConnMethodName, szcObjectPath,
			&jndClosing);
		// Set function return type, number of parameters (0), and their type (no one)
		jniClosing.SetFunctionSignature(JNIDataType_Void, 0);
		CJNIProcessor<CJNIVoidData> jopObj2Close(&jniClosing, &jndObj2Close);
		// Find and run method with previously defined parameters
		if (!jopObj2Close.ExecuteMethod(0))
		{
			m_sError = jopObj2Close.GetLatestError();
			break;
		}

		bRetv = true;
	} 
	while (false);
	
	return bRetv;
}

bool CTfsJNIClient::GetVersionControlObject(CJNIObjectData & jndProjCollection,
	CJNIStringData & jndPath, CJNIObjectData & jndVersionControlClient)
{
	bool bRetv = false;
	
	do
	{
		// Get pointer to 'getVersionControlClient' method
		CJNIInstance<CJNIObjectData> jniVersionCC(g_szcGetVCCMethodName, g_szcProjectCollectionPath,
			&jndVersionControlClient);
		// Set function return type, number of parameters (0), and their types (if any)
		jniVersionCC.SetFunctionSignature(JNIDataType_Object, 0);
		CJNIProcessor<CJNIObjectData> jopVersionCC(&jniVersionCC, &jndProjCollection);
		// Find and run method with previously defined parameters
		if (!jopVersionCC.ExecuteMethod(0))
		{
			m_sError = jopVersionCC.GetLatestError();
			break;
		}

		CJNIBooleanData	jndItemExists;
		// Verify whether the item exists in TFS collection (use 'testItemExist' method)
		CJNIInstance<CJNIBooleanData> jniItemExists(g_szcItemExistsMethodName,
			g_szcVersionControlClPath, &jndItemExists);
		// Set function return type, number of parameters (1), and their types (jstring)
		jniItemExists.SetFunctionSignature(JNIDataType_Boolean, 1, &jndPath);
		CJNIProcessor<CJNIBooleanData> jopItemExists(&jniItemExists, &jndVersionControlClient);
		// Find and run method with previously defined parameters
		if (!jopItemExists.ExecuteMethod(1, jndPath.GetJNIObjectData()))
		{
			m_sError = jopItemExists.GetLatestError();
			break;
		}

		bRetv = true;
	} 
	while (false);

	return bRetv;
}

TFSItemType CTfsJNIClient::GetTFSItemType(CJNIObjectData & jndParentItem,
	CJNIFieldData jndItemTypes[], bool bFileOnly)
{
	TFSItemType eRetv = TFSItemType_Unknown;

	do
	{
		CJNIObjectData	jndItem2Test(g_szcItemTypesPath);
		// Look for actual item type : call ItemType::getItemType() method
		CJNIInstance<CJNIObjectData> jniItem2Test(g_szcGetItemTypeMethodName, g_szcVCCItemPath,
			&jndItem2Test);
		// Set function return type, number of parameters (0), and their types
		jniItem2Test.SetFunctionSignature(JNIDataType_Object, 0);
		CJNIProcessor<CJNIObjectData> jopItem2Test(&jniItem2Test, &jndParentItem);
		// Find and run method with previously defined parameters
		if (!jopItem2Test.ExecuteMethod(0))
		{
			m_sError = jopItem2Test.GetLatestError();
			break;
		}
		
		bool	bIsError = false;
		for (unsigned int uiType = static_cast<unsigned int>(TFSItemType_File);
			uiType < static_cast<unsigned int>(TFSItemTypesCount); ++uiType)
		{
			// Initialize static fileds to compare (if using them for the first time)
			if (jndItemTypes[uiType].IsObjectNull())
			{
				const char *szcItemTypeName = uiType ? g_szcFldrItemTypeFieldName :
					g_szcFileItemTypeFieldName;

				CJNIInstance<CJNIFieldData> jniItemType(szcItemTypeName, g_szcItemTypesPath,
					&jndItemTypes[uiType]);
				// Set static field constructor return type; it has no parameters by default
				jniItemType.SetFunctionSignature(JNIDataType_Object, 0);
				CJNIProcessor<CJNIFieldData> jopItemType(&jniItemType, NULL);
				// Find and run method with previously defined parameters: create new static field
				if (!jopItemType.CreateNewObject(0))
				{
					m_sError = jopItemType.GetLatestError();
					bIsError = true;
					break;
				}
				// 'LatestVersionSpec' static field should be casted to suitable for comparison
				// 'java.lang.Object' parent class
				jndItemTypes[uiType].SetDataTypeSignature(g_szcJavaObjectTypeName);
			}

			// Compare current item type with static one: 
			// use 'boolean ItemType::equals(java.lang.Object obj)
			CJNIBooleanData	jndTypeCompare;
			CJNIInstance<CJNIBooleanData> jniTypeCompare(g_szcEqualsMethodName,
				g_szcItemTypesPath, &jndTypeCompare);
			// Set function return type, number of parameters (1), and their types (jobject)
			jniTypeCompare.SetFunctionSignature(JNIDataType_Boolean, 1, &jndItemTypes[uiType]);
			CJNIProcessor<CJNIBooleanData> jopTypeCompare(&jniTypeCompare, &jndItem2Test);
			// Find and run method with previously defined parameters
			if (!jopTypeCompare.ExecuteMethod(1, jndItemTypes[uiType].GetJNIObjectData()))
			{
				m_sError = jopTypeCompare.GetLatestError();
				bIsError = true;
				break;
			}

			bool bMatch = jndTypeCompare.GetJNIObjectData();
			if (bMatch)	// break if Item types match
			{
				eRetv = static_cast<TFSItemType>(uiType);
				break;
			}
			if (bFileOnly)	// break on the first loop if not 'FILE' type detected
			{
				break;
			}
		}
		if (bIsError)
		{
			break;
		}
	}
	while (false);

	return eRetv;
}

bool CTfsJNIClient::CreateWorkspace(const string & csServerPath, const string & csLocalPath,
	const string & csWorkspaceName, const string & csComment,
	const WorkspaceOption ceWorkspaceOptions, CJNIObjectData & jndVersionControlClient,
	CJNIObjectData & jndOutWorkspace, const bool cbServerLocation /*= true*/)
{
	bool bRetVal = false;

	do
	{
		// WorkingFolders array
		jclass JavaObjectClass = g_pJNIEnvironment->FindClass(g_szcJavaObjectTypeName);
		jobjectArray WorkingFoldersArray = g_pJNIEnvironment->NewObjectArray(1,
			JavaObjectClass, NULL);
		CJNIObjectData jndWorkingFolders(g_szcWorkingFolder,
			WorkingFoldersArray, true);

		// WorkingFolder element
		CJNIStringData jndServerPath(NULL, csServerPath.c_str(), m_sError);
		CJNIStringData jndLocalPath(NULL, csLocalPath.c_str(), m_sError);
		CJNIObjectData jndAddWorkingFolder(g_szcWorkingFolder);
		CJNIInstance<CJNIObjectData> jniAddWorkingFolder(g_szcClassConstructorName,
			g_szcWorkingFolder,	&jndAddWorkingFolder);
		if (!jniAddWorkingFolder.SetFunctionSignature(JNIDataType_Void, 2, &jndServerPath,
			&jndLocalPath))
		{
			m_sError = jniAddWorkingFolder.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIObjectData> jopAddWorkingFolder(&jniAddWorkingFolder,
			&jndAddWorkingFolder);
		if (!jopAddWorkingFolder.CreateNewObject(2, jndServerPath.GetJNIObjectData(),
			jndLocalPath.GetJNIObjectData()))
		{
			m_sError = jopAddWorkingFolder.GetLatestError();
			break;
		}

		// add single element to array
		g_pJNIEnvironment->SetObjectArrayElement(
			static_cast<jobjectArray>(jndWorkingFolders.GetJNIObjectData()), 0,
			jndAddWorkingFolder.GetJNIObjectData());

		CJNIStringData jndWorkSpaceName(NULL, csWorkspaceName.c_str(), m_sError);
		CJNIStringData jndWorkSpaceComment(NULL, csComment.c_str(), m_sError);

		const char * szWorkspaceLocation = cbServerLocation ? g_szcServer : g_szcLocal;

		//WorkspaceLocation enum, createWorkspace function parameter
		CJNIFieldData jndWorkspaceLocation(g_szcWorkspaceLocation);
		CJNIInstance<CJNIFieldData> jniWorkspaceLocation(szWorkspaceLocation,
			g_szcWorkspaceLocation, &jndWorkspaceLocation);
		// Set static field constructor return type; it has no parameters by default
		if (!jniWorkspaceLocation.SetFunctionSignature(JNIDataType_Object, 0))
		{
			m_sError = jniWorkspaceLocation.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIFieldData> jopWorkspaceLocation(&jniWorkspaceLocation, NULL);
		// Find and run method with previously defined parameters: create new static field
		if (!jopWorkspaceLocation.CreateNewObject(0))
		{
			m_sError = jopWorkspaceLocation.GetLatestError();
			break;
		}

		const char * szcWorkspaceOptions = GetEnumValueString<WorkspaceOption,
			WorkspaceOptionsCount, g_pszcWorkspaceOptionsList>(ceWorkspaceOptions);
		if (szcWorkspaceOptions == NULL)
		{
			m_sError = "WorkspaceOptions mode is not set (is NULL)";
			break;
		}

		//WorkspaceOptions enum, createWorkspace function parameter
		CJNIFieldData jndWorkspaceOptions(g_szcWorkspaceOptions);
		CJNIInstance<CJNIFieldData> jniWorkspaceOptions(szcWorkspaceOptions, g_szcWorkspaceOptions,
			&jndWorkspaceOptions);
		// Set static field constructor return type; it has no parameters by default
		if (!jniWorkspaceOptions.SetFunctionSignature(JNIDataType_Object, 0))
		{
			m_sError = jniWorkspaceOptions.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIFieldData> jopWorkspaceOptions(&jniWorkspaceOptions, NULL);
		// Find and run method with previously defined parameters: create new static field
		if (!jopWorkspaceOptions.CreateNewObject(0))
		{
			m_sError = jopWorkspaceOptions.GetLatestError();
			break;
		}

		//execute Workspace createWorkspace(WorkingFolder[] workingFolders,
		//	  java.lang.String workspaceName, java.lang.String comment, WorkspaceLocation location,
		//	  WorkspaceOptions options) 
		CJNIInstance<CJNIObjectData> jniCreateWorkspace(g_szcCreateWorkspace,
			g_szcVersionControlClPath, &jndOutWorkspace);
		if (!jniCreateWorkspace.SetFunctionSignature(JNIDataType_Object, 5, &jndWorkingFolders,
			&jndWorkSpaceName, &jndWorkSpaceComment, &jndWorkspaceLocation, &jndWorkspaceOptions))
		{
			m_sError = jniCreateWorkspace.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIObjectData> jopWorkspace(&jniCreateWorkspace, &jndVersionControlClient);
		if (!jopWorkspace.ExecuteMethod(5, jndWorkingFolders.GetJNIObjectData(),
			jndWorkSpaceName.GetJNIObjectData(), jndWorkSpaceComment.GetJNIObjectData(),
			jndWorkspaceLocation.GetJNIObjectData(), jndWorkspaceOptions.GetJNIObjectData()))
		{
			m_sError = jopWorkspace.GetLatestError();
			break;
		}

		bRetVal = true;

	} 
	while (false);

	return bRetVal;
}

bool CTfsJNIClient::GetWorkspace(const string & csWorkspaceName, const string & csWorkspaceOwner,
	CJNIObjectData & jndVersionControlClient, CJNIObjectData & jndOutWorkspace)
{
	bool bRetVal = false;

	do
	{
		CJNIStringData jndWorkSpaceName(NULL, csWorkspaceName.c_str(), m_sError);
		CJNIStringData jndWorkSpaceOwner(NULL, csWorkspaceOwner.c_str(), m_sError);
		if (jndWorkSpaceName.IsObjectNull() || jndWorkSpaceOwner.IsObjectNull())
		{
			break;
		}

		//execute Workspace getWorkspace(java.lang.String workspaceName,
		//			java.lang.String workspaceOwner)
		CJNIInstance<CJNIObjectData> jniGetWorkSpace(g_szcGetWorkspaceMethodName,
			g_szcVersionControlClPath, &jndOutWorkspace);
		if (!jniGetWorkSpace.SetFunctionSignature(JNIDataType_Object, 2, &jndWorkSpaceName,
			&jndWorkSpaceOwner))
		{
			m_sError = jniGetWorkSpace.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIObjectData> jopGetWorkSpace(&jniGetWorkSpace, &jndVersionControlClient);
		if (!jopGetWorkSpace.ExecuteMethod(2, jndWorkSpaceName.GetJNIObjectData(),
			jndWorkSpaceOwner.GetJNIObjectData()))
		{
			m_sError = jopGetWorkSpace.GetLatestError();
			break;
		}

		if (jndOutWorkspace.IsObjectNull())
		{
			m_sError = "Workspace object is not set";
			break;
		}

		bRetVal = true;
	}
	while (false);

	return bRetVal;
}

bool CTfsJNIClient::PendAdd(const CPendAdd & cPendAddOptions, CJNIObjectData & jndWorkspace)
{
	bool bRetVal = false;
	
	do
	{
		//parameters for Workspace.pendAdd method
		//string array
		CJNIObjectData jndLocalDiskPaths(g_szcJavaStringTypeName,
			g_pJNIEnvironment->NewObjectArray(static_cast<jsize>(1),
			g_pJNIEnvironment->FindClass(g_szcJavaStringTypeName), NULL),
			true);

		//add elements to array
		CJNIStringData	jndTargetPath;
		jndTargetPath.ConvertJNIStringFrom(cPendAddOptions.sPaths, m_sError);
			
		g_pJNIEnvironment->SetObjectArrayElement(
			static_cast<jobjectArray>(jndLocalDiskPaths.GetJNIObjectData()),
			static_cast<jsize>(0), jndTargetPath.GetJNIObjectData());

		CJNIBooleanData jndRecurcive(true);

		const char * szcFileEncoding = GetEnumValueString<PendAddFileEncoding,
			PendAddFileEncodingsCount, g_pszcFileEncodingsList>(cPendAddOptions.eFileEncoding);
		if (szcFileEncoding == NULL)
		{
			m_sError = "File encoding mode is not set";
			break;
		}

		//FileEncoding
		CJNIFieldData jndFileEncodingType(g_szcFileEncodingTypePath);
		CJNIInstance<CJNIFieldData> jniFileEncodingType(szcFileEncoding,
			g_szcFileEncodingTypePath, &jndFileEncodingType);
		// Set static field constructor return type; it has no parameters by default
		if (!jniFileEncodingType.SetFunctionSignature(JNIDataType_Object, 0))
		{
			m_sError = jniFileEncodingType.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIFieldData> jopFileEncodingType(&jniFileEncodingType, NULL);
		// Find and run method with previously defined parameters: create new static field
		if (!jopFileEncodingType.CreateNewObject(0))
		{
			m_sError = jopFileEncodingType.GetLatestError();
			break;
		}

		const char * szcLockLevel = GetEnumValueString<PendAddLockLevel,
			PendAddLockLevelsCount, g_pszcLockLevelList>(cPendAddOptions.eLockLevel);
		if (szcLockLevel == NULL)
		{
			m_sError = "Lock level mode is not set";
			break;
		}

		//LockLevel
		CJNIFieldData jndLockLevelType(g_szcLockLevelTypePath);
		CJNIInstance<CJNIFieldData> jniLockLevelType(szcLockLevel, g_szcLockLevelTypePath,
			&jndLockLevelType);
		// Set static field constructor return type; it has no parameters by default
		if (!jniLockLevelType.SetFunctionSignature(JNIDataType_Object, 0))
		{
			m_sError = jniLockLevelType.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIFieldData> jopLockLevelType(&jniLockLevelType, NULL);
		// Find and run method with previously defined parameters: create new static field
		if (!jopLockLevelType.CreateNewObject(0))
		{
			m_sError = jopLockLevelType.GetLatestError();
			break;
		}

		const char * szcGetOptions = GetEnumValueString<PendAddGetOption,
			PendAddGetOptionsCount, g_pszcGetOptionList>(cPendAddOptions.eGetOptions);
		if (szcGetOptions == NULL)
		{
			m_sError = "Get options mode is not set";
			break;
		}

		//GetOptions
		CJNIFieldData jndGetOptionsType(g_szcGetOptionsTypePath);
		CJNIInstance<CJNIFieldData> jniGetOptionsType(szcGetOptions, g_szcGetOptionsTypePath,
			&jndGetOptionsType);
		// Set static field constructor return type; it has no parameters by default
		if (!jniGetOptionsType.SetFunctionSignature(JNIDataType_Object, 0))
		{
			m_sError = jniGetOptionsType.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIFieldData> jopGetOptionsType(&jniGetOptionsType, NULL);
		// Find and run method with previously defined parameters: create new static field
		if (!jopGetOptionsType.CreateNewObject(0))
		{
			m_sError = jopGetOptionsType.GetLatestError();
			break;
		}

		const char * szcPendChangesOptions = GetEnumValueString<PendChangesOption,
			PendChangesOptionsCount, g_pszcPendChangesOptionList>
			(cPendAddOptions.ePendChangesOptions);
		if (szcPendChangesOptions == NULL)
		{
			m_sError = "Pend changes options mode is not set";
			break;
		}

		//PendChangesOptions
		CJNIFieldData jndPendChangesOptionsType(g_szcPendChangesOptionsTypePath);
		CJNIInstance<CJNIFieldData> jniPendChangesOptionsType(szcPendChangesOptions,
			g_szcPendChangesOptionsTypePath, &jndPendChangesOptionsType);
		// Set static field constructor return type; it has no parameters by default
		if (!jniPendChangesOptionsType.SetFunctionSignature(JNIDataType_Object, 0))
		{
			m_sError = jniPendChangesOptionsType.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIFieldData> jopPendChangesOptionsType(&jniPendChangesOptionsType, NULL);
		// Find and run method with previously defined parameters: create new static field
		if (!jopPendChangesOptionsType.CreateNewObject(0))
		{
			m_sError = jopPendChangesOptionsType.GetLatestError();
			break;
		}

		//execute int pendAdd(java.lang.String[] paths, boolean recursive,
		//	FileEncoding fileEncoding, LockLevel lockLevel, GetOptions getOptions,
		//	PendChangesOptions pendOptions)
		//Ask the server for permission to add file from local working folders.
		CJNIIntData jndPendAddRes(0L);
		CJNIInstance<CJNIIntData> jniPendAdd(g_szcPendAddMethodName, g_szcWorkspacePath,
			&jndPendAddRes);
		if (!jniPendAdd.SetFunctionSignature(JNIDataType_Int, 6, &jndLocalDiskPaths, &jndRecurcive,
			&jndFileEncodingType, &jndLockLevelType, &jndGetOptionsType,
			&jndPendChangesOptionsType))
		{
			m_sError = jniPendAdd.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIIntData> jopPendAdd(&jniPendAdd, &jndWorkspace);
		if (!jopPendAdd.ExecuteMethod(6, jndLocalDiskPaths.GetJNIObjectData(),
			jndRecurcive.GetJNIObjectData(), jndFileEncodingType.GetJNIObjectData(),
			jndLockLevelType.GetJNIObjectData(), jndGetOptionsType.GetJNIObjectData(),
			jndPendChangesOptionsType.GetJNIObjectData()))
		{
			m_sError = jopPendAdd.GetLatestError();
			break;
		}

		bRetVal = true;
	} 
	while (false);

	return bRetVal;
}

bool CTfsJNIClient::CheckIn(const string & csComment, CJNIObjectData & jndWorkspace)
{
	bool bRetVal = false;

	do
	{
		//execute PendingSet getPendingChanges() method
		CJNIObjectData jndPendingSet(g_szcPendingSetTypePath);
		CJNIInstance<CJNIObjectData> jniPendingSet(g_szcGetPendingChangesMethodName,
			g_szcWorkspacePath, &jndPendingSet);
		if (!jniPendingSet.SetFunctionSignature(JNIDataType_Object, 0))
		{
			m_sError = jniPendingSet.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIObjectData> jopPendingSet(&jniPendingSet, &jndWorkspace);
		if (!jopPendingSet.ExecuteMethod(0))
		{
			m_sError = jopPendingSet.GetLatestError();
			break;
		}

		//get PendingChanges[] using PendingSet.getPendingChanges() method
		CJNIObjectData jndPendingChange(g_szcPendingChangeTypePath,	true);
		CJNIInstance<CJNIObjectData> jniPendingChange(g_szcGetPendingChangesMethodName,
			g_szcPendingSetTypePath, &jndPendingChange);
		if (!jniPendingChange.SetFunctionSignature(JNIDataType_Object, 0))
		{
			m_sError = jniPendingChange.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIObjectData> jopPendingChange(&jniPendingChange, &jndPendingSet);
		if (!jopPendingChange.ExecuteMethod(0))
		{
			m_sError = jopPendingChange.GetLatestError();
			break;
		}

		//execute - int Workspace.checkIn(PendingChange[] changes, java.lang.String comment) method
		CJNIIntData jndCheckIn(0L);
		CJNIStringData jndComment(NULL, csComment, m_sError);

		CJNIInstance<CJNIIntData> jniCheckIn(g_szcCheckInMethodName, g_szcWorkspacePath,
			&jndCheckIn);
		if (!jniCheckIn.SetFunctionSignature(JNIDataType_Int, 2, &jndPendingChange, &jndComment))
		{
			m_sError = jniCheckIn.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIIntData> jopCheckIn(&jniCheckIn, &jndWorkspace);
		if (!jopCheckIn.ExecuteMethod(2, jndPendingChange.GetJNIObjectData(),
			jndComment.GetJNIObjectData()))
		{
			m_sError = jopCheckIn.GetLatestError();
			break;
		}

		bRetVal = true;
	} 
	while (false);

	return bRetVal;
}

bool CTfsJNIClient::DeleteWorkspase(CJNIObjectData & jndVersionControlClient,
	CJNIObjectData & jndWorkspace)
{
	bool bRetVal = false;

	do
	{
		if (jndWorkspace.IsObjectNull())
		{
			m_sError = "Workspace object is not set";
			break;
		}

		//execute void deleteWorkspace(Workspace workspace) function
		CJNIVoidData jndDeleteWorkSpace;
		CJNIInstance<CJNIVoidData> jniDeleteWorkSpace(g_szcDeleteWorkspaceMethodName,
			g_szcVersionControlClPath, &jndDeleteWorkSpace);
		if (!jniDeleteWorkSpace.SetFunctionSignature(JNIDataType_Void, 1, &jndWorkspace))
		{
			m_sError = jniDeleteWorkSpace.GetLatestError();
			break;
		}

		CJNIProcessor<CJNIVoidData> jopDeleteWorkSpace(&jniDeleteWorkSpace,
			&jndVersionControlClient);
		if (!jopDeleteWorkSpace.ExecuteMethod(1, jndWorkspace.GetJNIObjectData()))
		{
			m_sError = jopDeleteWorkSpace.GetLatestError();
			break;
		}

		bRetVal = true;

	} 
	while (false);

	return bRetVal;
}

bool CTfsJNIClient::DownloadItemFromTFS(const string & csItemPath, void * & pContent,
	size_t & nContSize)
{
	bool bRetv = false;
	ASSERT(m_joProjectCollection != nullptr);
	ASSERT(pContent == NULL);

	nContSize = 0U;
	CJNIObjectData	jndVersionControlClient(g_szcVersionControlClPath);

	do
	{
		// Convert input path to 'jstring'
		CJNIStringData	jndItemPath(NULL, csItemPath, m_sError);
		if (!m_sError.empty())
		{
			break;
		}

		// Set stored 'ProjectCollection' class as parent
		CJNIObjectData	jndProjCollection(g_szcProjectCollectionPath, static_cast<jobject>
			(m_joProjectCollection));
		if (!GetVersionControlObject(jndProjCollection, jndItemPath, jndVersionControlClient))
		{
			break;
		}

		// Download necessary item ('getItem' method): Item getItem(java.lang.String path,
		//	 VersionSpec version, int deletionID, boolean includeDownloadInfo)
		// Prepare 'LatestVersionSpec' static field 'INSTANCE' since 'VersionSpec' is abstract class
		CJNIFieldData jndVersionSpec(g_szcLtstVersionSpecPath);
		CJNIInstance<CJNIFieldData> jniVersionSpec(g_szcVersionSpecFieldName, 
			g_szcLtstVersionSpecPath, &jndVersionSpec);
		// Set static field constructor return type; it has no parameters by default
		jniVersionSpec.SetFunctionSignature(JNIDataType_Object, 0);
		CJNIProcessor<CJNIFieldData> jopVersionSpec(&jniVersionSpec, NULL);
		// Find and run method with previously defined parameters: create new static field
		if (!jopVersionSpec.CreateNewObject(0))
		{
			m_sError = jopVersionSpec.GetLatestError();
			break;
		}

		// Prepare the rest parameters for 'getItem' call...
		CJNIIntData		jndDeletionID(0L);
		CJNIBooleanData jndDownloadInfo(true);
		// ...and resulting object
		CJNIObjectData	jndGetItem(g_szcVCCItemPath);
		// 'LatestVersionSpec' static field should be casted to parent 'VersionSpec' abstract class
		jndVersionSpec.SetDataTypeSignature(g_szcVersionSpecPath);
		CJNIInstance<CJNIObjectData> jniGetItem(g_szcGetItemMethodName, g_szcVersionControlClPath,
			&jndGetItem);
		// Set function return type, number of parameters (4), and their types
		jniGetItem.SetFunctionSignature(JNIDataType_Object, 4, &jndItemPath, &jndVersionSpec,
			&jndDeletionID, &jndDownloadInfo);
		CJNIProcessor<CJNIObjectData> jopGetItem(&jniGetItem, &jndVersionControlClient);
		// Find and run method with previously defined parameters
		if (!jopGetItem.ExecuteMethod(4, jndItemPath.GetJNIObjectData(),
			jndVersionSpec.GetJNIObjectData(), jndDeletionID.GetJNIObjectData(),
			jndDownloadInfo.GetJNIObjectData()))
		{
			m_sError = jopGetItem.GetLatestError();
			break;
		}

		// Test whether there are valid file by given path 'csItemPath'; 
		CJNIFieldData	jndItemTypes[TFSItemTypesCount] =
			{ CJNIFieldData(g_szcItemTypesPath), CJNIFieldData(g_szcItemTypesPath) };
		TFSItemType eItemType = GetTFSItemType(jndGetItem, jndItemTypes, true);
		// Verify whether the requested item is a file
		if (m_sError.empty() && (eItemType != TFSItemType_File))
		{
			FormatString(m_sError, "Cannot download requested item '%s' since it is not file",
				csItemPath.c_str());
			break;
		}

		// Look for actual file (item) length: long item::getContentLength()
		CJNILongData jndItemLen(-1L);
		CJNIInstance<CJNILongData> jniItemLen(g_szcGetContLenMethodName, g_szcVCCItemPath,
			&jndItemLen);
		// Set function return type, number of parameters (0), and their types (if any)
		jniItemLen.SetFunctionSignature(JNIDataType_Long, 0);
		CJNIProcessor<CJNILongData> jopItemLen(&jniItemLen, &jndGetItem);
		// Find and run method with previously defined parameters
		if (!jopItemLen.ExecuteMethod(0))
		{
			m_sError = jopItemLen.GetLatestError();
			break;
		}
		long lItemSize = static_cast<long>(jndItemLen.GetJNIObjectData());

		// Create 'DownloadURL' object to correctly initialize 'DownloadSpec' object
		// java.lang.String item::getDownloadURL()
		CJNIStringData jndDownloadUrl;
		CJNIInstance<CJNIStringData> jniDownloadUrl(g_szcGetDLUrlMethodName, g_szcVCCItemPath,
			&jndDownloadUrl);
		// Set function return type, number of parameters (0), and their types (if any)
		jniDownloadUrl.SetFunctionSignature(JNIDataType_String, 0);
		CJNIProcessor<CJNIStringData> jopDownloadUrl(&jniDownloadUrl, &jndGetItem);
		// Find and run method with previously defined parameters
		if (!jopDownloadUrl.ExecuteMethod(0))
		{
			m_sError = jopDownloadUrl.GetLatestError();
			break;
		}
		////////////////////////////////////////////////////////////////////////////////////////////
		// Compare 'jndItemPath' and 'jndDownloadUrl' - do we need to call 'getDownloadURL'
		//	= > Yep; quite different values :(
		////////////////////////////////////////////////////////////////////////////////////////////


		// Set 'jint' input parameter
		if ((lItemSize > TO_STRING_BUFFER_SIZE) || (lItemSize <= 0))
		{
			lItemSize = TO_STRING_BUFFER_SIZE;
		}
		CJNIIntData jndItemSize(lItemSize);
		// Find object 'ByteArrayOutputStream' constructor
		CJNIObjectData jndByteArrayOutputStream(g_szcJavaBAOutputStreamName);
		CJNIInstance<CJNIObjectData> jniByteArrayOutputStream(g_szcClassConstructorName,
			g_szcJavaBAOutputStreamName, &jndByteArrayOutputStream);
		// Set function return type, number of parameters (0), and their types (if any)
		jniByteArrayOutputStream.SetFunctionSignature(JNIDataType_Void, 1, &jndItemSize);
		CJNIProcessor<CJNIObjectData> jopByteArrayOutputStream(&jniByteArrayOutputStream, NULL);
		// Find and run method with previously defined parameters
		if (!jopByteArrayOutputStream.CreateNewObject(1, jndItemSize.GetJNIObjectData()))
		{
			m_sError = jopByteArrayOutputStream.GetLatestError();
			break;
		}

		// Prepare more data for 'downloadFileToStream': boolean 'autoGunzip' parameter set to true
		CJNIBooleanData jndAutoGunzip(true);
		// Reserve also abstract parent data object
		CJNIObjectData jndOutputStream(g_szcJavaOutputStreamName);
		// Find object 'DownloadSpec' constructor
		CJNIObjectData jndDownloadSpec(g_szcDownloadSpecPath);
		CJNIInstance<CJNIObjectData> jniDownloadSpec(g_szcClassConstructorName,
			g_szcDownloadSpecPath, &jndDownloadSpec);
		// Set function return type, number of parameters (0), and their types (if any)
		jniDownloadSpec.SetFunctionSignature(JNIDataType_Void, 1, &jndDownloadUrl);
		CJNIProcessor<CJNIObjectData> jopDownloadSpec(&jniDownloadSpec, NULL);
		// Find and run method with previously defined parameters
		if (!jopDownloadSpec.CreateNewObject(1, jndDownloadUrl.GetJNIObjectData()))
		{
			m_sError = jopDownloadSpec.GetLatestError();
			break;
		}

		// Prepare call for 'downloadFileToStream' method
		CJNIVoidData jndFile2Stream;
		CJNIInstance<CJNIVoidData> jniFile2Stream(g_szcDownLoadItemMethodName,
			g_szcVersionControlClPath, &jndFile2Stream);
		// Set function return type, number of parameters (0), and their types (if any)
		jniFile2Stream.SetFunctionSignature(JNIDataType_Void, 3, &jndDownloadSpec, &jndOutputStream,
			&jndAutoGunzip);
		CJNIProcessor<CJNIVoidData> jopFile2Stream(&jniFile2Stream, &jndVersionControlClient);
		// Find and run method with previously defined parameters
		if (!jopFile2Stream.ExecuteMethod(3, jndDownloadSpec.GetJNIObjectData(),
			jndByteArrayOutputStream.GetJNIObjectData(), jndAutoGunzip.GetJNIObjectData()))
		{
			m_sError = jopFile2Stream.GetLatestError();
			break;
		}

		// Prepare call for 'toString' method: String ByteArrayOutputStream::toString()
		CJNIStringData jndToString;
		CJNIInstance<CJNIStringData> jniToString(g_szcToStringMethodName,
			g_szcJavaBAOutputStreamName, &jndToString);
		// Set function return type, number of parameters (0), and their types (if any)
		jniToString.SetFunctionSignature(JNIDataType_String, 0);
		CJNIProcessor<CJNIStringData> jopToString(&jniToString, &jndByteArrayOutputStream);
		// Find and run method with previously defined parameters
		if (!jopToString.ExecuteMethod(0))
		{
			m_sError = jopToString.GetLatestError();
			break;
		}

		// Prepare call for 'length' method: int String::length()
		CJNIIntData jndStrLen(-1L);
		CJNIInstance<CJNIIntData> jniStrLen(g_szcStrLengthMethodName,
			g_szcJavaStringTypeName, &jndStrLen);
		// Set function return type, number of parameters (0), and their types (if any)
		jniStrLen.SetFunctionSignature(JNIDataType_Int, 0);
		CJNIProcessor<CJNIIntData, CJNIStringData> jopStrLen(&jniStrLen, &jndToString);
		// Find and run method with previously defined parameters
		if (!jopStrLen.ExecuteMethod(0))
		{
			m_sError = jopStrLen.GetLatestError();
			break;
		}

		// Got content length and reserve enough memory
		nContSize = static_cast<size_t>(jndStrLen.GetJNIObjectData());
		void * pLocal = malloc(nContSize + 1);	// for trailing '\0'
		if (pLocal == NULL)
		{
			// add error
			nContSize = 0U;
			break;
		}

		// Convert content from UTF
		bool bConverted = JavaToConstChar(jndToString.GetJNIObjectData(),
			static_cast<unsigned int>(nContSize), static_cast<char *>(pLocal));
		if (!bConverted)
		{
			free(pLocal);
			nContSize = 0U;
			break;
		}

		// Fill out input pointer
		pContent = pLocal;
		bRetv = true;
	} 
	while (false);

	// Closable object, must be closed
	if (!jndVersionControlClient.IsObjectNull())
	{
		CloseObject(static_cast<void *>(jndVersionControlClient.GetJNIObjectData()),
			g_szcVersionControlClPath);
		jndVersionControlClient.SetJNIObjectData(nullptr);
	}

	return bRetv;
}

bool CTfsJNIClient::GetItemsByPathFromTFS(const string & csItemPath, const bool cbIsRecursive,
	vector<CItemInfo> & vInfos)
{
	bool bRetv = false;
	ASSERT(!csItemPath.empty());
	ASSERT(m_joProjectCollection != nullptr);

	vInfos.clear();
	CJNIObjectData	jndVersionControlClient(g_szcVersionControlClPath);
	
	do
	{
		// Convert input path to Item 'jstring'
		CJNIStringData	jndItemPath(NULL, csItemPath, m_sError);
		if (!m_sError.empty())
		{
			break;
		}
		// Set stored 'ProjectCollection' class as parent
		CJNIObjectData	jndProjCollection(g_szcProjectCollectionPath, static_cast<jobject>
			(m_joProjectCollection));
		if (!GetVersionControlObject(jndProjCollection, jndItemPath, jndVersionControlClient))
		{
			break;
		}

		// Build obligatory 'RecursionType' static object, either 'FULL' or 'ONE_LEVEL'
		CJNIFieldData jndRecursionType(g_szcRecursionTypePath);
		CJNIInstance<CJNIFieldData> jniRecursionType(cbIsRecursive ? g_szcRecursionOnFieldName :
			g_szcRecursionOffFieldName, g_szcRecursionTypePath, &jndRecursionType);
		// Set static field constructor return type; it has no parameters by default
		jniRecursionType.SetFunctionSignature(JNIDataType_Object, 0);
		CJNIProcessor<CJNIFieldData> jopRecursionType(&jniRecursionType, NULL);
		// Find and run method with previously defined parameters: create new static field
		if (!jopRecursionType.CreateNewObject(0))
		{
			m_sError = jopRecursionType.GetLatestError();
			break;
		}

		// Get 'ItemSet' object: 
		//	ItemSet VersionControlClient::getItems(java.lang.String path, RecursionType recursion)
		CJNIObjectData jndGetItems(g_szcItemSetPath);
		CJNIInstance<CJNIObjectData> jniGetItems(g_szcGetItemsMethodName, g_szcVersionControlClPath,
			&jndGetItems);
		// Set function return type, number of parameters (2), and their types
		jniGetItems.SetFunctionSignature(JNIDataType_Object, 2, &jndItemPath, &jndRecursionType);
		CJNIProcessor<CJNIObjectData> jopGetItems(&jniGetItems, &jndVersionControlClient);
		// Find and run method with previously defined parameters
		if (!jopGetItems.ExecuteMethod(2, jndItemPath.GetJNIObjectData(),
			jndRecursionType.GetJNIObjectData()))
		{
			m_sError = jopGetItems.GetLatestError();
			break;
		}

		// Gets a copy of the items, 'Item' array as:  Item[] ItemSet::getItems()
		CJNIObjectData jndGetItemsArray(g_szcVCCItemPath, true);
		CJNIInstance<CJNIObjectData> jniGetItemsArray(g_szcGetItemsMethodName, g_szcItemSetPath,
			&jndGetItemsArray);
		// Set function return type, number of parameters (0), and their types (if any)
		jniGetItemsArray.SetFunctionSignature(JNIDataType_Object, 0);
		CJNIProcessor<CJNIObjectData> jopGetItemsArray(&jniGetItemsArray, &jndGetItems);
		// Find and run method with previously defined parameters
		if (!jopGetItemsArray.ExecuteMethod(0))
		{
			m_sError = jopGetItemsArray.GetLatestError();
			break;
		}
		// Estimate size of resulting array
		const unsigned int cuiArrayLength = GetJNIArrayLength<CJNIObjectData>(jndGetItemsArray);

		// Prepare to get current Item length: long Item::getContentLength() ...
		CJNILongData jndNextItemLen(-1);
		CJNIInstance<CJNILongData> jniNextItemLen(g_szcGetContLenMethodName, g_szcVCCItemPath,
			&jndNextItemLen);
		// Set function return type, number of parameters (0), and their types (if any)
		jniNextItemLen.SetFunctionSignature(JNIDataType_Long, 0);

		// ... and java.lang.String Item::getServerItem()
		CJNIStringData jndNextItemName;
		CJNIInstance<CJNIStringData> jniNextItemName(g_szcGetSrvItemMethodName, g_szcVCCItemPath,
			&jndNextItemName);
		// Set function return type, number of parameters (0), and their types (if any)
		jniNextItemName.SetFunctionSignature(JNIDataType_String, 0);

		// Next object in resulting array (jndGetItemsArray)
		CJNIObjectData jndNextItem(g_szcVCCItemPath);

		// Static fields to compare item types		
		CJNIFieldData	jndStaticTypes[TFSItemTypesCount] =
			{ CJNIFieldData(g_szcItemTypesPath), CJNIFieldData(g_szcItemTypesPath) };

		// Reserve vector of sufficient enough size
		vInfos.resize(cuiArrayLength);

		// Loop on found TFS Items
		bool	bIsError = false;
		for (unsigned int uiCount = 0; uiCount < cuiArrayLength; ++uiCount)
		{
			CItemInfo & ItInfo = vInfos[uiCount];

			do
			{
				bIsError = !GetJNIArrayNextObject<CJNIObjectData>(uiCount, jndGetItemsArray,
					jndNextItem);
				if (bIsError)
				{
					FormatString(m_sError, "Cannot retrieve %u-th element from array of %u objects",
						uiCount, cuiArrayLength);
					break;
				}

				// Get Item type (actually folder or not folder), and save it
				TFSItemType eItemType = GetTFSItemType(jndNextItem, jndStaticTypes, false);
				// Root folder being resolved as 'unknown' type, we should detect directory like:
				ItInfo.SetIsDirectory(eItemType != TFSItemType_File);

				// Call 'getContentLength()' method
				CJNIProcessor<CJNILongData> jopNextItemLen(&jniNextItemLen, &jndNextItem);
				// Find and run method with previously defined parameters
				if (!jopNextItemLen.ExecuteMethod(0))
				{
					m_sError = jopNextItemLen.GetLatestError();
					break;
				}
				ItInfo.SetContentSize(static_cast<long>(jndNextItemLen.GetJNIObjectData()));

				// Call 'getServerItem()' method 
				CJNIProcessor<CJNIStringData> jopNextItemName(&jniNextItemName, &jndNextItem);
				// Find and run method with previously defined parameters
				if (!jopNextItemName.ExecuteMethod(0))
				{
					m_sError = jopNextItemName.GetLatestError();
					break;
				}

				string	sItemName;
				JavaToStdString(static_cast<jstring>(jndNextItemName.GetJNIObjectData()), 0,
					sItemName);
				ItInfo.SetPath(sItemName);
			}
			while (false);

			if (bIsError)
			{
				break;
			}
			vInfos[uiCount] = ItInfo;
		}

		if (bIsError)
		{
			break;
		}
		bRetv = true;
	} 
	while (false);

	// Closable object, must be closed
	if (!jndVersionControlClient.IsObjectNull())
	{
		CloseObject(static_cast<void *>(jndVersionControlClient.GetJNIObjectData()),
			g_szcVersionControlClPath);
		jndVersionControlClient.SetJNIObjectData(nullptr);
	}

	return bRetv;
}

// TFS incorrect works with slash('/') in local path (with server source control path
//		everything OK)
string CTfsJNIClient::NormalizePathForTFS(const string & csPath)
{
	string sRetPath(csPath);
	string::size_type nPos = 0;

	while ((nPos = sRetPath.find('/', nPos)) != string::npos)
	{
		sRetPath[nPos] = '\\';
	}

	nPos = 1; 
	while((nPos = sRetPath.find("\\\\", nPos)) != string::npos)
	{
		sRetPath.erase(nPos + 1, 1);
	}

	return sRetPath;
}

bool CTfsJNIClient::GetProjectsFromTFS(vector<string> & vsProjects)
{
	bool bRetv = false;
	ASSERT(m_joProjectCollection != nullptr);

	vsProjects.clear();
	do
	{
		// Set stored 'ProjectCollection' class as parent
		CJNIObjectData	jndProjCollection(g_szcProjectCollectionPath, static_cast<jobject>
			(m_joProjectCollection));

		CJNIBooleanData jndRefresh(true);
		// Put path to interface class here in order to build correct method signature
		CJNIObjectData	jndObjectName(g_szcIProjCollCatalogPath);
		CJNIInstance<CJNIObjectData> jniObjectName(g_szcGetCollEntityMethodName,
			g_szcProjectCollectionPath, &jndObjectName);
		// Function 'ProjectCollectionEntity TFSTeamProjectCollection::
		// getTeamProjectCollectionEntity(boolean refresh)' return type,
		// number of parameters (1), and their types
		jniObjectName.SetFunctionSignature(JNIDataType_String, 1, &jndRefresh);
		//jniObjectName.SetFunctionSignature(JNIDataType_String, 1, jndRefresh);
		// Call 'getTeamProjectCollectionEntity()' method 
		CJNIProcessor<CJNIObjectData> jopObjectName(&jniObjectName, &jndProjCollection);
		// Find and run method with previously defined parameters
		if (!jopObjectName.ExecuteMethod(1, jndRefresh.GetJNIObjectData()))
		{
			m_sError = jopObjectName.GetLatestError();
			break;
		}

		// Get pointer to 'TeamProjectEntity[] ProjectCollectionEntity::getTeamProjects()' method
		// Set interface path here
		CJNIObjectData jndProjEntities(g_szcITeamProjEntityPath, true);
		CJNIInstance<CJNIObjectData> jniProjEntities(g_szcGetTeamProjsMethodName,
			g_szcProjCollCatalogEnPath, &jndProjEntities);
		// Set function return type, number of parameters (0), and their types (if any)
		jniProjEntities.SetFunctionSignature(JNIDataType_Object, 0);
		CJNIProcessor<CJNIObjectData> jopProjEntities(&jniProjEntities, &jndObjectName);
		// Find and run method with previously defined parameters
		if (!jopProjEntities.ExecuteMethod(0))
		{
			m_sError = jopProjEntities.GetLatestError();
			break;
		}
		// Estimate size of resulting array:
		const unsigned int cuiArrayLength = GetJNIArrayLength<CJNIObjectData>(jndProjEntities);

		// Prepare to call 'java.lang.String TeamProjectCatalogEntity::getProjectName()'
		CJNIStringData jndNextProjName;
		CJNIInstance<CJNIStringData> jniNextProjName(g_szcGetProjNameMethodName,
			g_szcTeamProjCatalogEnPath, &jndNextProjName);
		// Set function return type, number of parameters (0), and their types (if any)
		jniNextProjName.SetFunctionSignature(JNIDataType_String, 0);
		// Next object in resulting array (jndGetItemsArray)
		CJNIObjectData jndNextProject(g_szcITeamProjEntityPath);

		// Reserve vector of sufficient enough size
		vsProjects.resize(cuiArrayLength);
		// Loop on found TFS Items
		bool bIsError = false;
		for (unsigned int uiCount = 0; uiCount < cuiArrayLength; ++uiCount)
		{
			do
			{
				bIsError = !GetJNIArrayNextObject<CJNIObjectData>(uiCount, jndProjEntities,
					jndNextProject);
				if (bIsError)
				{
					FormatString(m_sError, "Cannot retrieve %u-th element from array of %u objects",
						uiCount, cuiArrayLength);
					break;
				}

				// Call 'java.lang.String getProjectName()' method 
				CJNIProcessor<CJNIStringData> jopNextProjName(&jniNextProjName, &jndNextProject);
				// Find and run method with previously defined parameters
				if (!jopNextProjName.ExecuteMethod(0))
				{
					m_sError = jopNextProjName.GetLatestError();
					break;
				}
				JavaToStdString(static_cast<jstring>(jndNextProjName.GetJNIObjectData()), 0,
					vsProjects[static_cast<unsigned int>(uiCount)]);
			}
			while (false);
		}

		if (bIsError)
		{
			break;
		}
		bRetv = true;
	} 
	while (false);

	return bRetv;
}

////////////////////////////////////////////////////////////////////////////////////////////////////

bool CTfsJNIClient::JavaToStdString(jstring jsInput, const unsigned int cuiSize,
	std::string & sOutput) const
{
	sOutput.clear();
    jboolean jbConverted = 0;
    const char *pUTFChars = g_pJNIEnvironment->GetStringUTFChars(jsInput, &jbConverted);

	if (jbConverted && (pUTFChars != NULL))
	{
		if (cuiSize > 0)
		{
			sOutput.assign(pUTFChars, cuiSize);
		}
		else
		{
			sOutput.assign(pUTFChars);
		}
	}
	if (pUTFChars != NULL)
	{
		g_pJNIEnvironment->ReleaseStringUTFChars(jsInput, pUTFChars);
	}

    return jbConverted ? true : false;
}

bool CTfsJNIClient::JavaToConstChar(const jstring jsInput, const unsigned int cuiSize,
	char *szcOutput) const
{
	ASSERT(szcOutput != NULL);

    jboolean jbConverted = 0;
    const char *pUTFChars = g_pJNIEnvironment->GetStringUTFChars(jsInput, &jbConverted);
	
	if (jbConverted && (pUTFChars != NULL) && (cuiSize > 0))
	{
		memcpy(static_cast<void *>(szcOutput), static_cast<void *>(const_cast<char *>(pUTFChars)),
			cuiSize);
		*(szcOutput + cuiSize) = '\0';
	}
	if (pUTFChars != NULL)
	{
		g_pJNIEnvironment->ReleaseStringUTFChars(jsInput, pUTFChars);
	}

    return jbConverted ? true : false;
}

/*static*/ string CTfsJNIClient::GenerateTempWorkspaceName()
{
	static unsigned int iNameNumber = 0;
	string sTempWorkspaceName(g_szcTempWorkspaceName);
	CPDateTime dtCurrentDateTime = CPlatformUtils::NowLocal();
	sTempWorkspaceName.append(dtCurrentDateTime.Format("[%d%m%Y-%H%M%S(%L)]"));
	sTempWorkspaceName = sTempWorkspaceName + "-" + std::to_string(iNameNumber);
	Atomic::Increment32(&iNameNumber);
	return sTempWorkspaceName;
}

#endif	//#ifdef USE_JNI_TFS_SDK
