#ifndef _LIBTFSCLIENT_H__INCLUDED_
#define _LIBTFSCLIENT_H__INCLUDED_

#include "libtfsclient/libtfsclientapi.h"

LINKAGE_TYPE_EXTERNAL_C 
{
LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_BeginItemsEnumeration(
	CLibTfsClientSession * pSession, const char * szcPath, const bool cbRecurcive,
	CLibTfsClientItemsEnumeration * & pEnumeration);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_BeginProjectsEnumeration(
	CLibTfsClientSession * pSession, CLibTfsClientProjectsEnumeration * & pEnumeration);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_CreateAuthSession(const char * szcUrl,
	const char * szcDomain, const char * szcUser, const char * szcPwd,
	CLibTfsClientSession * & pSession, char * & szError);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_CreateSession(const char * szcUrl,
	CLibTfsClientSession * & pSession, char * & szError);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_DestroySession(
	CLibTfsClientSession * & pSession);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_DownloadItem(
	CLibTfsClientSession * pSession, const char * szcPathToItem, void * & pContent,
	size_t & nContent);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_EndItemsEnumeration(
	CLibTfsClientItemsEnumeration * & pEnumeration);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_EndProjectsEnumeration(
	CLibTfsClientProjectsEnumeration * & pEnumeration);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_Finalize();

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_FreeMemory(void * & pMemory);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_GetItemInfo(
	CLibTfsClientItemsEnumeration * pEnumeration, CLibTfsClientItemInfo & itemInfo);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_GetLastError(
	CLibTfsClientSession * pSession, char * & szError);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_GetProjectName(
	CLibTfsClientProjectsEnumeration * pEnumeration, const char * & szcProjectName);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_Initialize(
	const char * szcJvmLibRootPath, const char * szcTfsSdkRootPath, char * & szLogLibsLocationMsg,
	char * & szError);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_MoveToNextItem(
	CLibTfsClientItemsEnumeration * & pEnumeration);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_MoveToNextProject(
	CLibTfsClientProjectsEnumeration * pEnumeration);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_UploadItemUsingTempWorkspace(
	CLibTfsClientSession * pSession, const char * szcServerPath, const char * szcLocalPath,
	const char * szcTargetToAdd, const char * szcComment, const bool cbRecursive,
	const PendAddLockLevel ceLockLevel = PendAddLockLevel_None,
	const PendAddFileEncoding ceFileEncoding = PendAddFileEncoding_AutomaticallyDetect, 
	const PendAddGetOption ceGetOptions = PendAddGetOption_None,
	const PendChangesOption cePendChangesOptions = PendChangesOption_None);

LibTfsClientResultCode LIBTFSCLIENT_STDCALL LibTfsClient_UploadItemUsingExistingWorkspace(
	CLibTfsClientSession * pSession, const char * szcWorkspaceName, const char * szcWorkspaceOwner,
	const char * szcTargetFullPath, const char * szcComment, const bool cbRecursive,
	const PendAddLockLevel ceLockLevel = PendAddLockLevel_None,
	const PendAddFileEncoding ceFileEncoding = PendAddFileEncoding_AutomaticallyDetect,
	const PendAddGetOption ceGetOptions = PendAddGetOption_None,
	const PendChangesOption cePendChangesOptions = PendChangesOption_None);
};

#endif // _LIBTFSCLIENT_H__INCLUDED_
