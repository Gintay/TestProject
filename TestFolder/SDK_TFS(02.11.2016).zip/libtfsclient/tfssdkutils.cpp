#include "StdAfx.h"

#include "libtfsclient/libtfsclientapi.h"

#ifdef USE_JNI_TFS_SDK

#include "common_constants.h"
#include "pathutils.h"
#include "system_utility.h"

#include "tfsclient_jni.h"

////////////////////////////////////////////////////////////////////////////////////////////////////

#define STATIC_SIZE(xArray)				(sizeof((xArray))/sizeof((xArray)[0]))
#define STATIC_ARRAY_SIZE(xArray)		STATIC_SIZE(xArray)

////////////////////////////////////////////////////////////////////////////////////////////////////

#ifdef UNIX
const char g_szcJavaVMLibName[]				= "libjvm.so";
const char g_szcJavaTFSSDKName[]			= "com.microsoft.tfs.sdk-11.0.0.jar";
#else	// WIN32
const char g_szcJavaVMLibName[]				= "jvm.dll";
const char g_szcJavaTFSSDKName[]			= "com.microsoft.tfs.sdk-11.0.0.jar";
#endif // UNIX

const char g_szcWhereNativeFilesAre[]		= "../native/";
const char g_szcWhereTempFilesAre[]			= "tmp/";

const char g_szcJavaUtilityName[]			= "java";
const char g_szcJVMSearchPath[]				= "../lib/amd64/server/";

const char g_szcJavaArchivePattern[]		= "-Djava.class.path=%s";   // where to find java .classes
const char g_szcJavaNativeFilesPattern[]	= "-Dcom.microsoft.tfs.jni.native.base-directory=%s";
const char g_szcMethodParamsPattern[]		= "(%s)%s";
const char g_szcJavaObjectTypePattern[]		= "L%s;";
const char g_szcJavaArrayTypePattern[]		= "[%s";

const char g_szcClassConstructorName[]		= "<init>";
const char g_szcCheckInMethodName[]			= "checkIn";
const char g_szcCloseConnMethodName[]		= "close";
const char g_szcCreateWorkspace[]			= "createWorkspace";
const char g_szcConnectMethodName[]			= "connect";
const char g_szcDeleteWorkspaceMethodName[]	= "deleteWorkspace";
const char g_szcDownLoadItemMethodName[]	= "downloadFileToStream";
const char g_szcDoAuthedMethodName[]		= "ensureAuthenticated";
const char g_szcEqualsMethodName[]			= "equals";
const char g_szcGetContLenMethodName[]		= "getContentLength";
const char g_szcGetDLUrlMethodName[]		= "getDownloadURL";
const char g_szcGetItemTypeMethodName[]		= "getItemType";
const char g_szcGetItemsMethodName[]		= "getItems";
const char g_szcGetItemMethodName[]			= "getItem";
const char g_szcGetProjNameMethodName[]		= "getProjectName";
const char g_szcGetSrvItemMethodName[]		= "getServerItem";
const char g_szcGetTeamProjsMethodName[]	= "getTeamProjects";
const char g_szcGetCollEntityMethodName[]	= "getTeamProjectCollectionEntity";
const char g_szcGetVCCMethodName[]			= "getVersionControlClient";
const char g_szcGetWorkspaceMethodName[]	= "getWorkspace";
const char g_szcIsAuthedMethodName[]		= "hasAuthenticated";
const char g_szcPendAddMethodName[]			= "pendAdd";
const char 
	g_szcGetPendingChangesMethodName[]		= "getPendingChanges";
const char g_szcStrLengthMethodName[]		= "length";
const char g_szcReadMethodName[]			= "read";
const char g_szcItemExistsMethodName[]		= "testItemExists";
const char g_szcToStringMethodName[]		= "toString";
const char g_szcToByteArrayMethodName[]		= "toByteArray";

const char g_szcBeginUploadRequest[]		= "beginUploadRequest";
const char g_szcExecuteUploadRequest[]		= "executeUploadRequest";
const char g_szcFinishUploadRequest[]		= "finishUploadRequest";


const char g_szcJavaOutputStreamName[]		= "java/io/OutputStream";
const char g_szcJavaBAOutputStreamName[]	= "java/io/ByteArrayOutputStream";
const char g_szcJavaObjectTypeName[]		= "java/lang/Object";
const char g_szcJavaStringTypeName[]		= "java/lang/String";
const char g_szcJavaURITypeName[]			= "java/net/URI";

const char g_szcProjCollCatalogEnPath[]		=
	"com/microsoft/tfs/core/clients/framework/configuration/catalog/ProjectCollectionCatalogEntity";
const char g_szcIProjCollCatalogPath[]		=
	"com/microsoft/tfs/core/clients/framework/configuration/entities/ProjectCollectionEntity";
const char g_szcTeamProjCatalogEnPath[]		=
	"com/microsoft/tfs/core/clients/framework/configuration/catalog/TeamProjectCatalogEntity";
const char g_szcITeamProjEntityPath[]		=
	"com/microsoft/tfs/core/clients/framework/configuration/entities/TeamProjectEntity";
const char g_szcConnOptionsPath[]			=
	"com/microsoft/tfs/core/clients/framework/location/ConnectOptions";
const char g_szcDeletedStatePath[]			=
	"com/microsoft/tfs/core/clients/versioncontrol/soapextensions/DeletedState";
const char g_szcVCCItemPath[]				=
	"com/microsoft/tfs/core/clients/versioncontrol/soapextensions/Item";
const char g_szcItemSetPath[]				=
	"com/microsoft/tfs/core/clients/versioncontrol/soapextensions/ItemSet";
const char g_szcItemTypesPath[]				=
	"com/microsoft/tfs/core/clients/versioncontrol/soapextensions/ItemType";
const char g_szcRecursionTypePath[]			=
	"com/microsoft/tfs/core/clients/versioncontrol/soapextensions/RecursionType";
const char g_szcFileEncodingTypePath[]		=
	"com/microsoft/tfs/core/util/FileEncoding";
const char g_szcLockLevelTypePath[]			=
	"com/microsoft/tfs/core/clients/versioncontrol/soapextensions/LockLevel";
const char g_szcGetOptionsTypePath[]		=
	"com/microsoft/tfs/core/clients/versioncontrol/GetOptions";
const char g_szcPendChangesOptionsTypePath[]=
	"com/microsoft/tfs/core/clients/versioncontrol/PendChangesOptions";
const char g_szcPendingSetTypePath[]		=
	"com/microsoft/tfs/core/clients/versioncontrol/soapextensions/PendingSet";
const char g_szcPendingChangeTypePath[]		=
	"com/microsoft/tfs/core/clients/versioncontrol/soapextensions/PendingChange";
const char g_szcDownloadSpecPath[]			=
	"com/microsoft/tfs/core/clients/versioncontrol/specs/DownloadSpec";
const char g_szcLtstVersionSpecPath[]		=
	"com/microsoft/tfs/core/clients/versioncontrol/specs/version/LatestVersionSpec";
const char g_szcVersionSpecPath[]			=
	"com/microsoft/tfs/core/clients/versioncontrol/specs/version/VersionSpec";
const char g_szcVersionControlClPath[]		=
	"com/microsoft/tfs/core/clients/versioncontrol/VersionControlClient";
const char g_szcUPCredentialsPath[]			=
	"com/microsoft/tfs/core/httpclient/UsernamePasswordCredentials";
const char g_szcWorkspacePath[]				=
	"com/microsoft/tfs/core/clients/versioncontrol/soapextensions/Workspace";
const char g_szcWorkingFolder[]				=
	"com/microsoft/tfs/core/clients/versioncontrol/soapextensions/WorkingFolder";
const char g_szcWorkspaceLocation[]			=
	"com/microsoft/tfs/core/clients/versioncontrol/WorkspaceLocation";
const char g_szcWorkspaceOptions[]			=
	"com/microsoft/tfs/core/clients/versioncontrol/WorkspaceOptions";

const char g_szcCredentialsPath[]			= "com/microsoft/tfs/core/httpclient/Credentials";
const char g_szcProjectCollectionPath[]		= "com/microsoft/tfs/core/TFSTeamProjectCollection";
const char g_szcPostMethodPath[]			= "com/microsoft/tfs/core/httpclient/methods/PostMethod";

const char g_szcFileItemTypeFieldName[]		= "FILE";
const char g_szcFldrItemTypeFieldName[]		= "FOLDER";
const char g_szcRecursionOnFieldName[]		= "FULL";
const char g_szcVersionSpecFieldName[]		= "INSTANCE";
const char g_szcRecursionOffFieldName[]		= "ONE_LEVEL";

const char g_szcJavaVoidTypeName[]			= "V";
const char g_szcJavaBoolTypeName[]			= "Z";
const char g_szcJavaByteTypeName[]			= "B";
const char g_szcJavaCharTypeName[]			= "C";
const char g_szcJavaShortTypeName[]			= "S";
const char g_szcJavaIntTypeName[]			= "I";
const char g_szcJavaLongTypeName[]			= "J";
const char g_szcJavaFloatTypeName[]			= "F";
const char g_szcJavaDoubleTypeName[]		= "D";

const char * const g_cszcJNITypeNames[JNIDataTypesCount] =
{
	szcEmptyString,

	g_szcJavaVoidTypeName,
	g_szcJavaBoolTypeName,
	g_szcJavaByteTypeName,
	g_szcJavaCharTypeName,
	g_szcJavaShortTypeName,
	g_szcJavaIntTypeName,
	g_szcJavaLongTypeName,
	g_szcJavaFloatTypeName,
	g_szcJavaDoubleTypeName,

	szcEmptyString,
	szcEmptyString,
	szcEmptyString
};

////////////////////////////////////////////////////////////////////////////////////////////////////
// Exported function(s) description

typedef  jint ( JNICALL *PJVM_CreateJavaVM)(JavaVM **pvm, void **penv, void *args);

PJVM_CreateJavaVM		g_pTFS_CreateJavaVM = NULL;

void ** const g_ppTFSSDKFunctionsAddresses[] =
{
	reinterpret_cast<void **>(&g_pTFS_CreateJavaVM),
};

const char * g_cszTFSSDKFunctionsNames[STATIC_ARRAY_SIZE(g_ppTFSSDKFunctionsAddresses)] =
{ 
	"JNI_CreateJavaVM"
};

////////////////////////////////////////////////////////////////////////////////////////////////////

const char cszPwdFromNameSeparator	= szcSymbolAt[0];
const char cszUrlFromNameSeparator	= szcSymbolPercent[0];

const char szcDisableJITCompile[]	= "-Djava.compiler=NONE";
const char szcPrintMessages2Stdout[]= "-verbose:jni";
const char szcPrintGCMsges2Stdout[]	= "-verbose:gc";
const char szcJavaMemInitHeapSize[]	= "-Xms16m";
const char szcJavaMemMaxHeapSize[]	= "-Xmx128m";	// 32, 40, 48 - possible values

////////////////////////////////////////////////////////////////////////////////////////////////////

void	* g_pJVMLibInstance = NULL;
JavaVM	* g_pJavaVM = nullptr;					// Pointer to the JVM (Java Virtual Machine)
JNIEnv	* g_pJNIEnvironment = nullptr;			// Pointer to native interface
uint32_t  g_uiJNIMinVersion = JNI_VERSION_1_2;	// minimum Java version

////////////////////////////////////////////////////////////////////////////////////////////////////

bool InitializeJVMLibrary(const bool cbExactPath, string & sInstallRoot, string & sError)
// 'sInstallRoot' should be slash-terminated here, may be empty
{
#ifdef LOAD_JVM_LIB

	bool bRetv = false;
	string	sJVMLibPath;

	do
	{
		if (g_pJVMLibInstance != NULL)
		{
			sError.assign("Java Virtual Machine is initialized already");
			break;
		}

		// First, look for the library in passed location if any
		string	sLibLocation;
		if (!sInstallRoot.empty())
		{
			sJVMLibPath.assign(sInstallRoot);
			if (!cbExactPath)	// suppose path is relative to [Eagles root]/lib folder...
			{
				sJVMLibPath.append(g_cszWhereJavaLibsAre);
				if (!CPlatformUtils::DirectoryExists(sJVMLibPath))
				{
					//or to [Eagles root] folder itself
					sJVMLibPath.assign(sInstallRoot);
					sJVMLibPath.append(szcLibDirectory);
					CPathUtils::AppendEndSlash(sJVMLibPath);
					sJVMLibPath.append(g_cszWhereJavaLibsAre);
				}
			}
			// Verify whether lib name is also included into full path name
			int	iLib = FindNoCase(sJVMLibPath, g_szcJavaVMLibName);
			if (iLib > 0)
			{
				sJVMLibPath.erase(iLib);
			}
			sJVMLibPath.append(g_szcJavaVMLibName);
			CPathUtils::MakeCanonicalPath(sJVMLibPath);
			bRetv = CPlatformUtils::FileExists(sJVMLibPath);
		}

		// Try to use system 'which' ('where' for Windows) utility to locate necessary library
		bool bAddPath = false;
		if (!bRetv)
		{
			sLibLocation.swap(sJVMLibPath);		// save path for printing error only
			string	sJVMLibName(g_szcJavaVMLibName);
			sJVMLibPath.clear();
			// Now utility name is being included into full path
			bRetv = CSystemUtilityPaths::ResolvePathToSystemUtility(sJVMLibName, sJVMLibPath);

			// Add special 'libjvm' path resolving routine here, via possible java installation
			// (for Linux only)
			if (!bRetv)
			{
				bRetv = SearchForJVMLibrary(string(g_szcJavaUtilityName), sJVMLibPath);
			}

			if (bRetv)
			{
				CPathUtils::MakeCanonicalPath(sJVMLibPath);
			}

			bAddPath = !bRetv;
		}

		if (!bRetv)
		{
			if (bAddPath)
			{
				FormatString(sError, "Cannot locate '%s' library file in the directories listed "
					"in the environment variable PATH. You probably need to add path to its "
					"location manually", g_szcJavaVMLibName);
			}
			else
			{
				FormatString(sError, "Failed to find Java TFS SDK libraries in '%s' location",
					sLibLocation.empty() ? sJVMLibPath.c_str() : sLibLocation.c_str());
			}
			break;
		}

		CPlatformUtils::NormalizeGivenPath(sJVMLibPath);
		g_pJVMLibInstance = CPlatformUtils::LoadLibrary(sJVMLibPath.c_str());
		if (g_pJVMLibInstance == NULL)
		{
			// set error
			FinalizeJVMLibrary();
			bRetv = false;
			FormatString(sError, "Failed to load '%s' library; error code %d, error: %s",
				sJVMLibPath.c_str(), CPlatformUtils::GetLastErrorCode(),
				CPlatformUtils::GetLastError().c_str());
			break;
		}

		size_t nIdx = 0U, nIdxEnd = STATIC_ARRAY_SIZE(g_ppTFSSDKFunctionsAddresses);
		for (; nIdx != nIdxEnd; ++nIdx)
		{
			void * pAddress =
				CPlatformUtils::GetProcAddress(g_pJVMLibInstance, g_cszTFSSDKFunctionsNames[nIdx]);
			if (pAddress == NULL)
			{
				// Release library and break;
				FinalizeJVMLibrary();
				FormatString(sError, "Failed to get address of '%s' function",
					g_cszTFSSDKFunctionsNames[nIdx]);
				break;
			}
			*g_ppTFSSDKFunctionsAddresses[nIdx] = pAddress;
		}

		bRetv = (nIdx == nIdxEnd);
	}
	while (false);

	sInstallRoot.assign(sJVMLibPath);
	return bRetv;

#else	//LOAD_JVM_LIB
	return true;
#endif	//LOAD_JVM_LIB
}

bool InitializeJavaVirtualMachine(const bool cbExactPath, string & sInstallRoot, string & sError)
// 'sInstallRoot' should be non-empty and slash-terminated here
{
	bool bRetv = false;
#ifdef LOAD_JVM_LIB
	ASSERT(g_pJVMLibInstance != NULL);
#endif	//LOAD_JVM_LIB

	string	sJARFilePath;
	do
	{
		if ((g_pJavaVM != nullptr) || (g_pJNIEnvironment != nullptr))
		{
			sError.assign("Java Virtual Machine and JNI environment are initialized already");
			break;
		}

		// Resolve Java archive location
		string	sLibLocation, sLibSelfName(LIBTFSCLIENT_LIB_NAME);
		if (sInstallRoot.empty())	// library should determine its own location itself
		{
			if (CPlatformUtils::GetPathToCurrentModule(sLibLocation))
			{
				size_t nFileName = FindNoCase(sLibLocation, sLibSelfName);
				if (nFileName != string::npos)
				{
					sLibLocation.erase(nFileName);
				}
				CPathUtils::AppendEndSlash(sLibLocation);
				sLibLocation.append(g_cszWhereJavaLibsAre);
				sJARFilePath.assign(sLibLocation);
			}
		}
		else
		{
			bool	bFound = false;
			sLibLocation.clear();
			if (cbExactPath)
			{
				sJARFilePath.assign(sInstallRoot);
				size_t nFileName = FindNoCase(sJARFilePath, sLibSelfName);
				if (nFileName != string::npos)
				{
					sJARFilePath.erase(nFileName);
				}
				else
				{
					sLibSelfName.assign(g_szcJavaTFSSDKName);
					nFileName = FindNoCase(sJARFilePath, sLibSelfName);
					if (nFileName != string::npos)
					{
						sJARFilePath.erase(nFileName);
					}
				}
				sLibLocation.assign(sJARFilePath);

				string	sFound(sJARFilePath);
				sFound.append(g_szcJavaTFSSDKName);
				CPathUtils::MakeCanonicalPath(sFound);
				bFound = CPlatformUtils::FileExists(sFound);
			}

			if (!bFound)
			{
				sJARFilePath.assign(sLibLocation);

				// Try relative location to [Eagles root]/lib folder
				sJARFilePath.append(g_cszWhereJavaLibsAre);
				if (!CPlatformUtils::DirectoryExists(sJARFilePath))
				{
					// and to [Eagles root] itself
					sJARFilePath.assign(sInstallRoot);
					sJARFilePath.append(szcLibDirectory);
					CPathUtils::AppendEndSlash(sJARFilePath);
					sJARFilePath.append(g_cszWhereJavaLibsAre);
				}
			}

			sLibLocation.assign(sJARFilePath);
		}

		sJARFilePath.append(g_szcJavaTFSSDKName);
		CPlatformUtils::NormalizeGivenPath(sJARFilePath);
		CPathUtils::MakeCanonicalPath(sJARFilePath);
		if (!CPlatformUtils::FileExists(sJARFilePath))
		{
			FormatString(sError, "Cannot find Java archive file '%s'", sJARFilePath.c_str());
			break;
		}

		JavaVMInitArgs jvmArgs;		// Initialization arguments
#if defined DEBUG && defined WIN32
		jvmArgs.nOptions = 7;
#else	// Release & LINUX
		jvmArgs.nOptions = 5;
#endif	// defined DEBUG && defined WIN32
		// JVM invocation options; 2-nd - for 'native' libs;
		JavaVMOption * pOptions = new JavaVMOption[jvmArgs.nOptions];
		if (pOptions == NULL)
		{
			sError.assign("Memory allocation error");
			break;
		}

		string sJARPathParam;
		FormatString(sJARPathParam, g_szcJavaArchivePattern, sJARFilePath.c_str());
		pOptions[0].optionString = const_cast<char *>(sJARPathParam.c_str());

		// We may need 'native' libs path too
		string sJARNativeLibsPath(sLibLocation);
		sJARNativeLibsPath.append(g_szcWhereNativeFilesAre);
		CPathUtils::MakeCanonicalPath(sJARNativeLibsPath);
		if (!CPlatformUtils::DirectoryExists(sJARNativeLibsPath))
		{
			FormatString(sError, "Cannot find folder '%s' with Java native libraries",
				sJARNativeLibsPath.c_str());
			break;
		}

		string	sNativeLibsParam;
		FormatString(sNativeLibsParam, g_szcJavaNativeFilesPattern, sJARNativeLibsPath.c_str());
		pOptions[1].optionString = const_cast<char *>(sNativeLibsParam.c_str());
		// Additional useful options: disable Just-In-Time compilation
		pOptions[2].optionString = const_cast<char *>(szcDisableJITCompile);
		// Heap-memory usage options
		pOptions[3].optionString = const_cast<char *>(szcJavaMemMaxHeapSize);
		pOptions[4].optionString = const_cast<char *>(szcJavaMemInitHeapSize);

#if defined DEBUG && defined WIN32
		// print JNI-related messages
		pOptions[5].optionString = const_cast<char *>(szcPrintMessages2Stdout);
		pOptions[6].optionString = const_cast<char *>(szcPrintGCMsges2Stdout);
#endif	//defined DEBUG && defined WIN32

		jvmArgs.version = g_uiJNIMinVersion;	// minimum Java version
		jvmArgs.options = pOptions;
		jvmArgs.ignoreUnrecognized = false;		// invalid options make the JVM init fail

		// Load and initialize Java VM and JNI interface
#ifdef LOAD_JVM_LIB
		jint jiCreate = g_pTFS_CreateJavaVM(&g_pJavaVM, (void**)&g_pJNIEnvironment, (void *)&jvmArgs);
#else	//#if LOAD_JVM_LIB
		jint jiCreate = JNI_CreateJavaVM(&g_pJavaVM, (void**)&g_pJNIEnvironment, (void *)&jvmArgs);
#endif	//#if LOAD_JVM_LIB

		delete [] pOptions;    // no longer need the initialised options

		if (jiCreate == JNI_OK)
		{
			bRetv = true;
		}
		else
		{
			switch (jiCreate)
			{
				case JNI_ERR:
					sError.assign("Unrecognized error");
					break;
				case JNI_EDETACHED:
					sError.assign("Working thread detached from the VM");
					break;
				case JNI_EVERSION:
					{
						unsigned int uiMaj, uiMin;
						GetJVMLibraryVersion(uiMaj, uiMin);
						FormatString(sError, "JVM version [%u.%u] is outdated", uiMaj, uiMin);
					}
					break;
				case JNI_ENOMEM:
					sError.assign("Insufficient memory for JVM");
					break;
				case JNI_EEXIST:
					sError.assign("The process can only launch one JVM");
					break;
				case JNI_EINVAL:
					sError.assign("Invalid argument for launching JVM");
					break;
				default:
					FormatString(sError, "Cannot create the JVM instance; error code %ld",
						static_cast<long>(jiCreate));
					break;
			}
		}
	}
	while (false);

	sInstallRoot.assign(sJARFilePath);
	return bRetv;
}

bool GetJVMLibraryVersion(unsigned int & uiMajorVer, unsigned int & uiMinorVer)
{
	ASSERT(g_pJNIEnvironment != nullptr);

	unsigned int uiRetv = static_cast<unsigned int>(g_pJNIEnvironment->GetVersion());
	uiMajorVer = ((uiRetv >> 16) & 0x0f);
	uiMinorVer = (uiRetv & 0x0f);

	return (uiRetv >= g_uiJNIMinVersion);
}

bool FinalizeJVMLibrary()
{
	bool bRetv = false;
	
	// Reset imported functions
	size_t nIdx = 0U, nIdxEnd = STATIC_ARRAY_SIZE(g_ppTFSSDKFunctionsAddresses);
	for (; nIdx != nIdxEnd; ++nIdx)
	{
		*g_ppTFSSDKFunctionsAddresses[nIdx] = NULL;
	}

	if (g_pJVMLibInstance != NULL)
	{
		bRetv = (CPlatformUtils::FreeLibrary(g_pJVMLibInstance) != 0);
		g_pJVMLibInstance = NULL;
	}

	return bRetv;
}

bool FinalizeJavaVirtualMachine()
{
	bool bRetv = true;

	if (g_pJavaVM != nullptr)
	{
		bRetv = (g_pJavaVM->DestroyJavaVM() == static_cast<jint>(0));
	}

	g_pJavaVM = nullptr;
	g_pJNIEnvironment = nullptr;

	return bRetv;
}

bool ParseUrlAndCredentialsString(const string & csInput, string & sUrl, string & sFullName,
	string & sPassword)
// Suppose we have input line in the next format: Url_to_connect%DomainName\\UserName%Password
{
	bool bRetv = false;

	sUrl.clear();
	sFullName.clear();
	sPassword.clear();

	do
	{
		if (csInput.empty())
		{
			break;
		}
		string	sInput(csInput);

		size_t nPos = sInput.find(cszUrlFromNameSeparator, 0);
		if (nPos == string::npos)
		{
			break;
		}

		sUrl = sInput.substr(0, nPos);
		Trim(sUrl);
		sInput.erase(0, ++nPos);

		nPos = sInput.find(cszUrlFromNameSeparator, 0);
		if (nPos == string::npos)
		{
			break;
		}

		sFullName = sInput.substr(0, nPos);
		Trim(sFullName);
		sPassword = sInput.substr(++nPos);
		Trim(sPassword);

		bRetv = !(sUrl.empty() || sFullName.empty() && sPassword.empty());
	} 
	while (false);

	return bRetv;
}

bool SearchForJVMLibrary(const string & csWhatToSearch, string & sFullLibPath)
// Implemented for Linux only for now !
{
	bool bRetv = false;
	sFullLibPath.clear();

#ifdef UNIX

	do
	{
		if (csWhatToSearch.empty())
		{
			break;
		}

		// Look for 'java' binary
		string sBinPath;
		if (!CSystemUtilityPaths::ResolvePathToSystemUtility(csWhatToSearch, sBinPath))
		{
			break;
		}

		// Resolve symbolic link if necessary
		bool bIsSymLink = true;
		string sSearchName(csWhatToSearch);	
		do
		{
			sSearchName.swap(sBinPath);
			sBinPath.clear();
			bIsSymLink = CPlatformUtils::GetTargetPathForSymlink(sSearchName.c_str(), sBinPath);
		}
		while (bIsSymLink);
	
		if (sSearchName.length() <= csWhatToSearch.length())
		{
			break;
		}

		// Look for Java Virtual Machine library in the specified location
		sSearchName.erase(sSearchName.length() - csWhatToSearch.length(), csWhatToSearch.length()); 
		CPathUtils::AppendEndSlash(sSearchName);
		sSearchName.append(g_szcJVMSearchPath);
		sSearchName.append(g_szcJavaVMLibName);

		bRetv = CPlatformUtils::FileExists(sSearchName);
		if (bRetv)
		{
			sFullLibPath.swap(sSearchName);
		}
	}
	while (false);

#endif // UNIX

	return bRetv;
}

#endif //#ifdef USE_JNI_TFS_SDK
