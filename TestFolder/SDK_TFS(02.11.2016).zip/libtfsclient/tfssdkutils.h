#ifndef _TFSSDKUTILS_H__INCLUDED_
#define _TFSSDKUTILS_H__INCLUDED_

#define LOAD_JVM_LIB	// LibTfsClient looks for and dynamically loads 'jvm' library
//#undef LOAD_JVM_LIB	// 'jvm' library are being linked on link time

#define TO_STRING_BUFFER_SIZE			((jint)65536)

////////////////////////////////////////////////////////////////////////////////////////////////////

extern const char g_szcClassConstructorName[];
extern const char g_szcJavaVoidTypeName[];
extern const char g_szcJavaBoolTypeName[];
extern const char g_szcJavaByteTypeName[];
extern const char g_szcJavaCharTypeName[];
extern const char g_szcJavaIntTypeName[];
extern const char g_szcJavaLongTypeName[];
extern const char g_szcJavaFloatTypeName[];
extern const char g_szcJavaDoubleTypeName[];

extern const char g_szcJavaStringTypeName[];
extern const char g_szcJavaURITypeName[];
extern const char g_szcJavaObjectTypeName[];
extern const char g_szcJavaOutputStreamName[];
extern const char g_szcJavaBAOutputStreamName[];

extern const char g_szcDoAuthedMethodName[];
extern const char g_szcCheckInMethodName[];
extern const char g_szcIsAuthedMethodName[];
extern const char g_szcPendAddMethodName[];
extern const char g_szcGetPendingChangesMethodName[];
extern const char g_szcGetItemMethodName[];
extern const char g_szcCloseConnMethodName[];
extern const char g_szcCreateWorkspace[];
extern const char g_szcItemExistsMethodName[];
extern const char g_szcGetItemTypeMethodName[];
extern const char g_szcGetContLenMethodName[];
extern const char g_szcGetDLUrlMethodName[];
extern const char g_szcEqualsMethodName[];
extern const char g_szcGetVCCMethodName[];
extern const char g_szcGetWorkspaceMethodName[];
extern const char g_szcDeleteWorkspaceMethodName[];
extern const char g_szcDownLoadItemMethodName[];
extern const char g_szcToStringMethodName[];
extern const char g_szcStrLengthMethodName[];
extern const char g_szcGetItemsMethodName[];
extern const char g_szcGetSrvItemMethodName[];
extern const char g_szcGetCollEntityMethodName[];
extern const char g_szcGetTeamProjsMethodName[];
extern const char g_szcGetProjNameMethodName[];

extern const char g_szcBeginUploadRequest[];
extern const char g_szcExecuteUploadRequest[];
extern const char g_szcFinishUploadRequest[];

extern const char g_szcJavaArrayTypePattern[];
extern const char g_szcJavaObjectTypePattern[];
extern const char g_szcMethodParamsPattern[];

extern const char g_szcProjectCollectionPath[];
extern const char g_szcUPCredentialsPath[];
extern const char g_szcCredentialsPath[];
extern const char g_szcVersionControlClPath[];
extern const char g_szcVersionSpecPath[];
extern const char g_szcLtstVersionSpecPath[];
extern const char g_szcDownloadSpecPath[];
extern const char g_szcVCCItemPath[];
extern const char g_szcItemTypesPath[];
extern const char g_szcRecursionTypePath[];
extern const char g_szcFileEncodingTypePath[];
extern const char g_szcLockLevelTypePath[];
extern const char g_szcGetOptionsTypePath[];
extern const char g_szcPendChangesOptionsTypePath[];
extern const char g_szcPendingSetTypePath[];
extern const char g_szcPendingChangeTypePath[];
extern const char g_szcItemSetPath[];
extern const char g_szcITeamProjEntityPath[];
extern const char g_szcTeamProjCatalogEnPath[];
extern const char g_szcIProjCollCatalogPath[];
extern const char g_szcProjCollCatalogEnPath[];
extern const char g_szcWorkspacePath[];
extern const char g_szcWorkingFolder[];
extern const char g_szcWorkspaceLocation[];
extern const char g_szcWorkspaceOptions[];

extern const char g_szcPostMethodPath[];

extern const char g_szcVersionSpecFieldName[];
extern const char g_szcFileItemTypeFieldName[];
extern const char g_szcFldrItemTypeFieldName[];
extern const char g_szcRecursionOnFieldName[];
extern const char g_szcRecursionOffFieldName[];

extern const char cszUrlFromNameSeparator;
extern const char cszPwdFromNameSeparator;

////////////////////////////////////////////////////////////////////////////////////////////////////
class CItemInfo;

enum TFSItemType
{
	TFSItemType_File,
	TFSItemType_Folder,
	TFSItemType_Unknown,

	TFSItemTypesCount = TFSItemType_Unknown
};

////////////////////////////////////////////////////////////////////////////////////////////////////

bool InitializeJavaVirtualMachine(const bool cbExactPath, string & sInstallRoot, string & sError);
bool InitializeJVMLibrary(const bool cbExactPath, string & sInstallRoot, string & sError);
bool SearchForJVMLibrary(const string & csBinName, string & sFullibPath);
bool FinalizeJavaVirtualMachine();
bool FinalizeJVMLibrary();
bool GetJVMLibraryVersion(unsigned int & uiMajorVer, unsigned int & uiMinorVer);
bool ParseUrlAndCredentialsString(const string & csInput, string & sUrl, string & sFullName,
	string & sPassword);

#endif // _TFSSDKUTILS_H__INCLUDED_
