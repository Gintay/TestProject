#ifndef _TFS_UNRESOLVED_ASSEMBLY_HANDLER_H__INCLUDED_
#define _TFS_UNRESOLVED_ASSEMBLY_HANDLER_H__INCLUDED_

#ifndef USE_JNI_TFS_SDK

/** class CTfsUnresolvedAssemblyHandler
 * This class is used to handle and load an assembly that TFS client library failed to resolve.
 * This class is not thread-safe.
 */
class CTfsUnresolvedAssemblyHandler
{
public:
	/* 
	 * Starts to handle an unresolved assembly events.
	 * Parameters:
	 *	csTfsSdkDirectoryPath[in] - path to directory from which missed assembly will be loaded
	 *	sError[out] - error text
	 * Returns true on success, otherwise false
	 */
	static bool Start(const string & csTfsSdkDirectoryPath, string & sError);

	/* 
	 * Stops to handle an unresolved assembly events.
	 * Parameters:
	 *	sError[out] - error text
	 * Returns true on success, otherwise false
	 */
	static bool Stop(string & sError);

private:
	static System::Reflection::Assembly ^ ResolveTfsAssembly(System::Object ^ sender,
		System::ResolveEventArgs ^ args);

private:
	static string	 ms_sTfsSdkDirectoryPath;
	static bool		 ms_bIsStarted;
};

#endif	// #ifndef USE_JNI_TFS_SDK
#endif // #ifndef _TFS_UNRESOLVED_ASSEMBLY_HANDLER_H__INCLUDED_
