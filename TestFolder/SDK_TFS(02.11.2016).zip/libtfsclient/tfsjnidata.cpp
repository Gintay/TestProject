#include "StdAfx.h"

#include "libtfsclient/libtfsclientapi.h"

#ifdef USE_JNI_TFS_SDK

#include "tfsjnidata.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
// Basic 'CTypeIdentifier' class function

void CTypeIdentifier::SetDataArrayType(const bool cbIsArray)
{
	if (cbIsArray)
	{
		if (m_eDataType < JNIDataTypesCount)
		{
			m_eDataType = static_cast<JNIDataType>(m_eDataType + JNIDataType_Array);
		}
	}
	else
	{
		if (m_eDataType > JNIDataType_Array)
		{
			m_eDataType = static_cast<JNIDataType>(m_eDataType - JNIDataType_Array);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
// 'CJNIVoidData' class virtual functions

void CJNIVoidData::SetDataTypeSignature(const char * szcResClassPath)
{ 
	ASSERT(szcResClassPath != NULL);
	m_sResultSignature.assign(SAFE_STRING(szcResClassPath));
}

void CJNIVoidData::ExecuteJNIMethod(void * /*pRetval*/, jobject joOwnerObj, jmethodID jmID,
	va_list jvlArgs)
{
	g_pJNIEnvironment->CallVoidMethodV(joOwnerObj, jmID, jvlArgs);
}

void CJNIVoidData::EvaluateResult(bool & bSuccess) const
{ 
	bSuccess = true;
}

////////////////////////////////////////////
// 'CJNIBooleanData' class virtual functions

void CJNIBooleanData::SetDataTypeSignature(const char * szcResClassPath)
{ 
	ASSERT(szcResClassPath != NULL);
	m_sResultSignature.assign(SAFE_STRING(szcResClassPath));
}

void CJNIBooleanData::ExecuteJNIMethod(void * pRetval, jobject joOwnerObj, jmethodID jmID,
	va_list jvlArgs)
{
	if (pRetval != NULL)
	{
		jboolean jbRes = g_pJNIEnvironment->CallBooleanMethodV(joOwnerObj, jmID, jvlArgs);
		*(static_cast<bool *>(pRetval)) = static_cast<bool>(jbRes == JNI_TRUE);
	}
}

bool CJNIBooleanData::EvaluateResult(bool & bSuccess)  const
{ 
	bSuccess = m_bResultData;
	return m_bResultData; 
}

////////////////////////////////////////
// 'CJNIIniData' class virtual functions

void CJNIIntData::SetDataTypeSignature(const char * szcResClassPath)
{ 
	ASSERT(szcResClassPath != NULL);
	m_sResultSignature.assign(SAFE_STRING(szcResClassPath));
}

void CJNIIntData::ExecuteJNIMethod(void * pRetval, jobject joOwnerObj, jmethodID jmID,
	va_list jvlArgs)
{
	if (pRetval != NULL)
	{
		jint jiRes = g_pJNIEnvironment->CallIntMethodV(joOwnerObj, jmID, jvlArgs);
		*(static_cast<native_int *>(pRetval)) = static_cast<native_int>(jiRes);
	}
}

long CJNIIntData::EvaluateResult(bool & bSuccess) const
{ 
	bSuccess = true;
	return m_lResultData; 
}

/////////////////////////////////////////
// 'CJNILongData' class virtual functions

void CJNILongData::SetDataTypeSignature(const char * szcResClassPath)
{ 
	ASSERT(szcResClassPath != NULL);
	m_sResultSignature.assign(SAFE_STRING(szcResClassPath));
}

void CJNILongData::ExecuteJNIMethod(void * pRetval, jobject joOwnerObj, jmethodID jmID,
	va_list jvlArgs)
{
	if (pRetval != NULL)
	{
		jlong jiRes = g_pJNIEnvironment->CallLongMethodV(joOwnerObj, jmID, jvlArgs);
		*(static_cast<native_i64 *>(pRetval)) = static_cast<native_i64>(jiRes);
	}
}

native_i64 CJNILongData::EvaluateResult(bool & bSuccess) const
{ 
	bSuccess = true;
	return m_liResultData; 
}

///////////////////////////////////////////
// 'CJNIObjectData' class virtual functions

void CJNIObjectData::SetDataTypeSignature(const char * szcResClassPath)
{ 
	if (szcResClassPath == NULL)
	{
		m_sResultSignature.assign(g_szcJavaVoidTypeName);
	}
	else
	{
		if (szcResClassPath[1] != '\0')	// check if length is more than 1 symbol
		{
			FormatString(m_sResultSignature, g_szcJavaObjectTypePattern, szcResClassPath);
		}
		else
		{
			m_sResultSignature.assign(szcResClassPath);
		}
	}
}

void CJNIObjectData::CreateNewDTObject(jclass jcClass, void * pID, va_list jArgs)
{
	if ((jcClass != nullptr) && (pID != nullptr))
	{
		m_joResultData = g_pJNIEnvironment->NewObjectV(jcClass, static_cast<jmethodID>(pID), jArgs);
	}
}

void CJNIObjectData::ExecuteJNIMethod(void * pRetval, jobject joOwnerObj, jmethodID jmID,
	va_list jvlArgs)
{
	if (pRetval != NULL)
	{
		*(static_cast<jobject *>(pRetval)) =
			g_pJNIEnvironment->CallObjectMethodV(joOwnerObj, jmID, jvlArgs);
	}
}

jobject CJNIObjectData::EvaluateResult(bool & bSuccess) const
{ 
	bSuccess = (m_joResultData != nullptr);
	return m_joResultData;
}

///////////////////////////////////////////
// 'CJNIStringData' class virtual functions

void CJNIStringData::SetDataTypeSignature(const char * szcResClassPath)
{
	if (szcResClassPath == NULL)
	{
		FormatString(m_sResultSignature, g_szcJavaObjectTypePattern, g_szcJavaStringTypeName);
	}
	else
	{
		if (szcResClassPath[1] != '\0')	// check if length is more than 1 symbol
		{
			FormatString(m_sResultSignature, g_szcJavaObjectTypePattern, szcResClassPath);
		}
		else
		{
			m_sResultSignature.assign(szcResClassPath);
		}
	}
}

void CJNIStringData::CreateNewDTObject(jclass /*jcClass*/, void * /*pID*/, va_list jArgs)
{
	m_jsResultData = g_pJNIEnvironment->NewStringUTF(reinterpret_cast<char *>(jArgs));
}

void CJNIStringData::ConvertJNIStringFrom(const string & csData, string & sError)
{
	sError.clear();
	m_jsResultData = g_pJNIEnvironment->NewStringUTF(csData.c_str());
	if (m_jsResultData == NULL)
	{
		FormatString(sError, "Cannot convert string to JNI object: '%s'. ", csData.c_str());
	}
}

void CJNIStringData::ConvertJNIStringFrom(const char * pszData, string & sError)
{
	if (pszData != NULL)
	{
		sError.clear();
		m_jsResultData = g_pJNIEnvironment->NewStringUTF(pszData);
		if (m_jsResultData == NULL)
		{
			FormatString(sError, "Cannot convert string to JNI object:'%s'. ", pszData);
		}
	}
}

void CJNIStringData::ExecuteJNIMethod(void * pRetval, jobject joOwnerObj, jmethodID jmID,
	va_list jvlArgs)
{
	if (pRetval != NULL)
	{
		*(static_cast<jstring *>(pRetval)) = 
			static_cast<jstring>(g_pJNIEnvironment->CallObjectMethodV(joOwnerObj, jmID, jvlArgs));
	}
}

jstring CJNIStringData::EvaluateResult(bool & bSuccess) const
{ 
	bSuccess = (m_jsResultData != nullptr);
	return m_jsResultData;
}

/////////////////////////////////////////
// 'CJNIFieldData' class private function

void CJNIFieldData::SetDataTypeSignature(const char * szcResClassPath)
{ 
	if (szcResClassPath == NULL)
	{
		m_sResultSignature.assign(g_szcJavaVoidTypeName);
	}
	else
	{
		if (szcResClassPath[1] != '\0')	// check if length is more than 1 symbol
		{
			FormatString(m_sResultSignature, g_szcJavaObjectTypePattern, szcResClassPath);
		}
		else
		{
			m_sResultSignature.assign(szcResClassPath);
		}
	}
}

void CJNIFieldData::CreateNewDTObject(jclass jcClass, void * pID, va_list /*jArgs*/)
// 'jArgs' parameter should be NULL in calling function
{
	m_joResultData = g_pJNIEnvironment->GetStaticObjectField(jcClass, static_cast<jfieldID>(pID));
}

jobject CJNIFieldData::EvaluateResult(bool & bSuccess) const
{ 
	bSuccess = (m_joResultData != nullptr);
	return m_joResultData;
}

#endif	//#ifdef USE_JNI_TFS_SDK
