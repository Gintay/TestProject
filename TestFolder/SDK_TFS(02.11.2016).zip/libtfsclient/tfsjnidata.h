#ifndef _TFSJNIDATA_H__INCLUDED_
#define _TFSJNIDATA_H__INCLUDED_

#include "strutils.h"
#include "common_constants.h"
#include "tfssdkutils.h"

#ifdef LINUX
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wshadow"
# include <jni.h>
# pragma GCC diagnostic pop
#endif // LINUX

#ifdef WIN32
# ifdef USE_JNI_TFS_SDK
#  include <jni.h>
# endif	//USE_JNI_TFS_SDK

typedef __int64		native_i64;
typedef long		native_int;

#else	//#ifdef WIN32

typedef long long	native_i64;
typedef int			native_int;

# define nullptr		__null
#endif	//#ifdef WIN32

#ifdef USE_JNI_TFS_SDK
////////////////////////////////////////////////////////////////////////////////////////////////////

extern JNIEnv	* g_pJNIEnvironment;

////////////////////////////////////////////////////////////////////////////////////////////////////

enum JNIStorageType
{
	JNIStorageType_Unknown,

	JNIStorageType_Public,
	JNIStorageType_Static,
	JNIStorageType_Protected,	// no calls - not implemented

	JNIStorageTypesCount
};

enum JNIDataType
{
	JNIDataType_Unknown = 0,

	JNIDataType_Void,
	JNIDataType_Boolean,
	JNIDataType_Byte,			// no calls - not implemented
	JNIDataType_Char,			// no calls - not implemented
	JNIDataType_Short,			// no calls - not implemented
	JNIDataType_Int,
	JNIDataType_Long,
	JNIDataType_Float,			// no calls - not implemented
	JNIDataType_Double,			// no calls - not implemented
	JNIDataType_Object,			// = 10, next enums order is essential !!!
	JNIDataType_String,			// extension for 'Object' type
	JNIDataType_Field,
	JNIDataTypesCount,
	JNIDataType_Array = 0x0100	// binary flag
};

class CTypeIdentifier
{
public:
	CTypeIdentifier(const JNIDataType ceDataType = JNIDataType_Unknown,
		const JNIStorageType ceStorageClass = JNIStorageType_Unknown,
		const bool cbDataIsArray = false):
		m_eDataType(EnsureValidDataType(ceDataType)),
		m_eStorageClass(EnsureValidStorageType(ceStorageClass))
		{
			SetDataArrayType(cbDataIsArray);
		}

	virtual ~CTypeIdentifier() {}

	virtual	string const	GetDataTypeSignature() = 0;
	virtual	void * const	GetResultValAddress() = 0;
	virtual	void CreateNewDTObject(jclass jcObjClass, void * pInstID, va_list jArgs) = 0;
	virtual	void ExecuteJNIMethod(void * pRetval, jobject joOwnerObj, jmethodID jmID,
		va_list jArgs) = 0;

	bool IsDataOfArrayType() const	{ return (m_eDataType > JNIDataType_Array); };
	bool IsValidStorageType() const	{ return ((m_eStorageClass > JNIStorageType_Unknown) &&
										(m_eStorageClass < JNIStorageTypesCount)); };
	JNIDataType GetDataType() const	{ return  m_eDataType; };
	JNIDataType GetValildDataType() const	{ return IsDataOfArrayType() ? static_cast<JNIDataType>
												(m_eDataType - JNIDataType_Array) : m_eDataType; };
	JNIStorageType GetStorageType() const	{ return m_eStorageClass; };
	bool IsDataOfObjectType(const JNIDataType eType) const { return ((eType >= JNIDataType_Object)
															 && (eType < JNIDataTypesCount)); };
	bool IsValidDataType(const JNIDataType eType)	 const { return ((eType > JNIDataType_Unknown)
															 && (eType < JNIDataTypesCount)); };
	bool IsDataOfObjectType() const		{ return IsDataOfObjectType(GetValildDataType()); };
	bool IsValidDataType() const		{ return IsValidDataType(GetValildDataType()); };

private:
	void SetDataArrayType(const bool cbIsDataArray);
	JNIStorageType	EnsureValidStorageType(const JNIStorageType eType)
		{ return ((eType > JNIStorageType_Unknown) && (eType < JNIStorageTypesCount)) ?
			eType : JNIStorageType_Unknown; };
	JNIDataType	EnsureValidDataType(const JNIDataType eType)
		{ JNIDataType eT = (eType > JNIDataType_Array) ?
			static_cast<JNIDataType>(eType - JNIDataType_Array) : eType;
		return ((eT > JNIDataType_Unknown) && (eT < JNIDataTypesCount)) ?
			eT : JNIDataType_Unknown; };

private:
	JNIDataType		m_eDataType;
	JNIStorageType	m_eStorageClass;
protected:
	string			m_sResultSignature;
};

////////////////////////////////////////////////////////////////////////////////////////////////////

class CJNIVoidData: public CTypeIdentifier
{
public:
	CJNIVoidData():
		CTypeIdentifier(JNIDataType_Void, JNIStorageType_Public),
		m_bResultData(false)
	{
		SetDataTypeSignature(g_szcJavaVoidTypeName);
	}

	virtual ~CJNIVoidData() {}

	virtual	string const	GetDataTypeSignature()	{ return string(g_szcJavaVoidTypeName); };
	virtual	void * const	GetResultValAddress()	{ return static_cast<void *>(&m_bResultData); };
	virtual	void ExecuteJNIMethod(void * pRetv, jobject jOwnerObj, jmethodID jID, va_list jArgs);
	virtual	void CreateNewDTObject(jclass /*jcClass*/, void * /*pInstID*/, va_list /*jArgs*/) {};

	void GetJNIObjectData() const	{};
	void EvaluateResult(bool & bSuccess) const;

	void SetDataTypeSignature(const char * szcNewClassPath);

private:
	bool m_bResultData;
};

class CJNIBooleanData: public CTypeIdentifier
{
public:
	CJNIBooleanData():
		CTypeIdentifier(JNIDataType_Boolean, JNIStorageType_Public),
		m_bResultData(false)
	{
		SetDataTypeSignature(g_szcJavaBoolTypeName);
	}
	CJNIBooleanData(const bool cbInputData):
		CTypeIdentifier(JNIDataType_Boolean, JNIStorageType_Public),
		m_bResultData(cbInputData)
	{
		SetDataTypeSignature(g_szcJavaBoolTypeName);
	}

	virtual ~CJNIBooleanData() {}

	virtual	string const	GetDataTypeSignature()	{ return string(g_szcJavaBoolTypeName); };
	virtual	void * const	GetResultValAddress()	{ return static_cast<void *>(&m_bResultData); };
	virtual	void CreateNewDTObject(jclass /*jcObjClass*/, void * /*pInstID*/, va_list /*jArgs*/) {};
	virtual	void ExecuteJNIMethod(void * pRetval, jobject joOwnerObj, jmethodID jmID,
		va_list jArgs);

	bool GetJNIObjectData() const	{ return m_bResultData; };
	bool EvaluateResult(bool & bSuccess) const;

	void SetDataTypeSignature(const char * szcNewClassPath);

private:
	bool m_bResultData;
};

class CJNIIntData: public CTypeIdentifier
{
public:
	CJNIIntData():
		CTypeIdentifier(JNIDataType_Int, JNIStorageType_Public),
		m_lResultData(0)
	{
		SetDataTypeSignature(g_szcJavaIntTypeName);
	}
	CJNIIntData(const long clInputData):
		CTypeIdentifier(JNIDataType_Int, JNIStorageType_Public),
		m_lResultData(clInputData)
	{
		SetDataTypeSignature(g_szcJavaIntTypeName);
	}

	virtual ~CJNIIntData() {}

	virtual	string const	GetDataTypeSignature()	{ return string(g_szcJavaIntTypeName); };
	virtual	void * const	GetResultValAddress()	{ return static_cast<void *>(&m_lResultData); };
	virtual	void CreateNewDTObject(jclass /*jcObjClass*/, void * /*pInstID*/, va_list /*jArgs*/) {};
	virtual	void ExecuteJNIMethod(void * pRetval, jobject joOwnerObj, jmethodID jmID,
		va_list jArgs);

	jint GetJNIObjectData() const	{ return static_cast<jint>(m_lResultData); };
	long EvaluateResult(bool & bSuccess) const;	// since 'jint' maps to 'long' 

	void SetDataTypeSignature(const char * szcNewClassPath);

private:
	long m_lResultData;
};

class CJNILongData: public CTypeIdentifier
{
public:
	CJNILongData():
		CTypeIdentifier(JNIDataType_Long, JNIStorageType_Public),
		m_liResultData(0)
	{
		SetDataTypeSignature(g_szcJavaLongTypeName);
	}
	CJNILongData(const native_i64 cliInputData):
		CTypeIdentifier(JNIDataType_Long, JNIStorageType_Public),
		m_liResultData(cliInputData)
	{
		SetDataTypeSignature(g_szcJavaLongTypeName);
	}

	virtual ~CJNILongData() {}

	virtual	string const	GetDataTypeSignature() { return string(g_szcJavaLongTypeName); };
	virtual	void * const	GetResultValAddress()  { return static_cast<void *>(&m_liResultData); };
	virtual	void CreateNewDTObject(jclass /*jcObjClass*/, void * /*pInstID*/, va_list /*jArgs*/) {};
	virtual	void ExecuteJNIMethod(void * pRetval, jobject joOwnerObj, jmethodID jmID,
		va_list jArgs);

	jlong	 GetJNIObjectData() const	{ return static_cast<jlong>(m_liResultData); };
	native_i64 EvaluateResult(bool & bSuccess) const;	// since 'jlong' maps to '__int64' 

	void SetDataTypeSignature(const char * szcNewClassPath);
	
private:
	native_i64	m_liResultData;
};

class CJNIObjectData: public CTypeIdentifier
{
public:
	CJNIObjectData(const char * szcRetObjPath, const bool cbDataIsArray = false):
		CTypeIdentifier(JNIDataType_Object, JNIStorageType_Public, cbDataIsArray),
		m_joResultData(nullptr)
	{
		SetDataTypeSignature(szcRetObjPath);
	}
	CJNIObjectData(const char * szcRetObjPath, const jobject cjoInputData,
		const bool cbDataIsArray = false):
		CTypeIdentifier(JNIDataType_Object, JNIStorageType_Public, cbDataIsArray),
		m_joResultData(cjoInputData)
	{
		SetDataTypeSignature(szcRetObjPath);
	}

	virtual ~CJNIObjectData() {}

	virtual	string const	GetDataTypeSignature() { return m_sResultSignature; };
	virtual	void * const	GetResultValAddress()  { return static_cast<void *>(&m_joResultData); };
	virtual	void CreateNewDTObject(jclass jcObjClass, void * pInstID, va_list jArgs);
	virtual	void ExecuteJNIMethod(void * pRetval, jobject joOwnerObj, jmethodID jmID,
		va_list jArgs);

	void	SetJNIObjectData(jobject joOut)	{ m_joResultData = joOut; };
	jobject EvaluateResult(bool & bSuccess) const;
	jobject GetJNIObjectData() const	{ return m_joResultData;  };
	bool	IsObjectNull() const		{ return (m_joResultData == nullptr); };

	void SetDataTypeSignature(const char * szcNewClassPath);

private:
	jobject	m_joResultData;
};

class CJNIStringData : public CTypeIdentifier
{
public:
	CJNIStringData(const bool cbDataIsArray = false):
		CTypeIdentifier(JNIDataType_String, JNIStorageType_Public, cbDataIsArray),
		m_jsResultData(nullptr)
	{
		SetDataTypeSignature(g_szcJavaStringTypeName);
	}
	// Next two constructors used to convert single string; seems they need no 'array' switch
	CJNIStringData(const char * szcRetObjPath, const char * szcInput, string & sError):
		CTypeIdentifier(JNIDataType_String, JNIStorageType_Public)
	{
		SetDataTypeSignature(szcRetObjPath);
		ConvertJNIStringFrom(szcInput, sError);
	}
	CJNIStringData(const char * szcRetObjPath, const string & csInput, string & sError):
		CTypeIdentifier(JNIDataType_String, JNIStorageType_Public)
	{
		SetDataTypeSignature(szcRetObjPath);
		ConvertJNIStringFrom(csInput, sError);
	}

	virtual ~CJNIStringData() {}

	virtual	string const	GetDataTypeSignature() { return m_sResultSignature; };
	virtual	void * const	GetResultValAddress()  { return static_cast<void *>(&m_jsResultData); };
	virtual	void CreateNewDTObject(jclass jcObjClass, void * pInstID, va_list jArgs);
	virtual	void ExecuteJNIMethod(void * pRetval, jobject joOwnerObj, jmethodID jmID,
		va_list jArgs);

	jstring EvaluateResult(bool & bSuccess) const;
	jstring GetJNIObjectData() const	{ return m_jsResultData; };
	bool	IsObjectNull() const		{ return (m_jsResultData == nullptr); };
	void	ConvertJNIStringFrom(const string & csData, string & sError);
	void	ConvertJNIStringFrom(const char * pszData, string & sError);

	void SetDataTypeSignature(const char * szcNewClassPath);

private:
	jstring	m_jsResultData;
};

class CJNIFieldData: public CTypeIdentifier
{
public:
	CJNIFieldData(const char * szcRetObjPath):
		CTypeIdentifier(JNIDataType_Field, JNIStorageType_Static),
		m_joResultData(nullptr)
	{
		SetDataTypeSignature(szcRetObjPath);
	}
	CJNIFieldData(const char * szcRetObjPath, const jobject cjoInputData):
		CTypeIdentifier(JNIDataType_Field, JNIStorageType_Static),
		m_joResultData(cjoInputData)
	{
		SetDataTypeSignature(szcRetObjPath);
	}

	virtual ~CJNIFieldData() {}

	virtual	string const	GetDataTypeSignature() { return m_sResultSignature; };
	virtual	void * const	GetResultValAddress()  { return static_cast<void *>(&m_joResultData); };
	virtual	void CreateNewDTObject(jclass jcObjClass, void * pInstID, va_list jArgs);
	virtual	void ExecuteJNIMethod(void * /*pRetval*/, jobject /*joOwnerObj*/, jmethodID /*jmID*/,
		va_list /*jArgs*/) {};

	jobject EvaluateResult(bool & bSuccess) const;
	jobject GetJNIObjectData() const	{ return m_joResultData; };
	bool	IsObjectNull() const		{ return (m_joResultData == nullptr); };

	void SetDataTypeSignature(const char * szcNewClassPath);

private:
	jobject	m_joResultData;
};

////////////////////////////////////////////////////////////////////////////////////////////////////

extern const char * const g_cszcJNITypeNames[JNIDataTypesCount];

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TDataType> class CJNIInstance
{
public:
	CJNIInstance(const char * szcInstanceName, const char * szcOwnerClassPath,
		TDataType * pDataTypeRetId):
		m_sInstanceName(SAFE_STRING(szcInstanceName)),
		m_sOwnerClassPath(SAFE_STRING(szcOwnerClassPath)),
		m_pResultObject(pDataTypeRetId)
		{}

#if 0
	void AttachDataTypeObject(TDataType * pDataTypeRetId)
	{
		m_pResultObject = pDataTypeRetId;
	}

	void DetachDataTypeObject()
	{
		m_pResultObject = NULL;
	}

	void ResetInstance(void)
	{
		m_sLocalError.clear();
		m_sOwnerClassPath.clear();
		m_sInstanceName.clear();
		m_sInstanceSignature.clear();

		DetachDataTypeObject();
	}
#endif	//0

	bool SetFunctionSignature(JNIDataType eRetType, unsigned int uiNumArgs, ...)
	{
		bool bRetv = false;

		m_sLocalError.clear();
		do
		{
			if (m_pResultObject == nullptr)
			{
				FormatString(m_sLocalError, "Method '%s' return type is undefined",
					m_sInstanceName.c_str());
				break;
			}

			if (!m_pResultObject->IsValidDataType(eRetType))
			{
				FormatString(m_sLocalError, "Wrong instance return type parameter: %u",
					static_cast<unsigned int>(eRetType));
				break;
			}

			string	sRetv;
			// Determine the return value type signature:
			if (m_pResultObject->IsDataOfObjectType(eRetType))
			{
				// In case we have 'jobject', we hope (1) it is 'void' for constructor
				if (IsMethodConstructor())
				{
					sRetv.assign(g_szcJavaVoidTypeName);
				}
				else
				{
					// (2) it should coincide with 'm_pResultObject' return value signature
					sRetv = m_pResultObject->GetDataTypeSignature();
				}
			}
			else
			{
				// Normally, it should be set as the very 1-st function's input parameter
				sRetv.assign(g_cszcJNITypeNames[eRetType]);
			}

			// .... and resulting storage type
			const JNIStorageType cjStorageType = m_pResultObject->GetStorageType();
			const bool cbIsArray = m_pResultObject->IsDataOfArrayType();
			if (cjStorageType == JNIStorageType_Public)	// implementation for public methods
			{
				string	sRetValPattern, sInputParams;
				
				if (cbIsArray)
				{
					FormatString(sRetValPattern, g_szcJavaArrayTypePattern, sRetv.c_str());
				}
				else
				{
					sRetValPattern.swap(sRetv);
				}
			
				bool bToBuild = true;
				if (uiNumArgs > 0)
				{
					sInputParams.reserve(128 * uiNumArgs);

					va_list vArgsList;
					va_start(vArgsList, uiNumArgs);
					for (unsigned int uiArgsCount = 0; uiArgsCount < uiNumArgs; ++uiArgsCount)
					{
// Next code which is unacceptable for Linux 
// (cannot pass objects of non-trivially-copyable type �class CJNIStringData� through �...�)
						//CTypeIdentifier * pNextParam = va_arg(vArgsList, CTypeIdentifier *);

						void * pNP = va_arg(vArgsList, void *);
						CTypeIdentifier * pNextParam = static_cast<CTypeIdentifier *>(pNP);
						if (!pNextParam->IsValidDataType())
						{
							FormatString(m_sLocalError, "Invalid Data Type object encountered; "
								"parameter #%u", uiArgsCount);
							bToBuild = false;
							break;
						}
					
						if (pNextParam->IsDataOfArrayType())
						{
							string	sParam;
							FormatString(sParam, g_szcJavaArrayTypePattern, 
								pNextParam->GetDataTypeSignature().c_str());
							sInputParams.append(sParam);
						}
						else
						{
							sInputParams.append(pNextParam->GetDataTypeSignature());
						}
					}
					va_end(vArgsList);
				}

				FormatString(m_sInstanceSignature, g_szcMethodParamsPattern, sInputParams.c_str(),
					sRetValPattern.c_str());
				bRetv = bToBuild;
			}
			else if (cjStorageType == JNIStorageType_Static)	// implementation for static fields
			{
				if (cbIsArray)
				{
					FormatString(m_sInstanceSignature, g_szcJavaArrayTypePattern, sRetv.c_str());
				}
				else
				{
					m_sInstanceSignature.swap(sRetv);
				}
				bRetv = true;
			}
			else
			{
				FormatString(m_sLocalError, "Undefine pattern class storage type #%u",
					static_cast<unsigned int>(cjStorageType));
			}
		}
		while (false);

		if (!bRetv)
		{
			m_sInstanceSignature.clear();
		}

		return bRetv;
	}

	string GetLatestError(void) const
	{
		return m_sLocalError;
	}

	string GetInstanceSignature(void) const
	{
		return m_sInstanceSignature;
	}

	string GetInstanceName(void) const
	{
		return m_sInstanceName;
	}

	string GetOwnerClassPath(void) const
	{
		return m_sOwnerClassPath;
	}

	JNIStorageType GetStorageType() const
	{
		return (m_pResultObject == NULL) ? JNIStorageType_Unknown :
			m_pResultObject->GetStorageType();
	}

	bool IsMethodConstructor() const
	{ 
		return CompareStr(m_sInstanceName, g_szcClassConstructorName); 
	}

	TDataType * GetResultObject() const
	{
		ASSERT(m_pResultObject != NULL);
		return m_pResultObject;
	}

private:
	string		m_sLocalError;			// Last error erased
	string		m_sInstanceSignature;	// input parameters and return value signature
	string		m_sInstanceName;		// function or method name
	string		m_sOwnerClassPath;		// owner class path, for use when looking for ACTUAL method 
										// called, NOT abstract one;
	TDataType * m_pResultObject;
};

////////////////////////////////////////////////////////////////////////////////////////////////////

template<class TDataType, class TParentType = CJNIObjectData>  class CJNIProcessor
{
public:
	CJNIProcessor(CJNIInstance<TDataType> * pInstance, TParentType * pParent = NULL):
		m_jcParentClass(nullptr),
		m_jmMethodID(nullptr),
		m_jfFieldID(nullptr),
		m_pInstObject(pInstance),
		m_pParentObject(pParent)	// may be NULL if we're not going to call 'ExecuteMethod()'
		{}

	virtual ~CJNIProcessor()
		{}

	string GetLatestError(void) const
	{
		return m_sLocalError;
	}

	bool GetClassPath(void)
	{
		bool bRetv = false;

		m_sLocalError.clear();
		do
		{
			if (m_pInstObject == NULL)
			{
				m_sLocalError.assign("Pattern Data Type class is undefined");
				break;
			}

			if (m_jcParentClass != nullptr)
			{
				bRetv = true;	// defined already
				break;
			}

			string sPath2Find = m_pInstObject->GetOwnerClassPath();
			if (sPath2Find.empty())
			{
				FormatString(m_sLocalError, "Class path is undefined for instance '%s'",
					m_pInstObject->GetInstanceName().c_str());
			}

			m_jcParentClass = g_pJNIEnvironment->FindClass(sPath2Find.c_str());
			bRetv = (m_jcParentClass != nullptr);
			if (!bRetv)
			{
				FormatString(m_sLocalError, "Failed to load a locally-defined class '%s'",
					sPath2Find.c_str());
			}
		}
		while (false);

		return bRetv;
	}

	bool GetInstanceID()
	// m_pInstObject->SetFunctionSignature should be called before this function!
	{
		bool bRetv = false;

		m_sLocalError.clear();
		do
		{
			if (!GetClassPath())
			{
				break;
			}

			if (m_jmMethodID != nullptr)
			{
				bRetv = true;	// defined already
				break;
			}

			JNIStorageType jStClass = m_pInstObject->GetStorageType();
			// Retrieve method name for public classes or 'Field name' for static fields
			const string csInstanceName = m_pInstObject->GetInstanceName();
			// Retrieve method (or field) signature
			const string csSignature = m_pInstObject->GetInstanceSignature();
			if (csInstanceName.empty() || csSignature.empty())
			{
				FormatString(m_sLocalError, "Instance name '%s' or signature '%s' is undefined",
					csInstanceName.c_str(), csSignature.c_str());
			}

			if (jStClass == JNIStorageType_Public)	// implementation for public methods
			{
				m_jmMethodID = g_pJNIEnvironment->GetMethodID(m_jcParentClass,
					csInstanceName.c_str(), csSignature.c_str());

				bRetv = (m_jmMethodID != nullptr);
				if (!bRetv)
				{
					//Returns the method ID for an instance (nonstatic) method of a class 
					FormatString(m_sLocalError, "Cannot resolve ID for a public method '%s'; "
						"type signature: %s", csInstanceName.c_str(), csSignature.c_str());
				}
			}
			else if (jStClass == JNIStorageType_Static)	// implementation for static fields
			{
				m_jfFieldID = g_pJNIEnvironment->GetStaticFieldID(m_jcParentClass,
					csInstanceName.c_str(), csSignature.c_str());

				bRetv = (m_jfFieldID != nullptr);
				if (!bRetv)
				{
					FormatString(m_sLocalError, "Cannot resolve ID for a static field '%s';"
						" type signature: %s", csInstanceName.c_str(), csSignature.c_str());
				}
			}
			else
			{
				FormatString(m_sLocalError, "Undefine pattern class storage type #%u",
					static_cast<unsigned int>(jStClass));
			}
		}
		while (false);

		return bRetv;
	}

	bool CreateNewObject(unsigned int uiNumArgs, ...)
	{
		bool bRetv = false;

		m_sLocalError.clear();
		do
		{
			if (!GetInstanceID())
			{
				break;
			}

			JNIStorageType jStClass = m_pInstObject->GetStorageType();
			if (jStClass == JNIStorageType_Public)	// implementation for public methods
			{
				va_list vArgList;
				va_start(vArgList, uiNumArgs);
				// 'm_jmMethodID' should be defined if 'GetInstanceID' succeeded
				m_pInstObject->GetResultObject()->CreateNewDTObject(m_jcParentClass,
					static_cast<void *>(m_jmMethodID), vArgList);
				va_end(vArgList);

				m_pInstObject->GetResultObject()->EvaluateResult(bRetv);
				if (!bRetv)
				{
					//Returns the method ID for an instance (nonstatic) method of a class 
					FormatString(m_sLocalError, "Failed to create a new public object '%s'",
						m_pInstObject->GetInstanceName().c_str());
				}
			}
			else if (jStClass == JNIStorageType_Static)	// implementation for static fields
			{
				// Templete class should be 'CJNIFieldData' for static object
				m_pInstObject->GetResultObject()->CreateNewDTObject(m_jcParentClass,
					static_cast<void *>(m_jfFieldID), NULL);
				m_pInstObject->GetResultObject()->EvaluateResult(bRetv);
				if (!bRetv)
				{
					FormatString(m_sLocalError, "Cannot get value of a requested static field '%s'",
						m_pInstObject->GetInstanceName().c_str());
				}
			}
			else
			{
				FormatString(m_sLocalError, "Undefine pattern class storage type: %u",
					static_cast<unsigned int>(jStClass));
			}
		}
		while (false);

		return bRetv;
	}

	bool ExecuteMethod(unsigned int uiNumArgs, ...)
	{
		bool bRetv = false;

		m_sLocalError.clear();
		do
		{
			if (!GetInstanceID())
			{
				break;
			}

			if (m_pParentObject == NULL)
			{
				m_sLocalError.assign("Parent JNI object was not set on creation time");
				break;
			}

			JNIStorageType jStClass = m_pInstObject->GetStorageType();
			if (jStClass == JNIStorageType_Public)	// implementation for public methods 
			{
				void * pRetv = m_pInstObject->GetResultObject()->GetResultValAddress();
				if (pRetv == NULL)
				{
					m_sLocalError.assign("Resulting value is undefined");
					break;
				}

				va_list vArgsList;
				va_start(vArgsList, uiNumArgs);
				m_pInstObject->GetResultObject()->ExecuteJNIMethod(pRetv,
					m_pParentObject->GetJNIObjectData(), m_jmMethodID, vArgsList);
				va_end(vArgsList);

				if (g_pJNIEnvironment->ExceptionCheck())
				{
					FormatString(m_sLocalError, "Exception when running method '%s'",
						m_pInstObject->GetInstanceName().c_str());
#ifdef DEBUG
					g_pJNIEnvironment->ExceptionDescribe();
#endif	//DEBUG
					g_pJNIEnvironment->ExceptionClear();
					break;
				}

				m_pInstObject->GetResultObject()->EvaluateResult(bRetv);
				if (!bRetv)
				{
					//Returns the method ID for an instance (nonstatic) method of a class 
					FormatString(m_sLocalError, "Failed to run method '%s'",
						m_pInstObject->GetInstanceName().c_str());
				}
			}
			else
			{
				FormatString(m_sLocalError, "Undefine pattern class storage type: %u",
					static_cast<unsigned int>(jStClass));
			}
		}
		while (false);

		return bRetv;
	}

private:
// For resulting 'jobject' should be use one from template class
	string			m_sLocalError;
	jclass			m_jcParentClass;
	jmethodID		m_jmMethodID;
	jfieldID		m_jfFieldID;
	CJNIInstance<TDataType> * m_pInstObject;
	TParentType		* m_pParentObject;
};

////////////////////////////////////////////////////////////////////////////////////////////////////

template <class TDataType> unsigned int GetJNIArrayLength(const TDataType & objJNIData)
{
	// Estimate size of resulting array: jsize GetArrayLength(JNIEnv *env, jarray array);
	jsize	jnArraySize = objJNIData.IsDataOfArrayType() ? g_pJNIEnvironment->GetArrayLength(
		static_cast<jarray>(objJNIData.GetJNIObjectData())) : 0;

	return static_cast<unsigned int>(jnArraySize);
}

template <class TDataType> bool GetJNIArrayNextObject(const unsigned int cuiNext,
	const TDataType & cObjArrayData, TDataType & objNextData)
{
	bool bRetv = false;

	if (cObjArrayData.IsDataOfArrayType())
	{
		jobject joNextItem = g_pJNIEnvironment->GetObjectArrayElement(
					static_cast<jobjectArray>(cObjArrayData.GetJNIObjectData()), cuiNext);
		if (joNextItem != nullptr)
		{
			bRetv = true;
			objNextData.SetJNIObjectData(joNextItem);
		}
	}

	return bRetv;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
#endif	//#ifdef USE_JNI_TFS_SDK
#endif	// _TFSJNIDATA_H__INCLUDED_
