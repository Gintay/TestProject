#ifndef _LIBTFSCLIENTCALLER_H__INCLUDED_
#define _LIBTFSCLIENTCALLER_H__INCLUDED_

#include "libtfsclient/libtfsclientapi.h"

////////////////////////////////////////////////////////////////////////////////////////////////////

#define		NUMBER_OF_EXPORTED_FUNCTIONS		16

extern const char * const g_cpszcTFSClientFunctionsNames[NUMBER_OF_EXPORTED_FUNCTIONS];

////////////////////////////////////////////////////////////////////////////////////////////////////

struct CItemInfo
{
	CItemInfo():
		m_nContentSize(0U),
		m_bIsDirectory(false)
		{}

	string		m_sPath;
	size_t		m_nContentSize;
	bool		m_bIsDirectory;
};
typedef vector<CItemInfo> CItemInfos;

class CLibTfsClientCaller
{
public:
	CLibTfsClientCaller();
	~CLibTfsClientCaller();

	bool Initialize(const string & csPathToLibTfsClientLibrary, const bool cbStandAlone,
		string & sError);
	bool Finalize();
	bool IsInitialized()	{ return m_bInitialized; };
	bool IsStandAlone()		{ return m_bStandAlone;  };

	bool CreateSession(const string & csUrl, CLibTfsClientSession * & pSession,
		string & sError);
	bool CreateSession(const string & csUrl, const string & csDomain, const string & csUser,
		const string & csPwd, CLibTfsClientSession * & pSession, string & sError);
	bool DestroySession(CLibTfsClientSession * & pSession, string & sError) const;
	bool DownloadDirectory(CLibTfsClientSession * & pSession, const string & csSourceTfsPath,
		const string & csDestinationPath, const bool cbRecursive, string & sError) const;
	bool DownloadFile(CLibTfsClientSession * & pSession, const string & csSourceTfsPath,
		const string & csDestinationPath, string & sError) const;
	bool DownloadItem(CLibTfsClientSession * & pSession, const string & csPathToItem,
		string & sItemContent, string & sError) const;
	bool GetItemInfos(CLibTfsClientSession * pSession, const string & csPath,
		const bool cbRecurcive, CItemInfos & itemInfos, string & sError) const;
	bool GetProjectNames(CLibTfsClientSession * pSession, vector<string> & svProjectNames,
		string & sError) const;

private:
	bool InitializeSDKLibraries(string & sError);
	bool FinalizeSDKLibraries(string & sError);
	bool DefineFunctions(string & sError);
	void UndefineFunctions();
	void MoveAndFreeLibErrorMemory(char * & szError, string & sError) const;

private:
	void *	m_pLibTfsClient;
	bool	m_bInitialized;
	bool	m_bSDKLibsLoaded;
	bool	m_bStandAlone;
	string	m_sTfsClientLibPath;

	TLibTfsClient_BeginItemsEnumeration		m_funcBeginItemsEnumeration;
	TLibTfsClient_BeginProjectsEnumeration	m_funcBeginProjectsEnumeration;
	TLibTfsClient_CreateSession				m_funcCreateSession;
	TLibTfsClient_CreateAuthSession			m_funcCreateAuthSession;
	TLibTfsClient_DestroySession			m_funcDestroySession;
	TLibTfsClient_DownloadItem				m_funcDownloadItem;
	TLibTfsClient_EndItemsEnumeration		m_funcEndItemsEnumeration;
	TLibTfsClient_EndProjectsEnumeration	m_funcEndProjectsEnumeration;
	TLibTfsClient_Finalize					m_funcFinalize;
	TLibTfsClient_FreeMemory				m_funcFreeMemory;
	TLibTfsClient_GetItemInfo				m_funcGetItemInfo;
	TLibTfsClient_GetLastError				m_funcGetLastError;
	TLibTfsClient_GetProjectName			m_funcGetProjectName;
	TLibTfsClient_Initialize				m_funcInitialize;
	TLibTfsClient_MoveToNextItem			m_funcMoveToNextItem;
	TLibTfsClient_MoveToNextProject			m_funcMoveToNextProject;

	void ** g_cppTFSClientFunctionsAddresses[NUMBER_OF_EXPORTED_FUNCTIONS];
};

#endif // #ifndef _LIBTFSCLIENTCALLER_H__INCLUDED_
