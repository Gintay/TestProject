#include "StdAfx.h"

#include "platformutils.h"
#include "liblogger/logging.h"
#include "common_constants.h"
#include "scope_objects.h"
#include "pathutils.h"
#include "strutils.h"

#include "libtfsclientcaller.h"

////////////////////////////////////////////////////////////////////////////////////////////////////

const char g_szcErrorNotInitialized[]	= "'LibTfsClient' library is not initialized";
const char g_szcErrorSDKNotInitialized[]= "SDK libraries are not initialized";
const char g_szcSDKLibsInitialized[]	= "SDK libraries are initialized already";

////////////////////////////////////////////////////////////////////////////////////////////////////

const char * const g_cpszcTFSClientFunctionsNames[NUMBER_OF_EXPORTED_FUNCTIONS] =
{ 
	LIBTFSCLIENT_BEGIN_ITEMS_ENUMERATION,
	LIBTFSCLIENT_BEGIN_PROJECTS_ENUMERATION,
	LIBTFSCLIENT_CREATE_SESSION,
	LIBTFSCLIENT_CREATE_SESSION_WITH_CREDS,
	LIBTFSCLIENT_DESTROY_SESSION,
	LIBTFSCLIENT_DOWNLOAD_ITEM,
	LIBTFSCLIENT_END_ITEMS_ENUMERATION,
	LIBTFSCLIENT_END_PROJECTS_ENUMERATION,
	LIBTFSCLIENT_FINALIZE,
	LIBTFSCLIENT_FREE_MEMORY,
	LIBTFSCLIENT_GET_ITEM_INFO,
	LIBTFSCLIENT_GET_LAST_ERROR,
	LIBTFSCLIENT_GET_PROJECT_NAME,
	LIBTFSCLIENT_INITIALIZE,
	LIBTFSCLIENT_MOVE_TO_NEXT_ITEM,
	LIBTFSCLIENT_MOVE_TO_NEXT_PROJECT
};

////////////////////////////////////////////////////////////////////////////////////////////////////

CLibTfsClientCaller::CLibTfsClientCaller():
	m_pLibTfsClient(NULL),
	m_bInitialized(false),
	m_bSDKLibsLoaded(false),
	m_bStandAlone(false),
	m_funcBeginItemsEnumeration(NULL),
	m_funcBeginProjectsEnumeration(NULL),
	m_funcCreateSession(NULL),
	m_funcCreateAuthSession(NULL),
	m_funcDestroySession(NULL),
	m_funcDownloadItem(NULL),
	m_funcEndItemsEnumeration(NULL),
	m_funcEndProjectsEnumeration(NULL),
	m_funcFinalize(NULL),
	m_funcFreeMemory(NULL),
	m_funcGetItemInfo(NULL),
	m_funcGetLastError(NULL),
	m_funcGetProjectName(NULL),
	m_funcInitialize(NULL),
	m_funcMoveToNextItem(NULL),
	m_funcMoveToNextProject(NULL)
{
	g_cppTFSClientFunctionsAddresses[0] = reinterpret_cast<void **>(&m_funcBeginItemsEnumeration);
	g_cppTFSClientFunctionsAddresses[1] = reinterpret_cast<void **>(&m_funcBeginProjectsEnumeration);
	g_cppTFSClientFunctionsAddresses[2] = reinterpret_cast<void **>(&m_funcCreateSession);
	g_cppTFSClientFunctionsAddresses[3] = reinterpret_cast<void **>(&m_funcCreateAuthSession);
	g_cppTFSClientFunctionsAddresses[4] = reinterpret_cast<void **>(&m_funcDestroySession);
	g_cppTFSClientFunctionsAddresses[5] = reinterpret_cast<void **>(&m_funcDownloadItem);
	g_cppTFSClientFunctionsAddresses[6] = reinterpret_cast<void **>(&m_funcEndItemsEnumeration);
	g_cppTFSClientFunctionsAddresses[7] = reinterpret_cast<void **>(&m_funcEndProjectsEnumeration);
	g_cppTFSClientFunctionsAddresses[8] = reinterpret_cast<void **>(&m_funcFinalize);
	g_cppTFSClientFunctionsAddresses[9] = reinterpret_cast<void **>(&m_funcFreeMemory);
	g_cppTFSClientFunctionsAddresses[10] = reinterpret_cast<void **>(&m_funcGetItemInfo);
	g_cppTFSClientFunctionsAddresses[11] = reinterpret_cast<void **>(&m_funcGetLastError);
	g_cppTFSClientFunctionsAddresses[12] = reinterpret_cast<void **>(&m_funcGetProjectName);
	g_cppTFSClientFunctionsAddresses[13] = reinterpret_cast<void **>(&m_funcInitialize);
	g_cppTFSClientFunctionsAddresses[14] = reinterpret_cast<void **>(&m_funcMoveToNextItem);
	g_cppTFSClientFunctionsAddresses[15] = reinterpret_cast<void **>(&m_funcMoveToNextProject);
}

CLibTfsClientCaller::~CLibTfsClientCaller()
{
}

bool CLibTfsClientCaller::Initialize(const string & csPathToLibTfsClientLibrary,
	const bool cbStandAlone, string & sError)
{
	bool bRes = false;
	BEGIN_FUNCTION("CLibTfsClientCaller::Initialize");

	ASSERT(STATIC_ARRAY_SIZE(g_cpszcTFSClientFunctionsNames) == NUMBER_OF_EXPORTED_FUNCTIONS);
	ASSERT(STATIC_ARRAY_SIZE(g_cppTFSClientFunctionsAddresses) == NUMBER_OF_EXPORTED_FUNCTIONS);

	m_bStandAlone = cbStandAlone;
	do
	{
		if (m_bInitialized)
		{
			bRes = true;
			break;
		}

		m_pLibTfsClient = PlatformInlines::LoadLibrary(csPathToLibTfsClientLibrary.c_str());
		if (m_pLibTfsClient == NULL)
		{
			FormatString(sError, "Failed to load library '%s'. Error: %s", 
				csPathToLibTfsClientLibrary.c_str(), CPlatformUtils::GetLastError().c_str());
			LOG_ERR1(sError.c_str());
			break;
		}

		string	sDefError;
		if (!DefineFunctions(sDefError))
		{
			FormatString(sError, "Failed to define functions. Error: %s", sDefError.c_str()); 
			LOG_ERR1(sError.c_str());

			UndefineFunctions();
			if (!PlatformInlines::UnloadLibrary(m_pLibTfsClient))
			{
				FormatString(sError, "Failed to unload '%s' library. Error: %s",
					csPathToLibTfsClientLibrary.c_str(), CPlatformUtils::GetLastError().c_str());
				LOG_WRN1(sError.c_str());
			}
			m_pLibTfsClient = NULL;
			break;
		}

		// Remove possible library file name from the incoming path
		string sLibSelfName(LIBTFSCLIENT_LIB_NAME);
		int iFileName = FindNoCase(csPathToLibTfsClientLibrary, sLibSelfName);
		if (iFileName < 0)
		{
			m_sTfsClientLibPath.assign(csPathToLibTfsClientLibrary);
		}
		else
		{
			m_sTfsClientLibPath = csPathToLibTfsClientLibrary.substr(0, iFileName);
		}

		// Move actual TFS SDK libraries initializing from here to the very first call
		// of 'CreateSession()', because of great memory and CPU consumption
		/* ****************
		if (!m_bStandAlone)	// StandAlone version needs no initialization and finalization calls
		{
			// So, next code is for BM SMC version only
			char * szError = NULL;
			char * szLibsLocationMessage = NULL;
			string	sJvmLibRootPath, sTfsSdkRootPath, sLibsLocation;
			
			// - sJvmLibRootPath: path to 'libjvm.so' ('jvm.dll') library, for Java only; should be
			// resolved by 'libtfs' library itself, therefore we may not initialize it;
			// - sTfsSdkRootPath: path to 3rd-party libraries we need to run SDK TFS; should be
			// '[Eagle_Root]/lib/3rdparty/tfs_sdk/Net|Java/lib/' folder, or empty for Java
#ifndef USE_JNI_TFS_SDK		// Windows, .NET
			sTfsSdkRootPath.assign(m_sTfsClientLibPath);
			sTfsSdkRootPath.append(g_cszWhereDotNetLibsAre);
			CPlatformUtils::NormalizeGivenPath(sTfsSdkRootPath);
#endif	//USE_JNI_TFS_SDK
			LOG_DEBUG3("Supposed library location is '%s', supposed TFS SDK tools path: '%s'",
				m_sTfsClientLibPath.c_str(), sTfsSdkRootPath.c_str());

			LibTfsClientResultCode eRes = m_funcInitialize(sJvmLibRootPath.c_str(),
				sTfsSdkRootPath.c_str(), szLibsLocationMessage, szError);
			MoveAndFreeLibErrorMemory(szLibsLocationMessage, sLibsLocation);
			LOG_PROD1(sLibsLocation.c_str());
			if (eRes != LibTfsClientResultCode_NoError)
			{
				string sLastError;
				MoveAndFreeLibErrorMemory(szError, sLastError);
				FormatString(sError, "Failed to initialize library from '%s' location. %s",
					sTfsSdkRootPath.c_str(), sLastError.c_str());
				LOG_ERR1(sError.c_str());

				UndefineFunctions();

				if (!PlatformInlines::UnloadLibrary(m_pLibTfsClient))
				{
					FormatString(sError, "Failed to unload '%s' library. Error: %s",
						csPathToLibTfsClientLibrary.c_str(), CPlatformUtils::GetLastError().c_str());
					LOG_WRN1(sError.c_str());
				}
				m_pLibTfsClient = NULL;
				break;
			}
		}
		LOG_PROD3("'%s' library found in '%s' location and successfully initialized",
			sLibSelfName.c_str(), m_sTfsClientLibPath.c_str());
		**************** */
		m_bInitialized = bRes = true;
	}
	while (false);

	END_FUNCTION_RET(bRes, false);
}

bool CLibTfsClientCaller::Finalize()
{
	bool	bRetv = true;
	BEGIN_FUNCTION("CLibTfsClientCaller::Finalize");

	do
	{
		if (!m_bInitialized)
		{
			LOG_ERR1(g_szcErrorNotInitialized);
			break;
		}
		// No breaks more, all rest steps should be executed

		/* ****************
		// Move actual TFS SDK libraries finalizing from here to 'DestroySession()'
		// because of great memory and CPU consumption
		if (!m_bStandAlone)	// StandAlone version needs no initialization and finalization calls
		{
			// Next code is for BM SMC version only
			if (m_funcFinalize() != LibTfsClientResultCode_NoError)
			{
				LOG_ERR1("Failed to finalize library");
			}
		}
		**************** */
		// Move back actual TFS SDK libraries finalizing from 'DestroySession()' to here
		// since it's impossible to destroy JVM and restart it anew
		string	sFinalError;
		if (!FinalizeSDKLibraries(sFinalError))
		{
			bRetv = false;
			LOG_ERR1(sFinalError.c_str());
		}

		UndefineFunctions();
		if (!PlatformInlines::UnloadLibrary(m_pLibTfsClient))
		{
			bRetv = false;
			LOG_WRN2("Failed to unload library. Error: %s", CPlatformUtils::GetLastError().c_str());
		}
		m_pLibTfsClient = NULL;

		if (bRetv)
		{
			LOG_PROD2("'%s' library successfully finalized", LIBTFSCLIENT_LIB_NAME);
		}
		m_bInitialized = false;
	}
	while (false);

	END_FUNCTION_RET(bRetv, false);
}

bool CLibTfsClientCaller::DefineFunctions(string & sError)
{
	bool bRes = false;
	BEGIN_FUNCTION("CLibTfsClientCaller::DefineFunctions");

	do
	{
		if (m_pLibTfsClient == NULL)
		{
			FormatString(sError, "Failed to initialise '%s' library", LIBTFSCLIENT_LIB_NAME);
			break;
		}

		size_t nIdx = 0, nExportedFunctions = NUMBER_OF_EXPORTED_FUNCTIONS;
		for (; nIdx < nExportedFunctions; ++nIdx)
		{
			void * pFuncAddress = PlatformInlines::GetSymbolAddress(m_pLibTfsClient,
				g_cpszcTFSClientFunctionsNames[nIdx]);
			if (pFuncAddress == NULL)
			{
				break;
			}
			*g_cppTFSClientFunctionsAddresses[nIdx] = pFuncAddress;
		}
		
		if (nIdx < nExportedFunctions)
		{
#ifdef WIN32
			const char * szcLastErr = CPlatformUtils::GetLastError().c_str();
#else	//!WIN32
			const char * szcLastErr = SAFE_STRING(dlerror());
#endif	//#ifdef WIN32
			FormatString(sError, "Failed to resolve '%s' function. %s",
				g_cpszcTFSClientFunctionsNames[nIdx], szcLastErr);
			break;
		}
		bRes = true;
	}
	while (false);

	if (!sError.empty())
	{
		LOG_ERR1(sError.c_str());
	}

	END_FUNCTION_RET(bRes, false);
}

void CLibTfsClientCaller::UndefineFunctions()
{
	size_t nExportedFunctions = NUMBER_OF_EXPORTED_FUNCTIONS;
	for (size_t nIdx = 0; nIdx < nExportedFunctions; ++nIdx)
	{
		*g_cppTFSClientFunctionsAddresses[nIdx] = NULL;
	}
}

void CLibTfsClientCaller::MoveAndFreeLibErrorMemory(char * & szError, string & sError) const
{
	sError.clear();
	if (szError != NULL)
	{
		sError.assign(szError);
		void * pError = static_cast<void *>(szError);
		m_funcFreeMemory(pError);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////

bool CLibTfsClientCaller::CreateSession(const string & csUrl, CLibTfsClientSession * & pSession,
	string & sError)
{
	bool bRes = false;
	BEGIN_FUNCTION("CLibTfsClientCaller::CreateSession");

	do
	{
		if (!m_bInitialized)
		{
			sError.assign(g_szcErrorNotInitialized);
			LOG_ERR1(sError.c_str());
			break;
		}

		// Move actual TFS SDK libraries initializing from 'Initialize()' to the very first call
		// of 'CreateSession()', because of great memory and CPU consumption
		if (!InitializeSDKLibraries(sError))
		{
			LOG_ERR2("Failed to load SDK TFS libraries. %s", sError.c_str());
			break;
		}

		char * szError = NULL;
		LibTfsClientResultCode eRes = m_funcCreateSession(csUrl.c_str(), pSession, szError);
		string	sLastErr;
		MoveAndFreeLibErrorMemory(szError, sLastErr);
		if (eRes != LibTfsClientResultCode_NoError)
		{
			FormatString(sError, "Failed to create session; error code: %d. %s",
				static_cast<int>(eRes), sLastErr.c_str());
			LOG_ERR1(sError.c_str());
			break;
		}

		bRes = true;
	}
	while (false);

	END_FUNCTION_RET(bRes, false);
}

bool CLibTfsClientCaller::CreateSession(const string & csUrl, const string & csDomain,
	const string & csUser, const string & csPwd, CLibTfsClientSession * & pSession,
	string & sError)
{
	bool bRes = false;
	BEGIN_FUNCTION("CLibTfsClientCaller::CreateSession");

	do
	{
		if (!m_bInitialized)
		{
			sError.assign(g_szcErrorNotInitialized);
			LOG_ERR1(sError.c_str());
			break;
		}

		// Move actual TFS SDK libraries initializing from 'Initialize()' to the very first call
		// of 'CreateSession()', because of great memory and CPU consumption
		if (!InitializeSDKLibraries(sError))
		{
			LOG_ERR2("Failed to load SDK TFS libraries. %s", sError.c_str());
			break;
		}

		char * szError = NULL;
		LibTfsClientResultCode eRes = m_funcCreateAuthSession(csUrl.c_str(), csDomain.c_str(),
			csUser.c_str(), csPwd.c_str(), pSession, szError);
		string	sLastErr;
		MoveAndFreeLibErrorMemory(szError, sLastErr);
		if (eRes != LibTfsClientResultCode_NoError)
		{
			FormatString(sError, "Failed to create authenticated session; error code: %d. %s",
				static_cast<int>(eRes), sLastErr.c_str());
			LOG_ERR1(sError.c_str());
			break;
		}

		bRes = true;
	}
	while (false);

	END_FUNCTION_RET(bRes, false);
}

bool CLibTfsClientCaller::DestroySession(CLibTfsClientSession * & pSession, string & sError) const
{
	bool bRes = false;
	BEGIN_FUNCTION("CLibTfsClientCaller::DestroySession");

	do
	{
		if (!m_bInitialized)
		{
			sError.assign(g_szcErrorNotInitialized);
			LOG_ERR1(sError.c_str());
			break;
		}

		LibTfsClientResultCode eRes = m_funcDestroySession(pSession);
		if (eRes != LibTfsClientResultCode_NoError)
		{
			FormatString(sError, "Failed to destroy session, error code: %d",
				static_cast<int>(eRes));
			LOG_ERR1(sError.c_str());
			break;
		}

		bRes = true;
	}
	while (false);

	/* ***********
	// Move actual TFS SDK libraries finalizing from 'Finalize()' to here
	// because of great memory and CPU consumption
	string	sFinError;
	if (!FinalizeSDKLibraries(sFinError))
	{
		FormatString(sError, "%s\n%s", sError.c_str(), sFinError.c_str());
	}
	*********** */

	END_FUNCTION_RET(bRes, false);
}

bool CLibTfsClientCaller::DownloadDirectory(CLibTfsClientSession * & pSession,
	const string & csSourceTfsPath, const string & csDestinationPath, const bool cbRecursive,
	string & sError) const
{
	bool bRes = false;
	BEGIN_FUNCTION("CLibTfsClientCaller::DownloadDirectory");

	do
	{
		CItemInfos itemInfos;
		if (!GetItemInfos(pSession, csSourceTfsPath, false, itemInfos, sError))
		{
			LOG_ERR1(sError.c_str());
			break;
		}

		CItemInfos::const_iterator itItemInfo = itemInfos.begin();
		CItemInfos::const_iterator itItemInfoEnd = itemInfos.end();
		for (; itItemInfo != itItemInfoEnd; ++itItemInfo)
		{
			const CItemInfo & itemInfo = *itItemInfo;
			string sDestinationPath(itemInfo.m_sPath);
			FindAndReplace(sDestinationPath, csSourceTfsPath, csDestinationPath);

			if (itemInfo.m_bIsDirectory)
			{
				if (!cbRecursive)
				{
					continue;
				}

				if (CompareStr(csSourceTfsPath, itemInfo.m_sPath))	// skip current directory
				{
					continue;
				}

				if (!CPlatformUtils::DirectoryExists(sDestinationPath) &&
					!CPlatformUtils::CreateDirectory(sDestinationPath, true))
				{
					FormatString(sError, "Failed to create '%s' directory. Error: %s",
						sDestinationPath.c_str(), CPlatformUtils::GetLastError().c_str());
					LOG_ERR1(sError.c_str());
					break;
				}

				if (!DownloadDirectory(pSession, itemInfo.m_sPath, sDestinationPath, cbRecursive,
					sError))
				{
					LOG_ERR1(sError.c_str());
					break;
				}
			}
			else
			{
				if (!DownloadFile(pSession, itemInfo.m_sPath, sDestinationPath, sError))
				{
					LOG_ERR1(sError.c_str());
					break;
				}
			}
		}
		
		bRes = (itItemInfo == itItemInfoEnd);
	}
	while (false);

	END_FUNCTION_RET(bRes, false);
}

bool CLibTfsClientCaller::DownloadFile(CLibTfsClientSession * & pSession,
	const string & csSourceTfsPath, const string & csDestinationPath, string & sError) const
{
	bool bRes = false;
	BEGIN_FUNCTION("CLibTfsClientCaller::DownloadFile");

	do
	{
		if (!m_bInitialized)
		{
			sError.assign(g_szcErrorNotInitialized);
			LOG_ERR1(sError.c_str());
			break;
		}

		string sItemContent;
		if (!DownloadItem(pSession, csSourceTfsPath, sItemContent, sError))
		{
			LOG_ERR1(sError.c_str());
			break;
		}
		
		void * pFile = CPlatformUtils::OpenFile(csDestinationPath, FM_WRITE, true);
		if (pFile == NULL)
		{
			FormatString(sError, "Failed to open '%s' file. Error: %s", csDestinationPath.c_str(),
				CPlatformUtils::GetLastError().c_str());
			LOG_ERR1(sError.c_str());
			break;
		}
		CLOSE_FILE_ON_SCOPE(pFile);

		unsigned int uiBytesToWrite = static_cast<unsigned int>(sItemContent.size());
		int iBytesWritten = static_cast<unsigned int>(CPlatformUtils::WriteFileBuf(pFile,
			static_cast<const void *>(sItemContent.c_str()), uiBytesToWrite));
		if (iBytesWritten < 0)
		{
			FormatString(sError, "Failed to write buffer to '%s' file. Error: %s",
				csDestinationPath.c_str(), CPlatformUtils::GetLastError().c_str());
			LOG_ERR1(sError.c_str());
			break;
		}
		if (static_cast<unsigned int>(iBytesWritten) != uiBytesToWrite)
		{
			FormatString(sError, "Failed to write the whole buffer to '%s' file: %d bytes written "
				"out of %u total", csDestinationPath.c_str(), iBytesWritten, uiBytesToWrite);
			LOG_ERR1(sError.c_str());
			break;
		}

		bRes = true;
	}
	while (false);

	END_FUNCTION_RET(bRes, false);
}

bool CLibTfsClientCaller::DownloadItem(CLibTfsClientSession * & pSession,
	const string & csPathToItem, string & sItemContent, string & sError) const
{
	bool bRes = false;
	BEGIN_FUNCTION("CLibTfsClientCaller::DownloadItem");

	sItemContent.clear();
	do
	{
		if (!m_bInitialized)
		{
			sError.assign(g_szcErrorNotInitialized);
			LOG_ERR1(sError.c_str());
			break;
		}

		void * pContent = NULL;
		size_t nContentSize = 0U;
		LibTfsClientResultCode eRes = m_funcDownloadItem(pSession, csPathToItem.c_str(), pContent,
			nContentSize);
		if (eRes != LibTfsClientResultCode_NoError)
		{
			char * szError = NULL;
			string	sLastError;
			// Ask for last error...
			eRes = m_funcGetLastError(pSession, szError);
			// ... and clear memory if any
			MoveAndFreeLibErrorMemory(szError, sLastError);

			FormatString(sError, "Failed to download item with path '%s'; error code: %d. %s",
				csPathToItem.c_str(), static_cast<int>(eRes), sLastError.c_str());
			LOG_ERR1(sError.c_str());
			break;
		}

		if (pContent != NULL)
		{
			sItemContent.reserve(nContentSize);
			sItemContent.assign(static_cast<char *>(pContent), nContentSize);
			m_funcFreeMemory(pContent);
		}

		bRes = true;
	}
	while (false);

	END_FUNCTION_RET(bRes, false);
}

bool CLibTfsClientCaller::GetItemInfos(CLibTfsClientSession * pSession, const string & csPathInTfs,
	const bool cbRecurcive, CItemInfos & itemInfos, string & sError) const
{
	bool bRes = false;
	BEGIN_FUNCTION("CLibTfsClientCaller::GetItemInfos");

	itemInfos.clear();

	do
	{
		if (!m_bInitialized)
		{
			sError.assign(g_szcErrorNotInitialized);
			LOG_ERR1(sError.c_str());
			break;
		}

		CLibTfsClientItemsEnumeration * pEnumeration = NULL;
		LibTfsClientResultCode eRes = m_funcBeginItemsEnumeration(pSession, csPathInTfs.c_str(),
			cbRecurcive, pEnumeration);
		if (eRes != LibTfsClientResultCode_NoError)
		{
			char * szError = NULL;
			string	sLastError;
			// Ask for last error...
			eRes = m_funcGetLastError(pSession, szError);
			// ... and clear memory if any
			MoveAndFreeLibErrorMemory(szError, sLastError);

			FormatString(sError, "Failed to start items enumeration; error code: %d. %s",
				static_cast<int>(eRes), sLastError.c_str());
			LOG_ERR1(sError.c_str());
			break;
		}

		while (eRes == LibTfsClientResultCode_NoError)
		{
			itemInfos.push_back(CItemInfo());
			CItemInfo & itemInfo = itemInfos.back();

			CLibTfsClientItemInfo libTfsClientItemInfo;
			eRes = m_funcGetItemInfo(pEnumeration, libTfsClientItemInfo);
			if (eRes != LibTfsClientResultCode_NoError)
			{
				itemInfos.pop_back();
				FormatString(sError, "Failed to get next item info; error code: %d",
					static_cast<int>(eRes));
				LOG_ERR1(sError.c_str());
				break;
			}

			itemInfo.m_bIsDirectory = libTfsClientItemInfo.m_bIsDirectory;
			itemInfo.m_nContentSize = libTfsClientItemInfo.m_nContentSize;
			itemInfo.m_sPath.assign(libTfsClientItemInfo.m_szcPath);

			eRes = m_funcMoveToNextItem(pEnumeration);
		}

		if (m_funcEndItemsEnumeration(pEnumeration) != LibTfsClientResultCode_NoError)
		{
			LOG_WRN1("Failed to end items enumeration");
		}

		bRes = (eRes == LibTfsClientResultCode_EndReached);
	}
	while (false);

	END_FUNCTION_RET(bRes, false);
}

bool CLibTfsClientCaller::GetProjectNames(CLibTfsClientSession * pSession,
	vector<string> & svProjectNames, string & sError) const
{
	bool bRes = false;
	BEGIN_FUNCTION("CLibTfsClientCaller::GetProjectNames");

	svProjectNames.clear();
	do
	{
		if (!m_bInitialized)
		{
			sError.assign(g_szcErrorNotInitialized);
			LOG_ERR1(sError.c_str());
			break;
		}

		CLibTfsClientProjectsEnumeration *pEnumeration = NULL;
		LibTfsClientResultCode eRes = m_funcBeginProjectsEnumeration(pSession, pEnumeration);
		if (eRes != LibTfsClientResultCode_NoError)
		{
			char * szError = NULL;
			string	sLastError;
			// Ask for last error...
			eRes = m_funcGetLastError(pSession, szError);
			// ... and clear memory if any
			MoveAndFreeLibErrorMemory(szError, sLastError);

			FormatString(sError, "Failed to start projects enumeration; error code: %d. %s",
				static_cast<int>(eRes), sLastError.c_str());
			LOG_ERR1(sError.c_str());
			break;
		}

		while (eRes == LibTfsClientResultCode_NoError)
		{
			const char * szcProjectName = NULL;

			eRes = m_funcGetProjectName(pEnumeration, szcProjectName);		
			if (eRes != LibTfsClientResultCode_NoError)
			{
				FormatString(sError, "Failed to get item info, error code: %d",
					static_cast<int>(eRes));
				LOG_ERR1(sError.c_str());
				break;
			}
			svProjectNames.push_back(string(szcProjectName));

			eRes = m_funcMoveToNextProject(pEnumeration);
		}

		if (m_funcEndProjectsEnumeration(pEnumeration) != LibTfsClientResultCode_NoError)
		{
			LOG_WRN1("Failed to end projects enumeration");
		}

		bRes = (eRes == LibTfsClientResultCode_EndReached);
	}
	while (false);

	END_FUNCTION_RET(bRes, false);
}

bool CLibTfsClientCaller::InitializeSDKLibraries(string & sError)
{
	bool bRes = false;
	BEGIN_FUNCTION("CLibTfsClientCaller::InitializeSDKLibraries");

	do
	{
		if (!m_bInitialized)
		{
			sError.assign(g_szcErrorNotInitialized);
			LOG_ERR1(sError.c_str());
			break;
		}

		// Do it only on the very first TFS Session creation
		if (m_bSDKLibsLoaded)
		{
			bRes = true;
			LOG_PROD1(g_szcSDKLibsInitialized);
			break;
		}

		string sLibSelfName(LIBTFSCLIENT_LIB_NAME);
		if (!m_bStandAlone)	// StandAlone version needs no initialization and finalization calls
		{
			// So, next code is for BM SMC version only
			char * szError = NULL;
			char * szLibsLocationMessage = NULL;
			string	sJvmLibRootPath, sTfsSdkRootPath, sLibsLocation;
			
			// - sJvmLibRootPath: path to 'libjvm.so' ('jvm.dll') library, for Java only; should be
			// resolved by 'libtfs' library itself, therefore we may not initialize it;
			// - sTfsSdkRootPath: path to 3rd-party libraries we need to run SDK TFS; should be
			// '[Eagle_Root]/lib/3rdparty/tfs_sdk/Net|Java/lib/' folder, or empty for Java
#ifndef USE_JNI_TFS_SDK		// Windows, .NET
			sTfsSdkRootPath.assign(m_sTfsClientLibPath);
			sTfsSdkRootPath.append(g_cszWhereDotNetLibsAre);
			CPlatformUtils::NormalizeGivenPath(sTfsSdkRootPath);
#endif	//USE_JNI_TFS_SDK
			LOG_DEBUG3("Supposed library location is '%s', supposed TFS SDK tools path: '%s'",
				m_sTfsClientLibPath.c_str(), sTfsSdkRootPath.c_str());

			LibTfsClientResultCode eRes = m_funcInitialize(sJvmLibRootPath.c_str(),
				sTfsSdkRootPath.c_str(), szLibsLocationMessage, szError);
			MoveAndFreeLibErrorMemory(szLibsLocationMessage, sLibsLocation);
			LOG_PROD1(sLibsLocation.c_str());
			if (eRes != LibTfsClientResultCode_NoError)
			{
				string sLastError;
				MoveAndFreeLibErrorMemory(szError, sLastError);
				FormatString(sError, "Failed to initialize library from '%s' location. %s",
					sTfsSdkRootPath.c_str(), sLastError.c_str());
				LOG_ERR1(sError.c_str());

				UndefineFunctions();

				if (!PlatformInlines::UnloadLibrary(m_pLibTfsClient))
				{
					FormatString(sError, "Failed to unload '%s' library from '%s' location. "
						"Error: %s", sLibSelfName.c_str(), m_sTfsClientLibPath.c_str(),
						CPlatformUtils::GetLastError().c_str());
					LOG_WRN1(sError.c_str());
				}
				m_pLibTfsClient = NULL;
				break;
			}
		}
		LOG_PROD4("'%s' library was found in '%s' location and successfully initialized; "
			"StandAlone switch '%s'", sLibSelfName.c_str(), m_sTfsClientLibPath.c_str(),
			BoolToYesNoPtr(m_bStandAlone));

		bRes = true;
	}
	while (false);
	m_bSDKLibsLoaded = bRes;

	END_FUNCTION_RET(bRes, false);
}

bool CLibTfsClientCaller::FinalizeSDKLibraries(string & sError)
{
	bool bRetv = true;
	BEGIN_FUNCTION("CLibTfsClientCaller::FinalizeSDKLibraries");

	do
	{
		if (!m_bInitialized)
		{
			sError.assign(g_szcErrorNotInitialized);
			LOG_WRN1(sError.c_str());
			break;
		}

		if (!m_bSDKLibsLoaded)
		{
			sError.assign(g_szcErrorSDKNotInitialized);
			LOG_WRN1(sError.c_str());
			break;
		}

		if (!m_bStandAlone)	// StandAlone version needs no initialization and finalization calls
		{
			// Next code is for BM SMC version only
			if (m_funcFinalize() != LibTfsClientResultCode_NoError)
			{
				FormatString(sError, "Failed to finalize library '%s'", LIBTFSCLIENT_LIB_NAME);
				LOG_ERR1(sError.c_str());
				bRetv = false;
				break;
			}
		}
		LOG_PROD2("SDK libraries are successfully finalized; StandAlone switch '%s'",
			BoolToYesNoPtr(m_bStandAlone));
	}
	while (false);
	m_bSDKLibsLoaded = false;

	END_FUNCTION_RET(bRetv, false);
}
