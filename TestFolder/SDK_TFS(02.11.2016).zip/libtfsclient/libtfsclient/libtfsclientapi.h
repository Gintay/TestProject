#ifndef _LIBTFSCLIENTAPI_H__INCLUDED_
#define _LIBTFSCLIENTAPI_H__INCLUDED_

#ifdef _WIN32
#	define LIBTFSCLIENT_STDCALL				_stdcall
#	undef									USE_JNI_TFS_SDK
//#	define									USE_JNI_TFS_SDK		// uncomment for test purpose only!
#else // UNIX
#	define LIBTFSCLIENT_STDCALL
#	define									USE_JNI_TFS_SDK
#endif // WIN32

#define LIBTFSCLIENT_BEGIN_ITEMS_ENUMERATION				"LibTfsClient_BeginItemsEnumeration"
#define LIBTFSCLIENT_BEGIN_PROJECTS_ENUMERATION				"LibTfsClient_BeginProjectsEnumeration"
#define LIBTFSCLIENT_CREATE_SESSION							"LibTfsClient_CreateSession"
#define LIBTFSCLIENT_CREATE_SESSION_WITH_CREDS				"LibTfsClient_CreateAuthSession"
#define LIBTFSCLIENT_DESTROY_SESSION						"LibTfsClient_DestroySession"
#define LIBTFSCLIENT_DOWNLOAD_ITEM							"LibTfsClient_DownloadItem"
#define LIBTFSCLIENT_END_ITEMS_ENUMERATION					"LibTfsClient_EndItemsEnumeration"
#define LIBTFSCLIENT_END_PROJECTS_ENUMERATION				"LibTfsClient_EndProjectsEnumeration"
#define LIBTFSCLIENT_FINALIZE								"LibTfsClient_Finalize"
#define LIBTFSCLIENT_FREE_MEMORY							"LibTfsClient_FreeMemory"
#define LIBTFSCLIENT_GET_ITEM_INFO							"LibTfsClient_GetItemInfo"
#define LIBTFSCLIENT_GET_LAST_ERROR							"LibTfsClient_GetLastError"
#define LIBTFSCLIENT_GET_PROJECT_NAME						"LibTfsClient_GetProjectName"
#define LIBTFSCLIENT_INITIALIZE								"LibTfsClient_Initialize"
#define LIBTFSCLIENT_MOVE_TO_NEXT_ITEM						"LibTfsClient_MoveToNextItem"
#define LIBTFSCLIENT_MOVE_TO_NEXT_PROJECT					"LibTfsClient_MoveToNextProject"
#define LIBTFSCLIENT_UPLOAD_ITEM_USING_TEMP_WORKSPACE	\
	"LibTfsClient_UploadItemUsingTempWorkspace"
#define LIBTFSCLIENT_UPLOAD_ITEM_USING_EXISTING_WORKSPACE \
	"LibTfsClient_UploadItemUsingExistingWorkspace"

#if defined(_WIN64)
#	define LIBTFSCLIENT_LIB_NAME						"libtfsclient.dll"
#elif defined(_WIN32)
#	define LIBTFSCLIENT_LIB_NAME						"libtfsclient32.dll"
#else
#	define LIBTFSCLIENT_LIB_NAME						"libtfsclient.so"
#endif // defined(WIN32)

enum LibTfsClientResultCode
{
	LibTfsClientResultCode_NoError							= 0,

	LibTfsClientResultCode_EndReached,
	LibTfsClientResultCode_ErrorConnectFailed,
	LibTfsClientResultCode_ErrorExceptionReceived,
	LibTfsClientResultCode_ErrorInvalidArgument,
	LibTfsClientResultCode_ErrorMemoryAllocation,			// 5
	LibTfsClientResultCode_ErrorMemoryAllocation2,
	LibTfsClientResultCode_ErrorOperationFailed,
	LibTfsClientResultCode_ErrorNullPtrParameter,
	LibTfsClientResultCode_ErrorInternalJava,
	LibTfsClientResultCode_ErrorLibIsInitialized,			// 10
	LibTfsClientResultCode_ErrorLibIsFinalized,
	LibTfsClientResultCode_ErrorObjectNotExists,
	LibTfsClientResultCode_ErrorOutOfRange,
	LibTfsClientResultCode_ErrorFunctionNotImplemented,		// 14, for future use

	LibTfsClientResultCode_ErrorUnknown						= 0xffffffff
};

// The encoding these files are in (if null or FileEncoding.AUTOMATICALLY_DETECT,
//	the encoding is detected).
//enum PendAddFileEncoding
//{
//	PendAddFileEncoding_Unknown = 0x00000000,
//
//	PendAddFileEncoding_AutoDetectSpecialValue = 0x00000001, 
//	PendAddFileEncoding_AutomaticallyDetect = 0x00000002,
//	PendAddFileEncoding_Binary = 0x00000004,
//	PendAddFileEncoding_DefaultText = 0x00000008,
//	PendAddFileEncoding_TextSpecialValue = 0x00000010,
//	PendAddFileEncoding_UTF16 = 0x00000020,
//	PendAddFileEncoding_UTF16BE = 0x00000040,
//	PendAddFileEncoding_UTF32 = 0x00000080,
//	PendAddFileEncoding_UTF32BE = 0x00000100,
//	PendAddFileEncoding_UTF8 = 0x00000200,
//
//	PendAddFileEncodingsPattern = 0x000003FF,
//
//	PendAddLockLevel_ChekIn = 0x00000400,
//	PendAddLockLevel_ChekOut = 0x00000800,
//	PendAddLockLevel_None = 0x00001000,
//	PendAddLockLevel_Unchanged = 0x00002000,
//	PendAddLockLevel_ValueMap = 0x00004000,
//
//	PendAddLockLevelsMask = 0x0000FC00,
//
//	PendAddGetOption_GetAll = 0x00100000,
//	PendAddGetOption_NoAutoResolve,
//	PendAddGetOption_NoDiskUpdate,
//	PendAddGetOption_None,
//	PendAddGetOption_OverWrite,
//	PendAddGetOption_Preview,
//	PendAddGetOption_Remap,
//
//	PendAddGetOptionsMask = 0x00FF0000
//};
//
//// Options that affect how items are pended (must not be null)
//enum PendChangesOption
//{
//	PendChangesOption_Unknown,
//
//	PendChangesOption_ApplyLocalItemExclutions,
//	PendChangesOption_ForceChekOut,
//	PendChangesOption_GetLatestOnChekOut,
//	PendChangesOption_None,
//	PendChangesOption_Silent,
//	PendChangesOption_SuppressItemNotFoundFailures,
//	PendChangesOption_TreatMissingItemAsFile,
//
//	PendChangesOptionsCount
//};


// The encoding these files are in (if null or FileEncoding.AUTOMATICALLY_DETECT,
//	the encoding is detected).
enum PendAddFileEncoding
{
	PendAddFileEncoding_Unknown,

	PendAddFileEncoding_AutoDetectSpecialValue, 
	PendAddFileEncoding_AutomaticallyDetect,
	PendAddFileEncoding_Binary,
	PendAddFileEncoding_DefaultText,
	PendAddFileEncoding_TextSpecialValue,
	PendAddFileEncoding_UTF16,
	PendAddFileEncoding_UTF16BE,
	PendAddFileEncoding_UTF32,
	PendAddFileEncoding_UTF32BE,
	PendAddFileEncoding_UTF8,

	PendAddFileEncodingsCount
};

// The type of lock requested during this add (must not be null)
enum PendAddLockLevel
{
	PendAddLockLevel_Unknown,

	PendAddLockLevel_ChekIn,
	PendAddLockLevel_ChekOut,
	PendAddLockLevel_None,
	PendAddLockLevel_Unchanged,

	PendAddLockLevelsCount
};

// Options that affect how files on disk are treated during processing (must not be null)
enum PendAddGetOption
{
	PendAddGetOption_Unknown,

	PendAddGetOption_GetAll,
	PendAddGetOption_NoAutoResolve,
	PendAddGetOption_NoDiskUpdate,
	PendAddGetOption_None,
	PendAddGetOption_OverWrite,
	PendAddGetOption_Preview,
	PendAddGetOption_Remap,

	PendAddGetOptionsCount
};

// Options that affect how items are pended (must not be null)
enum PendChangesOption
{
	PendChangesOption_Unknown,

	PendChangesOption_ApplyLocalItemExclutions,
	PendChangesOption_ForceChekOut,
	PendChangesOption_GetLatestOnChekOut,
	PendChangesOption_None,
	PendChangesOption_Silent,
	PendChangesOption_SuppressItemNotFoundFailures,
	PendChangesOption_TreatMissingItemAsFile,

	PendChangesOptionsCount
};



////////////////////////////////////////////////////////////////////////////////////////////////////
// Forward declarations of opaque classes. They are defined inside LibTfsClient
////////////////////////////////////////////////////////////////////////////////////////////////////
class CLibTfsClientSession;
class CLibTfsClientItemsEnumeration;
class CLibTfsClientProjectsEnumeration;

////////////////////////////////////////////////////////////////////////////////////////////////////
// Enumerations
////////////////////////////////////////////////////////////////////////////////////////////////////
class CLibTfsClientItemInfo
{
public:
	CLibTfsClientItemInfo():
		m_szcPath(NULL),
		m_nContentSize(0U),
		m_bIsDirectory(false)
		{}

	const char *	m_szcPath;
	size_t			m_nContentSize;
	bool			m_bIsDirectory;
};

////////////////////////////////////////////////////////////////////////////////////////////////////
// Exported functions
////////////////////////////////////////////////////////////////////////////////////////////////////

/*
 * Begins items (files and/or folders) enumeration, from 'szcPath' folder.
 * Allocates CLibTfsClientItemsEnumeration object and sets pEnumeration pointer.
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_BeginItemsEnumeration)(
	CLibTfsClientSession * pSession, const char * szcPath, const bool cbRecurcive,
	CLibTfsClientItemsEnumeration * & pEnumeration);

/*
 * Begins team projects enumeration. Allocates the CLibTfsClientProjectsEnumerationInfo object and 
 * sets pEnumeration pointer.
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_BeginProjectsEnumeration)(
	CLibTfsClientSession * pSession, CLibTfsClientProjectsEnumeration * & pEnumeration);

/*
 * Establishes connection to TFS Server using szcUrl value, and credentials: domain and user name, 
 * and password. Sets up pSession pointer to hold session handle which must be closed later.
 * Sets up szError pointer to error if any, or to NULL; the memory, if allocated (that is 
 * szError != NULL after call), must be released later (..._FreeMemory)
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_CreateAuthSession)(
	const char * szcUrl, const char * szcDomain, const char * szcUser, const char * szcPwd,
	CLibTfsClientSession * & pSession, char * & szError);

/*
 * Establishes connection to TFS Server using szcUrl value and current process authentication data.
 * Sets up pSession pointer to hold session handle which must be closed later (..._DestroySession)
 * Sets up szError pointer to error if any, or to NULL; the memory, if allocated (that is 
 * szError != NULL after call), must be released later (..._FreeMemory)
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_CreateSession)(
	const char * szcUrl, CLibTfsClientSession * & pSession, char * & szError);

/*
 * Destroys previously created session
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_DestroySession)(
	CLibTfsClientSession * & pSession);

/*
 * Downloads item from server by its path. Allocates memory for pContent pointer
 * and sets its size - nContent.
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_DownloadItem)(
	CLibTfsClientSession * pSession, const char * szcPathToItem, void * & pContent,
	size_t & nContent);

/*
 * Ends items enumeration. Frees CLibTfsClientItemsEnumeration object and sets pEnumeration to NULL
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_EndItemsEnumeration)(
	CLibTfsClientItemsEnumeration * & pEnumeration);

/*
 * Ends team projects enumeration. Frees CLibTfsClientProjectsEnumerationInfo object and sets
 *  pEnumeration to NULL
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_EndProjectsEnumeration)(
	CLibTfsClientProjectsEnumeration * & pEnumeration);

/*
 * Release JVM and unloads JNI SDK archive and native libs from memory on the end.
 * Call it after session destroying.
 * ATTENTION: don't call it for StandAlone BundleManager !
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_Finalize)();

/*
 * Frees memory which was allocated inside 'LibTfsClient' library. Sets pMemory to NULL on success
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_FreeMemory)(void * & pMemory);

/*
 * Returns current item information
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_GetItemInfo)(
	CLibTfsClientItemsEnumeration * pEnumeration, CLibTfsClientItemInfo & itemInfo);

/*
 * Sets up szError pointer to the very latest error in current session if any, or to NULL;
 * the memory, if allocated (szError != NULL after call), must be released later (..._FreeMemory)
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_GetLastError)(
	CLibTfsClientSession * pSession, char * & szError);

/*
 * Gets project name in enumeration
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_GetProjectName)(
	CLibTfsClientProjectsEnumeration * pEnumeration, const char * & szcProjectName);

/*
 * Loads JNI SDK archive and native libs to the memory by szcRootPath set. Creates JVM. 
 * Call it before session creating, for Java (UNIX) version only. You must also
 * call '..._Finalize' before closing 'LibTfsClient' library. 
 * ATTENTION: don't call it for StandAlone BundleManager !
 * Sets up szError pointer to error if any, or to NULL; the memory, if allocated, must be released 
 * later (..._FreeMemory). 
 * szLogLibsLocationMsg is logging message about where target libs were located exactly;
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_Initialize)
	(const char * szcJvmLibRootPath, const char * szcTfsSdkRootPath, char * & szLogLibsLocationMsg,
	char * & szError);

/*
 * Moves to next item in enumeration. Returns LibTfsClientResultCode_EndReached if current item is
 *  the last one
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_MoveToNextItem)(
	CLibTfsClientItemsEnumeration * & pEnumeration);

/*
 * Moves to next project in enumeration. Returns LibTfsClientResultCode_EndReached if current
 *  project is the last one
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_MoveToNextProject)(
	CLibTfsClientProjectsEnumeration * pEnumeration);

/*
 * Add new files and folders to TFS using temporary workspace
 */
typedef LibTfsClientResultCode (LIBTFSCLIENT_STDCALL * TLibTfsClient_UploadItemUsingTempWorkspace)(
	CLibTfsClientSession * pSession, const char * szcServerPath, const char * szcLocalPath,
	const char * szcTargetPath, const char * szcComment, const bool cbRecursive,
	const PendAddLockLevel ceLockLevel, const PendAddFileEncoding ceFileEncoding,
	const PendAddGetOption ceGetOptions, const PendChangesOption cePendChangesOptions);

/*
 * Add new files and folders to TFS using existing workspace
 */
typedef LibTfsClientResultCode
	(LIBTFSCLIENT_STDCALL * TLibTfsClient_UploadItemUsingExistingWorkspace)(
	CLibTfsClientSession * pSession, const char * szcWorkspaceName, const char * szcWorkspaceOwner,
	const char * szcTargetPath, const char * szcComment, const bool cbRecursive,
	const PendAddLockLevel ceLockLevel, const PendAddFileEncoding ceFileEncoding,
	const PendAddGetOption ceGetOptions, const PendChangesOption cePendChangesOptions);

#endif // _LIBTFSCLIENTAPI_H__INCLUDED_
