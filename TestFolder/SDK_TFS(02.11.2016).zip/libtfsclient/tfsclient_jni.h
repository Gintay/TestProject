#ifndef _TFSCLIENT_H__INCLUDED_
#define _TFSCLIENT_H__INCLUDED_

#include "libtfsclient/libtfsclientapi.h"
#include "tfsjnidata.h"

////////////////////////////////////////////////////////////////////////////////////////////////////

extern const char g_szcEmptyInputError[];

extern const char * g_psz�WorkspaceOptionsList[];
extern const char * g_psz�FileEncodingsList[];
extern const char * g_psz�LockLevelList[];
extern const char * g_psz�GetOptionList[];
extern const char * g_psz�PendChangesOptionList[];

////////////////////////////////////////////////////////////////////////////////////////////////////

//WorkspaceLocation will be a bool variable


//options to use on the newly created workspace (if null, the default options are used)
enum WorkspaceOption
{
	WorkspaceOption_Unknown,

	WorkspaceOption_None,
	WorkspaceOption_SetFileToChekIn,

	WorkspaceOptionsCount
};

struct CPendAdd
{
	string sPaths;
	PendAddFileEncoding eFileEncoding;
	PendAddLockLevel eLockLevel;
	PendAddGetOption eGetOptions;
	PendChangesOption ePendChangesOptions;
	bool bRecursive;
};

class CItemInfo
{
public:
	CItemInfo():
		m_nContentSize(0U),
		m_bIsDirectory(false)
		{}

	size_t GetContentSize() const				{ return m_nContentSize;	}
	void SetContentSize(const size_t cnSize)	{ m_nContentSize = cnSize;	}

	bool GetIsDirectory() const					{ return m_bIsDirectory;	}
	void SetIsDirectory(const bool cbValue)		{ m_bIsDirectory = cbValue;	}

	const string & GetPath() const				{ return m_sPath;	}
	void SetPath(const string & sPath)			{ m_sPath = sPath;	}

private:
	string		m_sPath;
	size_t		m_nContentSize;
	bool		m_bIsDirectory;
};

class CTfsJNIClient
{
public:
	CTfsJNIClient():
		m_joProjectCollection(NULL)
		{}
	~CTfsJNIClient()
		{ Close(); }

	bool Close();
	bool Connect(const string & csUrl, const string & csFullName, const string & csPassword);
	bool DownloadItem(const char * szcPath, void * & pContent, size_t & nSize);
	bool UploadItemTempWorkspace(const string & csServerPath, const string & csLocalPath,
		const string & csComment, const CPendAdd & cPendAddOptions);
	bool UploadItemExistingWorkspace (const string & csWorkspaceName,
		const string & csWorkspaceOwner, const string & csComment,
		const CPendAdd & cPendAddOptions);
	bool GetItemsByPath(const char * szcPath, const bool cbIsRecursive,
		vector<CItemInfo> & vInfos);
	bool GetProjects(vector<string> & vsProjects);
	bool GetProjectsFromTFS(vector<string> & vsProjects);
	bool GetItemsByPathFromTFS(const string & csItemPath, const bool cbIsRecursive,
		vector<CItemInfo> & vInfos);
	string NormalizePathForTFS(const string & csPath);

	bool IsProjectCollectionNULL() const	{ return (m_joProjectCollection == NULL); };
	string GetLastError() const				{ return m_sError; };

private:
	bool CloseObject(const void * pcTFSObject2Close, const char * szcObjectPath);
	bool CreateWorkspace(const string & csServerPath, const string & csLocalPath,
		const string & csWorkspaceName, const string & csComment,
		const WorkspaceOption ceWorkspaceOptions, CJNIObjectData & jndVersionControlClient,
		CJNIObjectData & jndOutWorkspace, const bool cbServerLocation = true);
	bool GetWorkspace(const string & csWorkspaceName, const string & csWorkspaceOwner,
		CJNIObjectData & jndVersionControlClient, CJNIObjectData & jndOutWorkspace);
	bool PendAdd(const CPendAdd & cPendAddOptions, CJNIObjectData & jndWorkspace);
	bool CheckIn(const string & csComment, CJNIObjectData & jndWorkspace);
	bool DeleteWorkspase(CJNIObjectData & jndVersionControlClient, CJNIObjectData & jndWorkspace);
	bool DownloadItemFromTFS(const string & csItemPath, void * & pContent, size_t & nSize);
	bool CreateTFSConnection(const string & csUrl, const string & csFullName, const string & csPwd);
	bool JavaToConstChar(const jstring jsInput, const unsigned int cuiSize, char *szcOutput) const;
	bool JavaToStdString(const jstring jsInput, const unsigned int cuiSize,
		std::string & sOutput) const;
	bool GetVersionControlObject(CJNIObjectData & jndProjCollection, CJNIStringData & jndPath,
		CJNIObjectData & jndVersionCC);
	TFSItemType GetTFSItemType(CJNIObjectData & jndParentItem, CJNIFieldData jndItemTypes[],
		bool bFileOnly);
	static string GenerateTempWorkspaceName();

private:
	string	m_sError;
	void  * m_joProjectCollection;
};

////////////////////////////////////////////////////////////////////////////////////////////////////

#endif // _TFSCLIENT_H__INCLUDED_
