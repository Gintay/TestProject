#include "StdAfx.h"

#include "libtfsclient/libtfsclientapi.h"	// necessary to define 'USE_JNI_TFS_SDK'

#ifndef USE_JNI_TFS_SDK

#include "managedutils.h"
#include "tfs_unresolved_assembly_handler.h"

using namespace System;
using namespace System::Reflection;

const char g_cszFileExtension_dll[] = ".dll";
const char g_cchAssemblyNameDelimiter = ',';
const char g_cszSymbolSlash[] = "/";

string CTfsUnresolvedAssemblyHandler::ms_sTfsSdkDirectoryPath;
bool CTfsUnresolvedAssemblyHandler::ms_bIsStarted = false;

/* static */
bool CTfsUnresolvedAssemblyHandler::Start(const string & csTfsSdkDirectoryPath, string & sError)
{
	do
	{
		if (ms_bIsStarted)
		{
			break;
		}

		try
		{
			ms_sTfsSdkDirectoryPath.assign(csTfsSdkDirectoryPath);
			AppDomain ^ currentDomain = AppDomain::CurrentDomain;
			currentDomain->AssemblyResolve += gcnew ResolveEventHandler(&ResolveTfsAssembly);
			ms_bIsStarted = true;
		}
		catch (System::Exception ^ exception)
		{
			ManagedUtils::ConvertSystemStringToStdString(exception->Message, sError);
		}
	}
	while (false);

	return ms_bIsStarted;
}

bool CTfsUnresolvedAssemblyHandler::Stop(string & sError)
{
	do
	{
		if (!ms_bIsStarted)
		{
			break;
		}

		try
		{
			AppDomain ^ currentDomain = AppDomain::CurrentDomain;
			currentDomain->AssemblyResolve -= gcnew ResolveEventHandler(&ResolveTfsAssembly);
			ms_bIsStarted = false;
		}
		catch (System::Exception ^ exception)
		{
			ManagedUtils::ConvertSystemStringToStdString(exception->Message, sError);
		}
	}
	while (false);

	return !ms_bIsStarted;
}

/* static */
Assembly ^ CTfsUnresolvedAssemblyHandler::ResolveTfsAssembly(Object ^ sender,
	ResolveEventArgs ^ args)
{
	Assembly ^ resolvedAssembly = args->RequestingAssembly;

	try
	{
		String ^ sAssemblyToLoadName = args->Name;

		string sAssemblyName;
		ManagedUtils::ConvertSystemStringToStdString(sAssemblyToLoadName, sAssemblyName);

		const size_t cnAssemblyNameLastPos = sAssemblyName.find(g_cchAssemblyNameDelimiter);
		sAssemblyName.erase(cnAssemblyNameLastPos);
		sAssemblyName.append(g_cszFileExtension_dll);

		if (!ms_sTfsSdkDirectoryPath.empty())
		{
			sAssemblyName.insert(0U, ms_sTfsSdkDirectoryPath + g_cszSymbolSlash);
		}
		sAssemblyToLoadName = gcnew String(sAssemblyName.c_str());
	
		resolvedAssembly = Assembly::LoadFrom(sAssemblyToLoadName);
	}
	catch (...)
	{
	}

	return resolvedAssembly;
}

#endif	//#ifndef USE_JNI_TFS_SDK
